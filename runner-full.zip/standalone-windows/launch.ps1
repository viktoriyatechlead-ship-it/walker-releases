param(
    [string]$ConfigPath = (Join-Path $PSScriptRoot 'config.example.json')
)

$ErrorActionPreference = 'Continue'
$root = $PSScriptRoot
$runScript = Join-Path $root 'run.ps1'
. (Join-Path $root 'lib\Common.ps1')
. (Join-Path $root 'lib\Update.ps1')

# Self-update: if a newer version is hosted, download/apply it and relaunch (calls exit inside).
# Any error / no network -> stay on the current version.
try { Invoke-SelfUpdate -RootDir $root -ConfigPath $ConfigPath } catch { Write-Host "UPDATE: skipped ($($_.Exception.Message))" }

$consoleLog = Get-LaunchConsoleLogPath -RootDir $root -ConfigPath $ConfigPath
$workerLabel = ''
try {
    $resolvedConfigPath = Resolve-ConfigPath -RootDir $root -ConfigPath $ConfigPath
    $launchConfig = Read-JsonFile -Path $resolvedConfigPath
    $launchWorkerSettings = Resolve-WorkerSettings -Config $launchConfig -RootDir $root
    if ($launchWorkerSettings.HasExplicitWorkerId) {
        $workerLabel = " (worker $($launchWorkerSettings.WorkerId))"
    }
} catch {
}

Write-Host '========================================'
Write-Host " Standalone Windows Task Worker$workerLabel"
Write-Host '========================================'
Write-Host ''
Write-Host "Config: $ConfigPath"
Write-Host "Console log: $consoleLog"
Write-Host ''
Write-Host 'Starting...'
Write-Host ''

$transcriptStarted = $false
$exitCode = 0

try {
    Start-Transcript -Path $consoleLog -Force | Out-Null
    $transcriptStarted = $true

    $parseErrors = New-Object 'System.Collections.Generic.List[System.Management.Automation.Language.ParseError]'
    $scriptsToCheck = @($runScript) + @(Get-ChildItem -LiteralPath (Join-Path $root 'lib') -Filter '*.ps1' | ForEach-Object { $_.FullName })
    foreach ($scriptPath in $scriptsToCheck) {
        $fileErrors = $null
        [void][System.Management.Automation.Language.Parser]::ParseFile($scriptPath, [ref]$null, [ref]$fileErrors)
        if ($null -ne $fileErrors -and $fileErrors.Count -gt 0) {
            foreach ($err in $fileErrors) {
                $parseErrors.Add($err)
            }
        }
    }
    if ($parseErrors.Count -gt 0) {
        Write-Host 'SYNTAX CHECK FAILED. Fix these errors before running:'
        foreach ($err in $parseErrors) {
            Write-Host $err.ToString()
        }
        throw 'PowerShell syntax check failed'
    }

    & $runScript -ConfigPath $ConfigPath
    if ($null -ne $LASTEXITCODE -and $LASTEXITCODE -ne 0) {
        $exitCode = $LASTEXITCODE
    }
} catch {
    $exitCode = 1
    Write-Host ''
    Write-Host "LAUNCHER: $($_.Exception.Message)"
    if (-not [string]::IsNullOrWhiteSpace([string]$_.ScriptStackTrace)) {
        Write-Host $_.ScriptStackTrace
    }
} finally {
    if ($transcriptStarted) {
        Stop-Transcript | Out-Null
    }
}

Write-Host ''
Write-Host '========================================'
if ($exitCode -eq 0) {
    Write-Host 'Finished OK.'
} else {
    Write-Host "Finished with ERROR. Exit code: $exitCode"
}
Write-Host ''
Write-Host 'Logs to share:'
Write-Host "  $consoleLog"

try {
    $resolvedConfigPath = Resolve-ConfigPath -RootDir $root -ConfigPath $ConfigPath
    $launchConfig = Read-JsonFile -Path $resolvedConfigPath
    $launchWorkerSettings = Resolve-WorkerSettings -Config $launchConfig -RootDir $root
    $outputRoot = $launchWorkerSettings.OutputRoot
} catch {
    $outputRoot = Join-Path $root 'output'
}

if (Test-Path -LiteralPath $outputRoot) {
    $latestRun = Get-ChildItem -LiteralPath $outputRoot -Directory |
        Sort-Object Name -Descending |
        Select-Object -First 1

    if ($null -ne $latestRun) {
        $jsonLog = Join-Path $latestRun.FullName 'logs\run.jsonl'
        Write-Host "  $jsonLog"
    }
}

Write-Host ''
Read-Host 'Press Enter to close'
exit $exitCode
