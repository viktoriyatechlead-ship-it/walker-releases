@echo off
cd /d "%~dp0"

set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"

if not exist "%PS%" (
    echo PowerShell not found: %PS%
    pause
    exit /b 1
)

echo Starting runner...
"%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0launch.ps1" -ConfigPath "%~dp0config.json"
echo.
echo Done. Exit code: %ERRORLEVEL%
pause
