function Get-WindowsDeviceModel {
    try {
        $cs = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction Stop
        $manufacturer = [string]$cs.Manufacturer
        $model = [string]$cs.Model
        $value = (($manufacturer + ' ' + $model).Trim())
        if ([string]::IsNullOrWhiteSpace($value)) {
            return $env:COMPUTERNAME
        }
        return $value
    } catch {
        return $env:COMPUTERNAME
    }
}

function Get-OrCreateDeviceId {
    param(
        [Parameter(Mandatory = $true)][string]$StateDir
    )

    Ensure-Directory -Path $StateDir
    $deviceIdPath = Join-Path $StateDir 'device_id.txt'

    if (Test-Path -LiteralPath $deviceIdPath) {
        $stored = Get-Content -LiteralPath $deviceIdPath -Raw
        if (-not [string]::IsNullOrWhiteSpace($stored)) {
            return $stored.Trim()
        }
    }

    $base = (Get-WindowsDeviceModel).ToLowerInvariant() -replace '[^a-z0-9]+', '-'
    $base = $base.Trim('-')
    if ([string]::IsNullOrWhiteSpace($base)) {
        $base = 'windows-client'
    }
    if ($base.Length -gt 24) {
        $base = $base.Substring(0, 24).Trim('-')
    }

    $deviceId = "$base-$(New-RandomSuffix 3)"
    Set-Content -LiteralPath $deviceIdPath -Value $deviceId -Encoding utf8
    $deviceId
}

function Get-ClientVersion {
    param($Config)

    if ($null -ne $Config.clientVersion -and -not [string]::IsNullOrWhiteSpace([string]$Config.clientVersion)) {
        return [string]$Config.clientVersion
    }

    return 'windows-ps/1.0'
}

function Get-DeviceType {
    param($Config)

    if ($null -ne $Config.deviceType -and -not [string]::IsNullOrWhiteSpace([string]$Config.deviceType)) {
        return [string]$Config.deviceType
    }

    return 'desktop'
}

function Get-TaskAssignedDeviceId {
    param($Task)

    if ($null -eq $Task) { return $null }

    foreach ($key in @('assigned_device_id', 'target_device_id', 'device_id')) {
        try {
            $value = [string]$Task.$key
            if (-not [string]::IsNullOrWhiteSpace($value)) {
                return $value
            }
        } catch {
        }
    }

    return $null
}

