function New-RunTimestamp {
    Get-Date -Format 'yyyyMMdd-HHmmss'
}

function Ensure-Directory {
    param(
        [Parameter(Mandatory = $true)][string]$Path
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Read-JsonFile {
    param(
        [Parameter(Mandatory = $true)][string]$Path
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        throw "Config file not found: $Path"
    }

    Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json
}

function Resolve-ConfigPath {
    param(
        [Parameter(Mandatory = $true)][string]$RootDir,
        [Parameter(Mandatory = $true)][string]$ConfigPath
    )

    if ([System.IO.Path]::IsPathRooted($ConfigPath)) {
        return $ConfigPath
    }

    return (Join-Path $RootDir $ConfigPath)
}

function Resolve-RelativePath {
    param(
        [Parameter(Mandatory = $true)][string]$RootDir,
        [Parameter(Mandatory = $true)][string]$Path
    )

    if ([System.IO.Path]::IsPathRooted($Path)) {
        return $Path
    }

    return (Join-Path $RootDir $Path)
}

function Resolve-WorkerSettings {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)][string]$RootDir
    )

    $workerIdRaw = Get-ObjectPropertyValue -Object $Config -Name 'workerId' -Default $null
    $hasExplicitWorkerId = ($null -ne $workerIdRaw)
    $workerId = if ($hasExplicitWorkerId) { [Math]::Max([int]$workerIdRaw, 1) } else { 1 }

    $stateDirValue = [string](Get-ObjectPropertyValue -Object $Config -Name 'stateDir' -Default '')
    if (-not [string]::IsNullOrWhiteSpace($stateDirValue)) {
        $stateDir = Resolve-RelativePath -RootDir $RootDir -Path $stateDirValue
    } elseif ($hasExplicitWorkerId) {
        $stateDir = Join-Path $RootDir (Join-Path 'state' "worker$workerId")
    } else {
        $stateDir = Join-Path $RootDir 'state'
    }

    $portValue = Get-ObjectPropertyValue -Object $Config -Name 'remoteDebuggingPort' -Default $null
    if ($null -ne $portValue) {
        $port = [int]$portValue
    } else {
        $port = 9221 + $workerId
    }

    $outputRootValue = [string](Get-ObjectPropertyValue -Object $Config -Name 'outputRoot' -Default '')
    if (-not [string]::IsNullOrWhiteSpace($outputRootValue)) {
        $outputRoot = Resolve-RelativePath -RootDir $RootDir -Path $outputRootValue
    } elseif ($hasExplicitWorkerId) {
        $outputRoot = Join-Path $RootDir (Join-Path 'output' "worker$workerId")
    } else {
        $outputRoot = Join-Path $RootDir 'output'
    }

    $consoleLogSuffix = if ($hasExplicitWorkerId) { "-worker$workerId" } else { '' }

    return [pscustomobject]@{
        WorkerId         = $workerId
        HasExplicitWorkerId = $hasExplicitWorkerId
        StateDir         = $stateDir
        Port             = $port
        OutputRoot       = $outputRoot
        ConsoleLogSuffix = $consoleLogSuffix
    }
}

function Get-LaunchConsoleLogPath {
    param(
        [Parameter(Mandatory = $true)][string]$RootDir,
        [Parameter(Mandatory = $true)][string]$ConfigPath
    )

    try {
        $resolvedConfigPath = Resolve-ConfigPath -RootDir $RootDir -ConfigPath $ConfigPath
        $config = Read-JsonFile -Path $resolvedConfigPath
        $workerSettings = Resolve-WorkerSettings -Config $config -RootDir $RootDir
        return (Join-Path $RootDir ("last-run$($workerSettings.ConsoleLogSuffix).log"))
    } catch {
        return (Join-Path $RootDir 'last-run.log')
    }
}

function Get-ObjectPropertyValue {
    param(
        [AllowNull()]$Object,
        [Parameter(Mandatory = $true)][string]$Name,
        [AllowNull()]$Default = $null
    )

    if ($null -eq $Object) {
        return $Default
    }

    try {
        $prop = $Object.PSObject.Properties[$Name]
        if ($null -eq $prop) {
            return $Default
        }
        return $prop.Value
    } catch {
        return $Default
    }
}

function Normalize-Text {
    param([AllowNull()][string]$Value)

    if ([string]::IsNullOrWhiteSpace($Value)) {
        return ''
    }

    return $Value.Trim().ToLowerInvariant()
}

function Write-RunLog {
    param(
        [Parameter(Mandatory = $true)]$Context,
        [Parameter(Mandatory = $true)][string]$Level,
        [Parameter(Mandatory = $true)][string]$Event,
        [Parameter(Mandatory = $true)][string]$Message,
        [AllowNull()]$Data = $null
    )

    $entry = [ordered]@{
        timestamp = (Get-Date).ToString('o')
        level     = $Level
        event     = $Event
        message   = $Message
    }

    if ($null -ne $Data) {
        $entry.data = $Data
    }

    $json = $entry | ConvertTo-Json -Depth 20 -Compress
    Add-Content -LiteralPath $Context.LogPath -Value $json -Encoding utf8
    Write-Host "[$($entry.timestamp)] [$Level] ${Event}: $Message"
}

function Random-IntInclusive {
    param(
        [Parameter(Mandatory = $true)][int]$Min,
        [Parameter(Mandatory = $true)][int]$Max
    )

    if ($Min -gt $Max) {
        $tmp = $Min
        $Min = $Max
        $Max = $tmp
    }

    return Get-Random -Minimum $Min -Maximum ($Max + 1)
}

function Wait-WithChecks {
    param(
        [Parameter(Mandatory = $true)][int]$DurationMs
    )

    $remaining = $DurationMs
    while ($remaining -gt 0) {
        $chunk = [Math]::Min($remaining, 1000)
        try {
            Start-Sleep -Milliseconds $chunk
        } catch {
            return $false
        }
        $remaining -= $chunk
    }
    return $true
}

function Compute-CurrentRoundNumber {
    param(
        [Parameter(Mandatory = $true)]$Task
    )

    $total = [Math]::Max([int]$Task.repeat, 1)
    $left = [int]$Task.repeat_left
    if ($left -le 0) {
        return $total
    }
    if ($left -gt $total) {
        return 1
    }
    return [Math]::Max(($total - $left + 1), 1)
}

function New-RandomSuffix {
    param([int]$Length = 3)

    $chars = 'abcdefghijklmnopqrstuvwxyz0123456789'
    $builder = New-Object System.Text.StringBuilder
    for ($i = 0; $i -lt $Length; $i++) {
        [void]$builder.Append($chars[(Get-Random -Minimum 0 -Maximum $chars.Length)])
    }
    $builder.ToString()
}

function Write-StepError {
    param(
        [Parameter(Mandatory = $true)][string]$Step,
        [Parameter(Mandatory = $true)]$ErrorRecord,
        [AllowNull()]$Context = $null,
        [string]$Level = 'ERROR'
    )

    $msg = $ErrorRecord.Exception.Message
    $type = $ErrorRecord.Exception.GetType().FullName
    $stack = $ErrorRecord.ScriptStackTrace
    $line = $null
    $command = $null
    try { $line = $ErrorRecord.InvocationInfo.ScriptLineNumber } catch { }
    try { $command = $ErrorRecord.InvocationInfo.Line } catch { }

    Write-Host "[$Level] $Step : $msg"
    if ($null -ne $line) {
        Write-Host "  line: $line"
    }
    if (-not [string]::IsNullOrWhiteSpace([string]$command)) {
        Write-Host "  cmd: $command"
    }
    if (-not [string]::IsNullOrWhiteSpace([string]$stack)) {
        Write-Host $stack
    }

    if ($null -ne $Context) {
        try {
            Write-RunLog -Context $Context -Level $Level -Event 'step_error' -Message "$Step : $msg" -Data @{
                step    = $Step
                error   = $msg
                type    = $type
                line    = $line
                command = $command
                stack   = $stack
            }
        } catch {
        }
    }
}

function Invoke-SafeStep {
    param(
        [Parameter(Mandatory = $true)][string]$Step,
        [Parameter(Mandatory = $true)][scriptblock]$Action,
        [AllowNull()]$Context = $null,
        [AllowNull()]$Default = $null,
        [bool]$Rethrow = $false
    )

    try {
        $result = & $Action
        return [pscustomobject]@{
            Success = $true
            Result  = $result
            Error   = $null
        }
    } catch {
        Write-StepError -Step $Step -ErrorRecord $_ -Context $Context
        if ($Rethrow) {
            throw
        }
        return [pscustomobject]@{
            Success = $false
            Result  = $Default
            Error   = $_
        }
    }
}

function Report-TaskExecutionError {
    param(
        [Parameter(Mandatory = $true)][string]$Step,
        [Parameter(Mandatory = $true)]$ErrorRecord,
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)]$Context,
        [Parameter(Mandatory = $true)]$Task,
        [Parameter(Mandatory = $true)][string]$DeviceId,
        [Parameter(Mandatory = $true)]$Meta
    )

    Write-StepError -Step $Step -ErrorRecord $ErrorRecord -Context $Context

    $roundNumber = 0
    try {
        if ($null -ne $Task) {
            $roundNumber = Compute-CurrentRoundNumber -Task $Task
        }
    } catch {
    }

    try {
        [void](Post-Error -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -ErrorCode 'js_exception' -LogText "$Step failed: $($ErrorRecord.Exception.Message)" -Meta $Meta)
    } catch {
        Write-StepError -Step 'Post-Error' -ErrorRecord $_ -Context $Context -Level 'WARN'
    }

    return [pscustomobject]@{
        success     = $false
        finalStatus = 'error'
        finalLog    = "$Step failed: $($ErrorRecord.Exception.Message)"
        roundNumber = $roundNumber
        stats       = $null
    }
}

