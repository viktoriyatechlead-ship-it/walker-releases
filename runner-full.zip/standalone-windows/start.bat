@echo off
setlocal
cd /d "%~dp0"
title Standalone Windows Runner
start "Worker 1" cmd /c "%~dp0start-worker1.bat"
timeout /t 5 /nobreak >nul
start "Worker 2" cmd /c "%~dp0start-worker2.bat"
endlocal
