# Update.ps1 — самообновление раннера.
# При старте launch.ps1 проверяет version.json на updateUrl, и если на хосте версия
# новее локальной (version.txt) — качает runner.zip, накатывает поверх (НЕ трогая
# config*.json / state / output) и перезапускает раннер. Любая ошибка/нет сети —
# тихо продолжаем на текущей версии (раннер никогда не падает из-за апдейтера).

function Get-LocalRunnerVersion {
    param([Parameter(Mandatory = $true)][string]$RootDir)
    $vf = Join-Path $RootDir 'version.txt'
    if (Test-Path -LiteralPath $vf) {
        $v = Get-Content -LiteralPath $vf -Raw -ErrorAction SilentlyContinue
        if (-not [string]::IsNullOrWhiteSpace([string]$v)) { return ([string]$v).Trim() }
    }
    return '0.0.0'
}

function ConvertTo-VersionOrNull {
    param([string]$Text)
    if ([string]::IsNullOrWhiteSpace($Text)) { return $null }
    $clean = ($Text.Trim() -replace '^[vV]', '')
    $parsed = $null
    if ([version]::TryParse($clean, [ref]$parsed)) { return $parsed }
    return $null
}

function Invoke-SelfUpdate {
    param(
        [Parameter(Mandatory = $true)][string]$RootDir,
        [Parameter(Mandatory = $true)][string]$ConfigPath
    )

    try {
        $resolvedConfigPath = Resolve-ConfigPath -RootDir $RootDir -ConfigPath $ConfigPath
        $cfg = Read-JsonFile -Path $resolvedConfigPath
    } catch {
        Write-Host "UPDATE: не смог прочитать конфиг, пропускаю обновление ($($_.Exception.Message))"
        return
    }

    $updateUrl = [string](Get-ObjectPropertyValue -Object $cfg -Name 'updateUrl' -Default '')
    if ([string]::IsNullOrWhiteSpace($updateUrl)) { return }   # авто-апдейт выключен
    $updateUrl = $updateUrl.TrimEnd('/')

    $localVersion = Get-LocalRunnerVersion -RootDir $RootDir
    Write-Host "UPDATE: локальная версия $localVersion, проверяю $updateUrl/version.json ..."

    try {
        $manifest = Invoke-RestMethod -Uri "$updateUrl/version.json" -Method Get -TimeoutSec 12
    } catch {
        Write-Host "UPDATE: манифест недоступен, продолжаю на текущей версии ($($_.Exception.Message))"
        return
    }

    $remoteVersionText = [string](Get-ObjectPropertyValue -Object $manifest -Name 'version' -Default '')
    $remoteVer = ConvertTo-VersionOrNull -Text $remoteVersionText
    $localVer = ConvertTo-VersionOrNull -Text $localVersion
    if ($null -eq $remoteVer) {
        Write-Host "UPDATE: некорректная версия на хосте '$remoteVersionText', пропускаю"
        return
    }
    if ($null -ne $localVer -and $remoteVer -le $localVer) {
        Write-Host "UPDATE: уже актуальная версия ($localVersion)"
        return
    }

    $zipUrl = [string](Get-ObjectPropertyValue -Object $manifest -Name 'zipUrl' -Default '')
    if ([string]::IsNullOrWhiteSpace($zipUrl)) { $zipUrl = "$updateUrl/runner.zip" }
    $sha256 = [string](Get-ObjectPropertyValue -Object $manifest -Name 'sha256' -Default '')

    Write-Host "UPDATE: доступна новая версия $remoteVersionText — скачиваю $zipUrl"

    $tmpBase = Join-Path ([System.IO.Path]::GetTempPath()) ('walker-update-' + [Guid]::NewGuid().ToString('N'))
    $zipPath = "$tmpBase.zip"
    $extractDir = $tmpBase

    try {
        $oldProgress = $ProgressPreference
        $ProgressPreference = 'SilentlyContinue'
        Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -TimeoutSec 180 -UseBasicParsing
        $ProgressPreference = $oldProgress
    } catch {
        Write-Host "UPDATE: скачать не удалось, продолжаю на текущей версии ($($_.Exception.Message))"
        return
    }

    if (-not [string]::IsNullOrWhiteSpace($sha256)) {
        try {
            $actual = (Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash
            if ($actual -ne $sha256.Trim().ToUpper()) {
                Write-Host "UPDATE: не сошлась контрольная сумма — отмена (ждал $sha256, получил $actual)"
                Remove-Item -LiteralPath $zipPath -Force -ErrorAction SilentlyContinue
                return
            }
        } catch {}
    }

    try {
        if (Test-Path -LiteralPath $extractDir) { Remove-Item -LiteralPath $extractDir -Recurse -Force -ErrorAction SilentlyContinue }
        Expand-Archive -LiteralPath $zipPath -DestinationPath $extractDir -Force
    } catch {
        Write-Host "UPDATE: распаковка не удалась, продолжаю на текущей версии ($($_.Exception.Message))"
        Remove-Item -LiteralPath $zipPath -Force -ErrorAction SilentlyContinue
        return
    }

    # Если архив завёрнут в одну верхнюю папку — спускаемся в неё.
    $srcRoot = $extractDir
    $topItems = @(Get-ChildItem -LiteralPath $extractDir -Force)
    if ($topItems.Count -eq 1 -and $topItems[0].PSIsContainer) { $srcRoot = $topItems[0].FullName }

    # Эти файлы/папки НЕ перетираем (локальные настройки, состояние, логи).
    $preserve = @('config.json', 'config.worker1.json', 'config.worker2.json')
    try {
        Get-ChildItem -LiteralPath $srcRoot -Recurse -Force | ForEach-Object {
            $rel = $_.FullName.Substring($srcRoot.Length).TrimStart('\', '/')
            if ([string]::IsNullOrWhiteSpace($rel)) { return }
            $relLower = $rel.ToLower()
            if ($relLower -like 'state*' -or $relLower -like 'output*' -or $relLower -like '.git*') { return }
            if ($preserve -contains $rel) { return }
            $dest = Join-Path $RootDir $rel
            if ($_.PSIsContainer) {
                Ensure-Directory -Path $dest
            } else {
                Ensure-Directory -Path (Split-Path -Parent $dest)
                Copy-Item -LiteralPath $_.FullName -Destination $dest -Force
            }
        }
        Set-Content -LiteralPath (Join-Path $RootDir 'version.txt') -Value $remoteVersionText -NoNewline -Encoding ASCII
        Write-Host "UPDATE: версия $remoteVersionText установлена, перезапускаю раннер ..."
    } catch {
        Write-Host "UPDATE: накатить не удалось, продолжаю на текущей версии ($($_.Exception.Message))"
        Remove-Item -LiteralPath $zipPath -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $extractDir -Recurse -Force -ErrorAction SilentlyContinue
        return
    }

    Remove-Item -LiteralPath $zipPath -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $extractDir -Recurse -Force -ErrorAction SilentlyContinue

    # Перезапуск обновлённого лаунчера и выход текущего процесса.
    $launchPath = Join-Path $RootDir 'launch.ps1'
    try {
        $psExe = (Get-Process -Id $PID).Path
        if ([string]::IsNullOrWhiteSpace([string]$psExe)) { $psExe = 'powershell.exe' }
        Start-Process -FilePath $psExe -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $launchPath, '-ConfigPath', $ConfigPath)
    } catch {
        Write-Host "UPDATE: не смог перезапустить ($($_.Exception.Message)) — перезапусти раннер вручную"
    }
    exit 0
}
