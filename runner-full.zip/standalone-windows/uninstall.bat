@echo off
chcp 65001 >nul

echo.
echo  ==========================================
echo   VMOS Desktop Runner — Удаление
echo  ==========================================
echo.

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo  [ОШИБКА] Запустите от имени администратора
    pause
    exit /b 1
)

echo  Останавливаем раннер...
taskkill /F /IM wscript.exe /FI "IMAGENAME eq wscript.exe" >nul 2>&1

echo  Удаляем задачу автозапуска...
schtasks /delete /tn "VMOS Runner" /f >nul 2>&1

echo  Удаляем файлы...
if exist "C:\VMOS" rmdir /S /Q "C:\VMOS"

echo.
echo  Удалено. До свидания.
echo.
pause
