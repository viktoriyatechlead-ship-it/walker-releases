function Invoke-BehaviorProfileTask {
    param(        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)]$Context,
        [Parameter(Mandatory = $true)]$Task,
        [Parameter(Mandatory = $true)][string]$DeviceId,
        [Parameter(Mandatory = $true)]$Meta
    )

    try {
    $profile = Get-BehaviorProfile -Task $Task
    if ($null -eq $profile) {
        return Invoke-OpenUrlTask -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -Meta $Meta
    }

    if (Test-ProfileIsEffectivelyEmpty -Profile $profile) {
        return Invoke-OpenUrlTask -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -Meta $Meta
    }

    $macroEnabled = Get-ProfileMacroEnabled -Profile $profile
    $bannerRulesEnabled = Get-ProfileBannerRulesEnabled -Profile $profile
    $url = [string]$Task.url
    if ([string]::IsNullOrWhiteSpace($url)) {
        [void](Post-Error -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -ErrorCode 'js_exception' -LogText 'behavior_profile: url is null' -Meta $Meta)
        return [pscustomobject]@{ success = $false; finalStatus = 'error'; finalLog = 'URL is null'; roundNumber = 0; stats = $null }
    }

    $roundNumber = Compute-CurrentRoundNumber -Task $Task
    $repeatTotal = [Math]::Max([int]$Task.repeat, 1)
    $visitMin = [Math]::Max([int]$Task.visit_min, 1)
    $visitMax = [Math]::Max([int]$Task.visit_max, $visitMin)
    $defaultVisitSeconds = Random-IntInclusive -Min $visitMin -Max $visitMax
    if ($macroEnabled -and ($null -eq $profile.macro -or $null -eq $profile.macro.steps -or @($profile.macro.steps).Count -eq 0)) {
        [void](Post-Error -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -ErrorCode 'config_error' -LogText 'macro_enabled=true but macro.steps is missing' -Meta ([pscustomobject]@{ reason = 'macro_missing'; behavior_profile_name = (Get-ProfileName -Profile $profile); behavior_profile_slug = (Get-ProfileSlug -Profile $profile) }))
        return [pscustomobject]@{ success = $false; finalStatus = 'error'; finalLog = 'macro_enabled=true but macro.steps is missing'; roundNumber = $roundNumber; stats = $null }
    }
    if ($bannerRulesEnabled -and ($null -eq $profile.banner_rules -or @($profile.banner_rules).Count -eq 0)) {
        [void](Post-Error -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -ErrorCode 'config_error' -LogText 'banner_rules_enabled=true but banner_rules is empty' -Meta ([pscustomobject]@{ reason = 'banner_rules_missing'; behavior_profile_name = (Get-ProfileName -Profile $profile); behavior_profile_slug = (Get-ProfileSlug -Profile $profile) }))
        return [pscustomobject]@{ success = $false; finalStatus = 'error'; finalLog = 'banner_rules_enabled=true but banner_rules is empty'; roundNumber = $roundNumber; stats = $null }
    }
    $bannerSelectors = Get-BannerSelectors -Profile $profile -BannerRulesEnabled $bannerRulesEnabled
    $blockedRegions = Convert-ToRectList -Profile $profile -BannerRulesEnabled $bannerRulesEnabled
    $errorKeywords = Get-ErrorKeywords -Profile $profile -BannerRulesEnabled $bannerRulesEnabled
    $macroSteps = Get-BehaviorMacroSteps -Profile $profile -Task $Task -DefaultVisitSeconds $defaultVisitSeconds -MacroEnabled $macroEnabled
    $taskMeta = New-TaskProfileMeta -Config $Config -Task $Task -Profile $profile -DeviceId $DeviceId -SessionId $Meta.session_id -RoundNumber $roundNumber -RepeatTotal $repeatTotal -MacroEnabled $macroEnabled -BannerRulesEnabled $bannerRulesEnabled
    $taskMeta | Add-Member -NotePropertyName 'task_url' -NotePropertyValue $url -Force
    $taskMeta | Add-Member -NotePropertyName 'macro_step_count' -NotePropertyValue $macroSteps.Count -Force
    $taskMeta | Add-Member -NotePropertyName 'banner_rule_count' -NotePropertyValue (@($profile.banner_rules).Count) -Force
    $taskMeta | Add-Member -NotePropertyName 'target_domain_count' -NotePropertyValue (@($profile.target_domains).Count) -Force
    $taskMeta | Add-Member -NotePropertyName 'macro_enabled' -NotePropertyValue $macroEnabled -Force
    $taskMeta | Add-Member -NotePropertyName 'banner_rules_enabled' -NotePropertyValue $bannerRulesEnabled -Force

    [void](Post-Start -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -Meta $taskMeta)
    Write-RunLog -Context $Context -Level 'INFO' -Event 'task_start' -Message "Macro profile started for task $($Task.id)" -Data @{ task_id = $Task.id; profile = (Get-ProfileSlug -Profile $profile); version = (Get-ProfileVersion -Profile $profile) }

    Clear-WebState -Url $url
    try { Navigate-ToUrl -Url $url } catch {
        [void](Post-Error -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -ErrorCode 'network_timeout' -LogText "Navigation failed: $($_.Exception.Message)" -Meta $taskMeta)
        return [pscustomobject]@{ success = $false; finalStatus = 'error'; finalLog = "Navigation failed: $($_.Exception.Message)"; roundNumber = $roundNumber; stats = $null }
    }

    if (-not (Wait-ForPageReadyInteractive -TimeoutSec ([int]$Config.webViewReadyTimeoutSec))) {
        $errorMeta = [pscustomobject]@{ round = $roundNumber; total_rounds = $repeatTotal; step = 'wait_ready' }
        $screenshotPath = Capture-ErrorScreenshot -Context $Context -Config $Config -Task $Task -DeviceId $DeviceId -RoundNumber $roundNumber -StepName 'webview_not_ready' -ErrorCode 'webview_not_ready'
        if ($null -ne $screenshotPath) { $errorMeta | Add-Member -NotePropertyName 'screenshot_path' -NotePropertyValue $screenshotPath -Force }
        [void](Post-Error -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -ErrorCode 'webview_not_ready' -LogText "WebView not ready on round $roundNumber" -Meta $errorMeta)
        return [pscustomobject]@{ success = $false; finalStatus = 'error'; finalLog = "WebView not ready on round $roundNumber"; roundNumber = $roundNumber; stats = $null }
    }

    if (-not (Wait-ForPageLoaded -TimeoutSec ([int]$Config.pageReadyTimeoutSec))) {
        $errorMeta = [pscustomobject]@{ round = $roundNumber; total_rounds = $repeatTotal; step = 'wait_ready' }
        $screenshotPath = Capture-ErrorScreenshot -Context $Context -Config $Config -Task $Task -DeviceId $DeviceId -RoundNumber $roundNumber -StepName 'page_not_loaded' -ErrorCode 'page_not_loaded'
        if ($null -ne $screenshotPath) { $errorMeta | Add-Member -NotePropertyName 'screenshot_path' -NotePropertyValue $screenshotPath -Force }
        [void](Post-Error -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -ErrorCode 'page_not_loaded' -LogText "Page not loaded on round $roundNumber" -Meta $errorMeta)
        return [pscustomobject]@{ success = $false; finalStatus = 'error'; finalLog = "Page not loaded on round $roundNumber"; roundNumber = $roundNumber; stats = $null }
    }

    $pageProbe = Get-PageProbe -Config $Config -BannerSelectors $bannerSelectors -ErrorKeywords $errorKeywords
    $pageLoadError = Get-PageLoadErrorCode -Probe $pageProbe
    if ($null -ne $pageLoadError) {
        $logText = "Browser error page on round ${roundNumber}: $($pageProbe.title) $($pageProbe.bodySample)"
        if ($pageLoadError -eq 'ssl_error') {
            Trace-DeviceLog -Config $Config -Context $Context -DeviceId $DeviceId -TaskId $Task.id -Level 'WARN' -EventType 'ssl_warning' -Message 'SSL warning detected' -Meta ([pscustomobject]@{
                task_id = $Task.id
                round = $roundNumber
                url = $url
                title = $pageProbe.title
            })
        }
        $errorMeta = [pscustomobject]@{
            round = $roundNumber
            total_rounds = $repeatTotal
            url = $url
            error_code = $pageLoadError
        }
        $errorMeta = Apply-PageProbeMeta -Meta $errorMeta -Probe $pageProbe
        $screenshotPath = Capture-ErrorScreenshot -Context $Context -Config $Config -Task $Task -DeviceId $DeviceId -RoundNumber $roundNumber -StepName "browser_error_$pageLoadError" -ErrorCode $pageLoadError
        if ($null -ne $screenshotPath) { $errorMeta | Add-Member -NotePropertyName 'screenshot_path' -NotePropertyValue $screenshotPath -Force }
        [void](Post-Error -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -ErrorCode $pageLoadError -LogText $logText -Meta $errorMeta)
        return [pscustomobject]@{ success = $false; finalStatus = 'error'; finalLog = $logText; roundNumber = $roundNumber; stats = $null }
    }

    $probe = Collect-StablePageProbe -Config $Config -PageUrl $url -BannerSelectors $bannerSelectors -ErrorKeywords $errorKeywords
    [void](Invoke-ApiPostJson -Config $Config -Path '/task/event' -Payload ([ordered]@{ task_id = $Task.id; device_id = $DeviceId; event_type = 'step_started'; log = 'macro started'; meta = $taskMeta }) -Context $Context -EventName 'step_started')

    $cookieClosed = $false
    $stats = $null
    $screenshotPath = $null

    for ($i = 0; $i -lt $macroSteps.Count; $i++) {
        $step = $macroSteps[$i]
        $stepType = ([string]$step.type).ToLowerInvariant()
        $stepMeta = New-TaskProfileMeta -Config $Config -Task $Task -Profile $profile -DeviceId $DeviceId -SessionId $Meta.session_id -RoundNumber $roundNumber -RepeatTotal $repeatTotal -MacroEnabled $macroEnabled -BannerRulesEnabled $bannerRulesEnabled
        $stepMeta | Add-Member -NotePropertyName 'step' -NotePropertyValue $stepType -Force
        $stepMeta | Add-Member -NotePropertyName 'step_index' -NotePropertyValue $i -Force

        [void](Invoke-ApiPostJson -Config $Config -Path '/task/event' -Payload ([ordered]@{ task_id = $Task.id; device_id = $DeviceId; event_type = 'step_started'; log = "step[$i]=$stepType started"; meta = $stepMeta }) -Context $Context -EventName 'step_started')

        $stepSuccess = $true
        $stepError = $null

        try {
            switch ($stepType) {
                'open_url' {
                    if (-not [string]::IsNullOrWhiteSpace([string]$step.url)) { Navigate-ToUrl -Url ([string]$step.url) }
                }
                'wait_ready' {
                    $webT = if ($null -ne $step.webview_timeout_sec) { [int]$step.webview_timeout_sec } else { [int]$Config.webViewReadyTimeoutSec }
                    $pageT = if ($null -ne $step.page_timeout_sec) { [int]$step.page_timeout_sec } else { [int]$Config.pageReadyTimeoutSec }
                    $humanMs = if ($null -ne $step.human_wait_ms) { [int]$step.human_wait_ms } else { [int]$Config.pageReadyForHumanMaxWaitMs }
                    if (-not (Wait-ForPageReadyInteractive -TimeoutSec $webT)) { throw 'webview_not_ready' }
                    if (-not (Wait-ForPageLoaded -TimeoutSec $pageT)) { throw 'page_not_loaded' }
                    Wait-ForPageReadyForHuman -MaxWaitMs $humanMs | Out-Null
                }
                'scan_banners' {
                    $probe = Get-PageProbe -Config $Config -BannerSelectors $bannerSelectors -ErrorKeywords $errorKeywords
                    $stepMeta | Add-Member -NotePropertyName 'banner_count' -NotePropertyValue $probe.bannerCount -Force
                }
                'accept_cookie' {
                    $selectors = @()
                    if ($null -ne $step.selectors) { $selectors = @($step.selectors) }
                    $cookieSelector = $null
                    if ($selectors.Count -gt 0) {
                        $selectorsJson = @($selectors) | ConvertTo-Json -Compress
                        $cookieJs = @"
(() => {
  const selectors = $selectorsJson;
  for (const selector of selectors) {
    try {
      const el = document.querySelector(selector);
      if (el) {
        el.click();
        return JSON.stringify({ clicked: true, selector });
      }
    } catch (e) {}
  }
  return null;
})()
"@
                        $raw = Invoke-CdpEvaluate -Expression $cookieJs -TimeoutSec 4
                        if ($null -ne $raw -and $raw -ne 'null') {
                            $cookieObj = $raw | ConvertFrom-Json
                            if ($cookieObj.clicked) { $cookieSelector = $cookieObj.selector }
                        }
                    }
                    if ($null -eq $cookieSelector) {
                        $cookieJs = @'
(() => {
  const selectors = ['button','[role="button"]','a','input[type="button"]','input[type="submit"]'];
  const score = (el) => {
    const text = (el.innerText || el.value || '').toString().trim().toLowerCase();
    if (!text) return 0;
    let s = 0;
    if (text.includes('accept') || text.includes('agree') || text.includes('allow')) s += 5;
    if (text.includes('cookie')) s += 3;
    if (text.includes('all')) s += 1;
    return s;
  };
  let best = null;
  for (const selector of selectors) {
    document.querySelectorAll(selector).forEach(el => {
      const s = score(el);
      if (s >= 5 && !best) {
        best = el;
      }
    });
  }
  if (best) {
    best.click();
    return JSON.stringify({ clicked: true, selector: 'auto-cookie-js' });
  }
  return null;
})()
'@
                        $raw = Invoke-CdpEvaluate -Expression $cookieJs -TimeoutSec 4
                        if ($null -ne $raw -and $raw -ne 'null') {
                            $cookieObj = $raw | ConvertFrom-Json
                            if ($cookieObj.clicked) { $cookieSelector = $cookieObj.selector }
                        }
                    }
                    if ($null -ne $cookieSelector) {
                        $cookieClosed = $true
                        [void](Invoke-ApiPostJson -Config $Config -Path '/task/event' -Payload ([ordered]@{ task_id = $Task.id; device_id = $DeviceId; event_type = 'cookie_banner'; log = "Cookie popup closed (selector=$cookieSelector)"; meta = $stepMeta }) -Context $Context -EventName 'cookie_banner')
                    }
                }
                'human_behavior' {
                    $visitSec = if ($null -ne $step.visit_seconds) { [int]$step.visit_seconds } else { $defaultVisitSeconds }
                    $allowClicks = if ($null -ne $step.allow_clicks) { [bool]$step.allow_clicks } else { [bool]$Task.allow_clicks }
                    $allowBannerClicks = if ($null -ne $step.allow_banner_clicks) { [bool]$step.allow_banner_clicks } else { [bool]$Task.click_banner }
                    $stats = Invoke-HumanBehavior -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -Meta $taskMeta -TaskId $Task.id -RoundNumber $roundNumber -VisitSeconds $visitSec -AllowClicks $allowClicks -AllowBannerClicks $allowBannerClicks -CookieAlreadyClosed $cookieClosed -BlockedRegions $blockedRegions -BannerSelectors $bannerSelectors -ErrorKeywords $errorKeywords
                    if ($stats.aborted) { throw $stats.abortReason }
                }
                'assert_no_error' {
                    $probe = Get-PageProbe -Config $Config -BannerSelectors $bannerSelectors -ErrorKeywords $errorKeywords
                    if ((@($probe.errorHits)).Count -gt 0 -or [string]::IsNullOrWhiteSpace([string]$probe.bodySample)) {
                        $screenshotPath = Capture-PageShot -Context $Context -Prefix "task_${($Task.id)}_round_${roundNumber}_assert_no_error" -Config $Config -Task $Task -DeviceId $DeviceId -RoundNumber $roundNumber -ErrorCode 'js_exception'
                        throw 'js_exception'
                    }
                }
                'assert_transition' {
                    $probe = Get-PageProbe -Config $Config -BannerSelectors $bannerSelectors -ErrorKeywords $errorKeywords
                    $expectedUrl = [string]$step.url_contains
                    $expectedTitle = [string]$step.title_contains
                    $okUrl = [string]::IsNullOrWhiteSpace($expectedUrl) -or ([string]$probe.url).Contains($expectedUrl)
                    $okTitle = [string]::IsNullOrWhiteSpace($expectedTitle) -or ([string]$probe.title).Contains($expectedTitle)
                    if (-not ($okUrl -and $okTitle)) {
                        $screenshotPath = Capture-PageShot -Context $Context -Prefix "task_${($Task.id)}_round_${roundNumber}_assert_transition" -Config $Config -Task $Task -DeviceId $DeviceId -RoundNumber $roundNumber -ErrorCode 'transition_failed'
                        throw 'transition_failed'
                    }
                }
                'screenshot' {
                    $screenshotPath = Capture-PageShot -Context $Context -Prefix "task_${($Task.id)}_round_${roundNumber}_step_${i}" -Config $Config -Task $Task -DeviceId $DeviceId -RoundNumber $roundNumber -ErrorCode 'js_exception'
                    if ($null -eq $screenshotPath) { throw 'js_exception' }
                }
                'post_event' {
                    $eventType = if ($null -ne $step.event_type) { [string]$step.event_type } else { 'task_event' }
                    $logText = if ($null -ne $step.log) { [string]$step.log } else { 'macro event' }
                    [void](Invoke-ApiPostJson -Config $Config -Path '/task/event' -Payload ([ordered]@{ task_id = $Task.id; device_id = $DeviceId; event_type = $eventType; log = $logText; meta = $stepMeta }) -Context $Context -EventName $eventType)
                }
                'wait' {
                    $waitMs = if ($null -ne $step.ms) { [int]$step.ms } elseif ($null -ne $step.seconds) { [int]$step.seconds * 1000 } else { 1000 }
                    Wait-WithChecks -DurationMs $waitMs | Out-Null
                }
                'clear_state' { Clear-WebState -Url $url }
                'close_webview' {
                    try { Navigate-ToUrl -Url 'about:blank' } catch { }
                    Close-WebView
                }
                default {
                    [void](Invoke-ApiPostJson -Config $Config -Path '/task/event' -Payload ([ordered]@{ task_id = $Task.id; device_id = $DeviceId; event_type = 'unknown_step'; log = "Unknown macro step: $stepType"; meta = $stepMeta }) -Context $Context -EventName 'unknown_step')
                }
            }
        } catch {
            $stepSuccess = $false
            $stepError = if ($_.Exception.Message) { $_.Exception.Message } else { [string]$_ }
            if ($null -ne $screenshotPath) { $stepMeta | Add-Member -NotePropertyName 'screenshot_path' -NotePropertyValue $screenshotPath -Force }
            $stepMeta | Add-Member -NotePropertyName 'error_code' -NotePropertyValue $stepError -Force
            [void](Invoke-ApiPostJson -Config $Config -Path '/task/error' -Payload ([ordered]@{ task_id = $Task.id; device_id = $DeviceId; error = $stepError; log = "step[$i]=$stepType failed: $stepError"; event_type = 'task_error'; meta = $stepMeta }) -Context $Context -EventName 'task_error')
        }

        if (-not $stepSuccess) {
            [void](Invoke-ApiPostJson -Config $Config -Path '/task/event' -Payload ([ordered]@{ task_id = $Task.id; device_id = $DeviceId; event_type = 'step_failed'; log = "step[$i]=$stepType failed: $stepError"; meta = $stepMeta }) -Context $Context -EventName 'step_failed')
            return [pscustomobject]@{ success = $false; finalStatus = 'error'; finalLog = "step[$i]=$stepType failed: $stepError"; roundNumber = $roundNumber; stats = $stats }
        }

        [void](Invoke-ApiPostJson -Config $Config -Path '/task/event' -Payload ([ordered]@{ task_id = $Task.id; device_id = $DeviceId; event_type = 'step_done'; log = "step[$i]=$stepType done"; meta = $stepMeta }) -Context $Context -EventName 'step_done')
    }

    try { Navigate-ToUrl -Url 'about:blank' } catch { }
    Clear-WebState -Url $url

    $completionMeta = New-TaskProfileMeta -Config $Config -Task $Task -Profile $profile -DeviceId $DeviceId -SessionId $Meta.session_id -RoundNumber $roundNumber -RepeatTotal $repeatTotal -MacroEnabled $macroEnabled -BannerRulesEnabled $bannerRulesEnabled
    $completionMeta | Add-Member -NotePropertyName 'successful_rounds' -NotePropertyValue 1 -Force
    $completionMeta | Add-Member -NotePropertyName 'planned_rounds' -NotePropertyValue $Task.repeat -Force
    $completionMeta | Add-Member -NotePropertyName 'allow_clicks' -NotePropertyValue ([bool]$Task.allow_clicks) -Force
    $completionMeta | Add-Member -NotePropertyName 'allow_banner_clicks' -NotePropertyValue ([bool]$Task.click_banner) -Force
    if ($null -ne $stats) {
        $completionMeta | Add-Member -NotePropertyName 'banner_avoids' -NotePropertyValue $stats.bannerAvoids -Force
        $completionMeta | Add-Member -NotePropertyName 'scrolls' -NotePropertyValue $stats.scrolls -Force
        $completionMeta | Add-Member -NotePropertyName 'taps' -NotePropertyValue $stats.taps -Force
        $completionMeta | Add-Member -NotePropertyName 'idles' -NotePropertyValue $stats.idles -Force
        $completionMeta | Add-Member -NotePropertyName 'planned_visit_sec' -NotePropertyValue $stats.plannedVisitSec -Force
        $completionMeta | Add-Member -NotePropertyName 'actual_visit_sec' -NotePropertyValue $stats.actualVisitSec -Force
    }
    if ($null -ne $screenshotPath) { $completionMeta | Add-Member -NotePropertyName 'screenshot_path' -NotePropertyValue $screenshotPath -Force }

    return [pscustomobject]@{ success = $true; finalStatus = 'completed'; finalLog = 'Macro profile completed'; roundNumber = $roundNumber; stats = $stats; completionMeta = $completionMeta }
    } catch {
        return (Report-TaskExecutionError -Step 'Invoke-BehaviorProfileTask' -ErrorRecord $_ -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -Meta $Meta)
    }
}

function Invoke-HumanBehavior {
    param(        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)]$Context,
        [Parameter(Mandatory = $true)]$Task,
        [Parameter(Mandatory = $true)][string]$DeviceId,
        [Parameter(Mandatory = $true)]$Meta,
        [Parameter(Mandatory = $true)][int]$TaskId,
        [Parameter(Mandatory = $true)][int]$RoundNumber,
        [Parameter(Mandatory = $true)][int]$VisitSeconds,
        [Parameter(Mandatory = $true)][bool]$AllowClicks,
        [Parameter(Mandatory = $true)][bool]$AllowBannerClicks,
        [Parameter(Mandatory = $true)][bool]$CookieAlreadyClosed,
        [Parameter(Mandatory = $true)]$BlockedRegions,
        [string[]]$BannerSelectors = $null,
        [string[]]$ErrorKeywords = $null
    )

    $endAt = (Get-Date).AddSeconds($VisitSeconds)
    $startAt = Get-Date
    $scrolls = 0
    $taps = 0
    $idles = 0
    $bannerAvoids = 0
    $aborted = $false
    $abortReason = $null
    $lostFocusSince = $null
    $bannerEventLogged = $false
    $cookieEventLogged = $CookieAlreadyClosed
    $lastCookieCheck = [DateTime]::MinValue
    $lastHeartbeat = Get-Date
    $guaranteedFirstAction = $false
    $interactionCount = 0

    Start-Sleep -Milliseconds (Random-IntInclusive -Min 500 -Max 2500)

    while ((Get-Date) -lt $endAt) {
        if (-not (Test-PageIsVisibleForHuman)) {
            $now = Get-Date
            if ($null -eq $lostFocusSince) {
                $lostFocusSince = $now
            } elseif (((Get-Date) - $lostFocusSince).TotalSeconds -gt 15) {
                $aborted = $true
                $abortReason = 'webview_lost_focus'
                break
            }
            Start-Sleep -Milliseconds 500
            continue
        }

        $lostFocusSince = $null

        if (-not (Wait-ForPageLoaded -TimeoutSec 1)) {
            Start-Sleep -Milliseconds 500
            continue
        }

        if (-not $cookieEventLogged) {
            if ($lastCookieCheck -eq [DateTime]::MinValue -or ((Get-Date) - $lastCookieCheck).TotalSeconds -ge 3) {
                $lastCookieCheck = Get-Date
                $selector = Accept-KnownCookiePopup -Context $Context
                if ($null -ne $selector) {
                    $cookieEventLogged = $true
                    Log-CookieEvent -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -RoundNumber $RoundNumber -Selector $selector -Meta $Meta
                } else {
                    $accepted = Accept-CookiesIfNeeded -Context $Context
                    if ($accepted) {
                        $cookieEventLogged = $true
                        Log-CookieEvent -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -RoundNumber $RoundNumber -Selector 'auto-cookie-js' -Meta $Meta
                    }
                }
            }
        }

        if (((Get-Date) - $lastHeartbeat).TotalSeconds -ge ([int]$Config.heartbeatIntervalSec)) {
            $progress = [Math]::Min([int](((Get-Date) - ($endAt.AddSeconds(-$VisitSeconds))).TotalSeconds * 100 / [Math]::Max($VisitSeconds, 1)), 100)
            Send-Heartbeat -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -Meta $Meta -Status 'in_progress' -LogText "round #$RoundNumber/$($Task.repeat) ping" -EventType 'round_ping' -RepeatDone ([Math]::Max($RoundNumber - 1, 0)) -RepeatTotal ([int]$Task.repeat) -ProgressPercent $progress -Force $true
            $lastHeartbeat = Get-Date
        }

        if (-not $guaranteedFirstAction) {
            $guaranteedFirstAction = $true
            $delta = Random-IntInclusive -Min 500 -Max 1200
            if ((Get-Random -Minimum 0 -Maximum 2) -eq 0) {
                $delta = -$delta
            }
            $scrolls++
            $interactionCount++
            try {
                Invoke-PageScrollBy -DeltaY $delta | Out-Null
                Write-Host "[human] scroll delta=$delta (guaranteed)"
                Write-RunLog -Context $Context -Level 'INFO' -Event 'human_action' -Message "scroll delta=$delta" -Data @{ action = 'scroll'; delta = $delta; phase = 'guaranteed' }
            } catch {
                Write-StepError -Step 'human.guaranteed_scroll' -ErrorRecord $_ -Context $Context -Level 'WARN'
            }
            Start-Sleep -Milliseconds (Random-IntInclusive -Min 500 -Max 1200)
            continue
        }

        $elapsedMs = [int](((Get-Date) - $startAt).TotalMilliseconds)
        if ($interactionCount -eq 0 -and $elapsedMs -gt 4000) {
            $delta = Random-IntInclusive -Min 450 -Max 1000
            if ((Get-Random -Minimum 0 -Maximum 2) -eq 0) {
                $delta = -$delta
            }
            $scrolls++
            $interactionCount++
            try {
                Invoke-PageScrollBy -DeltaY $delta | Out-Null
                Write-Host "[human] scroll delta=$delta (forced)"
                Write-RunLog -Context $Context -Level 'INFO' -Event 'human_action' -Message "scroll delta=$delta" -Data @{ action = 'scroll'; delta = $delta; phase = 'forced' }
            } catch {
                Write-StepError -Step 'human.forced_scroll' -ErrorRecord $_ -Context $Context -Level 'WARN'
            }
            Start-Sleep -Milliseconds (Random-IntInclusive -Min 400 -Max 900)
            continue
        }

        try {
            Restore-MainBrowserTab -PopupSettleMs 0
        } catch {
        }

        $actionRoll = Get-Random -Minimum 0 -Maximum 100
        if ($actionRoll -lt 60) {
            $delta = Random-IntInclusive -Min 400 -Max 1200
            if ((Get-Random -Minimum 0 -Maximum 2) -eq 0) {
                $delta = -$delta
            }
            $scrolls++
            $interactionCount++
            try {
                Invoke-PageScrollBy -DeltaY $delta | Out-Null
                try { Invoke-CdpMouseWander | Out-Null } catch {}
                Write-Host "[human] scroll delta=$delta"
                Write-RunLog -Context $Context -Level 'INFO' -Event 'human_action' -Message "scroll delta=$delta" -Data @{ action = 'scroll'; delta = $delta; phase = 'random' }
            } catch {
                Write-StepError -Step 'human.scroll' -ErrorRecord $_ -Context $Context -Level 'WARN'
            }
        } elseif ($actionRoll -lt 85 -and $AllowClicks) {
            $probe = Get-PageProbe -Config $Config -BannerSelectors $BannerSelectors -ErrorKeywords $ErrorKeywords
            $coords = Select-SafeTapCoordinates -Probe $probe -AllowBannerClicks $AllowBannerClicks -BlockedRegions $BlockedRegions
            if ($null -ne $coords) {
                $taps++
                $interactionCount++
                try {
                    Invoke-PageClickAt -X ([int]$coords.x) -Y ([int]$coords.y)
                    Write-Host "[human] tap x=$([int]$coords.x) y=$([int]$coords.y)"
                    Write-RunLog -Context $Context -Level 'INFO' -Event 'human_action' -Message "tap x=$([int]$coords.x) y=$([int]$coords.y)" -Data @{ action = 'tap'; x = [int]$coords.x; y = [int]$coords.y }
                } catch {
                    Write-StepError -Step 'human.tap' -ErrorRecord $_ -Context $Context -Level 'WARN'
                }
            } else {
                $bannerAvoids++
                if (-not $bannerEventLogged) {
                    $bannerEventLogged = $true
                    $bannerCount = [int](Get-ObjectPropertyValue -Object $probe -Name 'bannerCount' -Default 0)
                    [void](Post-Event -Config $Config -Context $Context -Path '/task/event' -TaskId $Task.id -DeviceId $DeviceId -EventType 'banner_tap_blocked' -LogText 'Tap skipped due to banner detection' -Meta ([pscustomobject]@{
                        allow_clicks = $AllowClicks
                        allow_banner_clicks = $AllowBannerClicks
                        banner_count = $bannerCount
                    }))
                }
            }
        } else {
            $idles++
            try { Invoke-CdpMouseWander | Out-Null } catch {}
        }

        Start-Sleep -Milliseconds (Random-IntInclusive -Min 800 -Max 2500)
    }

    $actualSec = [int](((Get-Date) - $startAt).TotalSeconds)
    return [pscustomobject]@{
        scrolls       = $scrolls
        taps          = $taps
        idles         = $idles
        bannerAvoids  = $bannerAvoids
        plannedVisitSec = $VisitSeconds
        actualVisitSec  = $actualSec
        aborted       = $aborted
        abortReason   = $abortReason
    }
}

function Invoke-MultiPageBrowse {
    # After the main landing visit, browse 1-3 internal pages in the SAME session (no cookie clear).
    # Increases pageviews/session depth and duration -> lowers Yandex robot classification.
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)]$Context,
        [Parameter(Mandatory = $true)]$Task,
        [Parameter(Mandatory = $true)][string]$DeviceId,
        [Parameter(Mandatory = $true)]$Meta,
        [Parameter(Mandatory = $true)][int]$RoundNumber,
        [Parameter(Mandatory = $true)]$Stats,
        [string[]]$BannerSelectors = $null,
        [string[]]$ErrorKeywords = $null
    )

    try {
        $links = @(Get-SameOriginLinks)
        if ($links.Count -eq 0) {
            Write-RunLog -Context $Context -Level 'INFO' -Event 'multipage_skip' -Message 'No internal links found' -Data @{ task_id = $Task.id }
            return
        }

        $hops = Random-IntInclusive -Min 1 -Max 3
        $used = @{}
        $done = 0

        for ($h = 0; $h -lt $hops; $h++) {
            $candidate = $null
            $tries = 0
            while ($tries -lt 12) {
                $idx = Get-Random -Minimum 0 -Maximum ($links.Count)
                $cand = [string]$links[$idx]
                if (-not [string]::IsNullOrWhiteSpace($cand) -and -not $used.ContainsKey($cand)) {
                    $candidate = $cand
                    break
                }
                $tries++
            }
            if ($null -eq $candidate) { break }
            $used[$candidate] = 1

            try {
                Invoke-CdpMouseWander | Out-Null
                Navigate-ToUrl -Url $candidate
            } catch {
                continue
            }

            if (-not (Wait-ForPageReadyInteractive -TimeoutSec ([int]$Config.webViewReadyTimeoutSec))) { continue }
            if (-not (Wait-ForPageLoaded -TimeoutSec ([int]$Config.pageReadyTimeoutSec))) { continue }

            $pageSec = Random-IntInclusive -Min 7 -Max 20
            Write-RunLog -Context $Context -Level 'INFO' -Event 'multipage_hop' -Message "hop $($done + 1) -> $candidate ($pageSec s)" -Data @{ task_id = $Task.id; url = $candidate; hop = ($done + 1) }

            $hopStats = Invoke-HumanBehavior -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -Meta $Meta -TaskId $Task.id -RoundNumber $RoundNumber -VisitSeconds $pageSec -AllowClicks $false -AllowBannerClicks $false -CookieAlreadyClosed $true -BlockedRegions @() -BannerSelectors $BannerSelectors -ErrorKeywords $ErrorKeywords

            if ($null -ne $hopStats -and $null -ne $Stats) {
                try {
                    $Stats.scrolls = [int]$Stats.scrolls + [int]$hopStats.scrolls
                    $Stats.idles = [int]$Stats.idles + [int]$hopStats.idles
                } catch {}
            }

            $done++
            [void](Post-Event -Config $Config -Context $Context -Path '/task/event' -TaskId $Task.id -DeviceId $DeviceId -EventType 'multipage_hop' -LogText "hop $done -> $candidate" -Meta ([pscustomobject]@{ url = $candidate; hop = $done; page_sec = $pageSec }))
        }

        if ($done -gt 0) {
            Write-RunLog -Context $Context -Level 'INFO' -Event 'multipage_done' -Message "Browsed $done extra page(s)" -Data @{ task_id = $Task.id; hops = $done }
        }
    } catch {
        Write-StepError -Step 'Invoke-MultiPageBrowse' -ErrorRecord $_ -Context $Context -Level 'WARN'
    }
}

function Invoke-OpenUrlTask {
    param(        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)]$Context,
        [Parameter(Mandatory = $true)]$Task,
        [Parameter(Mandatory = $true)][string]$DeviceId,
        [Parameter(Mandatory = $true)]$Meta
    )

    $url = [string]$Task.url
    if ([string]::IsNullOrWhiteSpace($url)) {
        [void](Post-Error -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -ErrorCode 'js_exception' -LogText "handleOpenUrl: url is null" -Meta $Meta)
        return [pscustomobject]@{
            success = $false
            finalStatus = 'error'
            finalLog = "URL is null for task $($Task.id)"
            roundNumber = 0
            stats = $null
        }
    }

    $bannerSelectors = Get-BannerSelectors -Profile $null -BannerRulesEnabled $false
    $errorKeywords = Get-ErrorKeywords -Profile $null -BannerRulesEnabled $false
    $configBannerSelectors = Get-ObjectPropertyValue -Object $Config -Name 'bannerSelectors' -Default $null
    if ($null -ne $configBannerSelectors -and @($configBannerSelectors).Count -gt 0) {
        $bannerSelectors = @($configBannerSelectors)
    }
    $configErrorKeywords = Get-ObjectPropertyValue -Object $Config -Name 'errorKeywords' -Default $null
    if ($null -ne $configErrorKeywords -and @($configErrorKeywords).Count -gt 0) {
        $errorKeywords = @($configErrorKeywords)
    }

    try {
    $repeatTotal = [Math]::Max([int]$Task.repeat, 1)
    $roundNumber = Compute-CurrentRoundNumber -Task $Task
    $visitMin = [Math]::Max([int]$Task.visit_min, 1)
    $visitMax = [Math]::Max([int]$Task.visit_max, $visitMin)
    $allowClicks = [bool]$Task.allow_clicks
    $allowBannerClicks = [bool]$Task.click_banner
    $sessionMeta = New-BaseMeta -Config $Config -DeviceId $DeviceId -SessionId $Meta.session_id
    $startMeta = [pscustomobject]@{}
    foreach ($p in $sessionMeta.PSObject.Properties) {
        $startMeta | Add-Member -NotePropertyName $p.Name -NotePropertyValue $p.Value
    }
    $startMeta | Add-Member -NotePropertyName 'repeat' -NotePropertyValue $repeatTotal -Force
    $startMeta | Add-Member -NotePropertyName 'visit_min' -NotePropertyValue $visitMin -Force
    $startMeta | Add-Member -NotePropertyName 'visit_max' -NotePropertyValue $visitMax -Force
    $startMeta | Add-Member -NotePropertyName 'pause_min' -NotePropertyValue ([int]$Task.pause_min) -Force
    $startMeta | Add-Member -NotePropertyName 'pause_max' -NotePropertyValue ([int]$Task.pause_max) -Force
    $startMeta | Add-Member -NotePropertyName 'allow_clicks' -NotePropertyValue $allowClicks -Force
    $startMeta | Add-Member -NotePropertyName 'allow_banner_clicks' -NotePropertyValue $allowBannerClicks -Force

    [void](Post-Start -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -Meta $startMeta)

    Write-RunLog -Context $Context -Level 'INFO' -Event 'task_start' -Message "Round $roundNumber of $repeatTotal started" -Data @{ task_id = $Task.id; url = $url; allow_clicks = $allowClicks; allow_banner_clicks = $allowBannerClicks }
    Trace-DeviceLog -Config $Config -Context $Context -DeviceId $DeviceId -TaskId $Task.id -Level 'INFO' -EventType 'legacy_round_enter' -Message 'Legacy round entered' -Meta ([pscustomobject]@{
        task_id = $Task.id
        round = $roundNumber
        repeat_total = $repeatTotal
        visit_min = $visitMin
        visit_max = $visitMax
        allow_clicks = $allowClicks
        allow_banner_clicks = $allowBannerClicks
        url = $url
    })

    Clear-WebState -Url $url

    try {
        Navigate-ToUrl -Url $url
    } catch {
        [void](Post-Error -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -ErrorCode 'network_timeout' -LogText "Navigation failed: $($_.Exception.Message)" -Meta $Meta)
        return [pscustomobject]@{
            success = $false
            finalStatus = 'error'
            finalLog = "Navigation failed: $($_.Exception.Message)"
            roundNumber = $roundNumber
            stats = $null
        }
    }

    Start-Sleep -Milliseconds (Random-IntInclusive -Min 5000 -Max 10000)

    if (-not (Wait-ForPageReadyInteractive -TimeoutSec ([int]$Config.webViewReadyTimeoutSec))) {
        $errorMeta = [pscustomobject]@{ round = $roundNumber; total_rounds = $repeatTotal }
        $screenshotPath = Capture-ErrorScreenshot -Context $Context -Config $Config -Task $Task -DeviceId $DeviceId -RoundNumber $roundNumber -StepName 'webview_not_ready' -ErrorCode 'webview_not_ready'
        if ($null -ne $screenshotPath) { $errorMeta | Add-Member -NotePropertyName 'screenshot_path' -NotePropertyValue $screenshotPath -Force }
        [void](Post-Error -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -ErrorCode 'webview_not_ready' -LogText "WebView not ready on round $roundNumber" -Meta $errorMeta)
        Trace-DeviceLog -Config $Config -Context $Context -DeviceId $DeviceId -TaskId $Task.id -Level 'WARN' -EventType 'legacy_round_early_exit' -Message 'Legacy round exited before behavior: webview_not_ready' -Meta ([pscustomobject]@{ task_id = $Task.id; round = $roundNumber; reason = 'webview_not_ready' })
        return [pscustomobject]@{
            success = $false
            finalStatus = 'error'
            finalLog = "WebView not ready on round $roundNumber"
            roundNumber = $roundNumber
            stats = $null
        }
    }

    if (-not (Wait-ForPageLoaded -TimeoutSec ([int]$Config.pageReadyTimeoutSec))) {
        $errorMeta = [pscustomobject]@{ round = $roundNumber; total_rounds = $repeatTotal }
        $screenshotPath = Capture-ErrorScreenshot -Context $Context -Config $Config -Task $Task -DeviceId $DeviceId -RoundNumber $roundNumber -StepName 'page_not_loaded' -ErrorCode 'page_not_loaded'
        if ($null -ne $screenshotPath) { $errorMeta | Add-Member -NotePropertyName 'screenshot_path' -NotePropertyValue $screenshotPath -Force }
        [void](Post-Error -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -ErrorCode 'page_not_loaded' -LogText "Page not loaded on round $roundNumber" -Meta $errorMeta)
        Trace-DeviceLog -Config $Config -Context $Context -DeviceId $DeviceId -TaskId $Task.id -Level 'WARN' -EventType 'legacy_round_early_exit' -Message 'Legacy round exited before behavior: page_not_loaded' -Meta ([pscustomobject]@{ task_id = $Task.id; round = $roundNumber; reason = 'page_not_loaded' })
        try {
            Navigate-ToUrl -Url 'about:blank'
        } catch {
        }
        return [pscustomobject]@{
            success = $false
            finalStatus = 'error'
            finalLog = "Page not loaded on round $roundNumber"
            roundNumber = $roundNumber
            stats = $null
        }
    }

    $probe = Collect-StablePageProbe -Config $Config -PageUrl $url -BannerSelectors $bannerSelectors -ErrorKeywords $errorKeywords
    $pageLoadError = Get-PageLoadErrorCode -Probe $probe
    if ($null -ne $pageLoadError) {
        $probeTitle = [string](Get-ObjectPropertyValue -Object $probe -Name 'title' -Default '')
        $probeBody = [string](Get-ObjectPropertyValue -Object $probe -Name 'bodySample' -Default '')
        $logText = "Browser error page on round ${roundNumber}: $probeTitle $probeBody"
        if ($pageLoadError -eq 'ssl_error') {
            Trace-DeviceLog -Config $Config -Context $Context -DeviceId $DeviceId -TaskId $Task.id -Level 'WARN' -EventType 'ssl_warning' -Message 'SSL warning detected' -Meta ([pscustomobject]@{
                task_id = $Task.id
                round = $roundNumber
                url = $url
                title = $probeTitle
            })
        }
        $errorMeta = [pscustomobject]@{
            round = $roundNumber
            total_rounds = $repeatTotal
            url = $url
            error_code = $pageLoadError
        }
        $errorMeta = Apply-PageProbeMeta -Meta $errorMeta -Probe $probe
        $screenshotPath = Capture-ErrorScreenshot -Context $Context -Config $Config -Task $Task -DeviceId $DeviceId -RoundNumber $roundNumber -StepName "browser_error_$pageLoadError" -ErrorCode $pageLoadError
        if ($null -ne $screenshotPath) { $errorMeta | Add-Member -NotePropertyName 'screenshot_path' -NotePropertyValue $screenshotPath -Force }
        [void](Post-Error -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -ErrorCode $pageLoadError -LogText $logText -Meta $errorMeta)
        Trace-DeviceLog -Config $Config -Context $Context -DeviceId $DeviceId -TaskId $Task.id -Level 'ERROR' -EventType 'legacy_round_early_exit' -Message "Legacy round exited before behavior: $pageLoadError" -Meta ([pscustomobject]@{ task_id = $Task.id; round = $roundNumber; reason = $pageLoadError; url = $url })
        return [pscustomobject]@{
            success = $false
            finalStatus = 'error'
            finalLog = $logText
            roundNumber = $roundNumber
            stats = $null
        }
    }

    Write-RunLog -Context $Context -Level 'INFO' -Event 'page_probe' -Message "Page probe collected for task $($Task.id)" -Data @{
        readyState  = (Get-ObjectPropertyValue -Object $probe -Name 'readyState' -Default '')
        bannerCount = (Get-ObjectPropertyValue -Object $probe -Name 'bannerCount' -Default 0)
        errorHits   = (Get-ObjectPropertyValue -Object $probe -Name 'errorHits' -Default @())
        title       = (Get-ObjectPropertyValue -Object $probe -Name 'title' -Default '')
    }

    $initialCookieSelector = Accept-KnownCookiePopup -Context $Context
    if ($null -ne $initialCookieSelector) {
        Log-CookieEvent -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -RoundNumber $roundNumber -Selector $initialCookieSelector -Meta $Meta
    }

    $initialCookieAccepted = $false
    if ($null -eq $initialCookieSelector) {
        $initialCookieAccepted = Accept-CookiesIfNeeded -Context $Context
        if ($initialCookieAccepted) {
            Log-CookieEvent -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -RoundNumber $roundNumber -Selector 'auto-cookie-js' -Meta $Meta
        }
    }

    $visitSeconds = Random-IntInclusive -Min $visitMin -Max $visitMax
    $roundMeta = [pscustomobject]@{}
    foreach ($p in $sessionMeta.PSObject.Properties) {
        $roundMeta | Add-Member -NotePropertyName $p.Name -NotePropertyValue $p.Value
    }
    $roundMeta | Add-Member -NotePropertyName 'allow_clicks' -NotePropertyValue $allowClicks -Force
    $roundMeta | Add-Member -NotePropertyName 'allow_banner_clicks' -NotePropertyValue $allowBannerClicks -Force
    $roundMeta | Add-Member -NotePropertyName 'visit_min' -NotePropertyValue $visitMin -Force
    $roundMeta | Add-Member -NotePropertyName 'visit_max' -NotePropertyValue $visitMax -Force
    $roundMeta | Add-Member -NotePropertyName 'round' -NotePropertyValue $roundNumber -Force
    $roundMeta | Add-Member -NotePropertyName 'total_rounds' -NotePropertyValue $repeatTotal -Force

    Send-Heartbeat -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -Meta $roundMeta -Status 'pending' -LogText "task $($Task.id) pending" -EventType 'round_ping' -RepeatDone 0 -RepeatTotal $repeatTotal -ProgressPercent 0 -Force $true
    Send-Heartbeat -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -Meta $roundMeta -Status 'in_progress' -LogText "round #$roundNumber/$repeatTotal started" -EventType 'round_ping' -RepeatDone ([Math]::Max($roundNumber - 1, 0)) -RepeatTotal $repeatTotal -ProgressPercent 0 -Force $true

    Trace-DeviceLog -Config $Config -Context $Context -DeviceId $DeviceId -TaskId $Task.id -Level 'INFO' -EventType 'legacy_human_behavior_start' -Message 'Legacy human behavior started' -Meta ([pscustomobject]@{
        task_id = $Task.id
        round = $roundNumber
        planned_visit_sec = $visitSeconds
        allow_clicks = $allowClicks
        allow_banner_clicks = $allowBannerClicks
    })

    $stats = Invoke-HumanBehavior -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -Meta $roundMeta -TaskId $Task.id -RoundNumber $roundNumber -VisitSeconds $visitSeconds -AllowClicks $allowClicks -AllowBannerClicks $allowBannerClicks -CookieAlreadyClosed ($initialCookieSelector -ne $null -or $initialCookieAccepted) -BlockedRegions @() -BannerSelectors $bannerSelectors -ErrorKeywords $errorKeywords
    Trace-DeviceLog -Config $Config -Context $Context -DeviceId $DeviceId -TaskId $Task.id -Level 'INFO' -EventType 'legacy_human_behavior_end' -Message 'Legacy human behavior ended' -Meta ([pscustomobject]@{
        task_id = $Task.id
        round = $roundNumber
        planned_visit_sec = $stats.plannedVisitSec
        actual_visit_sec = $stats.actualVisitSec
        scrolls = $stats.scrolls
        taps = $stats.taps
        idles = $stats.idles
        banner_avoids = $stats.bannerAvoids
    })

    $statsAborted = [bool](Get-ObjectPropertyValue -Object $stats -Name 'aborted' -Default $false)
    $statsAbortReason = [string](Get-ObjectPropertyValue -Object $stats -Name 'abortReason' -Default '')
    if ($statsAborted -and $statsAbortReason -eq 'webview_lost_focus') {
        $focusMeta = [pscustomobject]@{ round = $roundNumber; total_rounds = $repeatTotal }
        if ($null -ne $probe) {
            $focusMeta = Apply-PageProbeMeta -Meta $focusMeta -Probe $probe
        }
        $screenshotPath = Capture-ErrorScreenshot -Context $Context -Config $Config -Task $Task -DeviceId $DeviceId -RoundNumber $roundNumber -StepName 'webview_lost_focus' -ErrorCode 'webview_lost_focus'
        if ($null -ne $screenshotPath) { $focusMeta | Add-Member -NotePropertyName 'screenshot_path' -NotePropertyValue $screenshotPath -Force }
        [void](Post-Error -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -ErrorCode 'webview_lost_focus' -LogText "WebView lost focus/destroyed on round $roundNumber" -Meta $focusMeta)
        Trace-DeviceLog -Config $Config -Context $Context -DeviceId $DeviceId -TaskId $Task.id -Level 'WARN' -EventType 'legacy_round_aborted' -Message 'Legacy round aborted: webview_lost_focus' -Meta ([pscustomobject]@{ task_id = $Task.id; round = $roundNumber; reason = 'webview_lost_focus' })
        try {
            Navigate-ToUrl -Url 'about:blank'
        } catch {
        }
        return [pscustomobject]@{
            success = $false
            finalStatus = 'error'
            finalLog = "WebView lost focus on round $roundNumber"
            roundNumber = $roundNumber
            stats = $null
        }
    }

    if (-not $statsAborted) {
        try {
            Invoke-MultiPageBrowse -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -Meta $roundMeta -RoundNumber $roundNumber -Stats $stats -BannerSelectors $bannerSelectors -ErrorKeywords $errorKeywords
        } catch {
            Write-StepError -Step 'multipage' -ErrorRecord $_ -Context $Context -Level 'WARN'
        }
    }

    $summaryMeta = [pscustomobject]@{}
    foreach ($p in $sessionMeta.PSObject.Properties) {
        $summaryMeta | Add-Member -NotePropertyName $p.Name -NotePropertyValue $p.Value
    }
    $summaryMeta | Add-Member -NotePropertyName 'round' -NotePropertyValue $roundNumber -Force
    $summaryMeta | Add-Member -NotePropertyName 'total_rounds' -NotePropertyValue $repeatTotal -Force
    $summaryMeta | Add-Member -NotePropertyName 'planned_visit_sec' -NotePropertyValue $stats.plannedVisitSec -Force
    $summaryMeta | Add-Member -NotePropertyName 'actual_visit_sec' -NotePropertyValue $stats.actualVisitSec -Force
    $summaryMeta | Add-Member -NotePropertyName 'scrolls' -NotePropertyValue $stats.scrolls -Force
    $summaryMeta | Add-Member -NotePropertyName 'taps' -NotePropertyValue $stats.taps -Force
    $summaryMeta | Add-Member -NotePropertyName 'idles' -NotePropertyValue $stats.idles -Force
    $summaryMeta | Add-Member -NotePropertyName 'aborted' -NotePropertyValue $stats.aborted -Force
    if ($null -ne $stats.abortReason -and -not [string]::IsNullOrWhiteSpace([string]$stats.abortReason)) {
        $summaryMeta | Add-Member -NotePropertyName 'abort_reason' -NotePropertyValue $stats.abortReason -Force
    }
    $summaryMeta | Add-Member -NotePropertyName 'successful_rounds' -NotePropertyValue 1 -Force
    $summaryMeta | Add-Member -NotePropertyName 'planned_rounds' -NotePropertyValue $repeatTotal -Force
    $summaryMeta | Add-Member -NotePropertyName 'allow_clicks' -NotePropertyValue $allowClicks -Force
    $summaryMeta | Add-Member -NotePropertyName 'allow_banner_clicks' -NotePropertyValue $allowBannerClicks -Force
    $summaryMeta | Add-Member -NotePropertyName 'banner_avoids' -NotePropertyValue $stats.bannerAvoids -Force

    [void](Post-Event -Config $Config -Context $Context -Path '/task/event' -TaskId $Task.id -DeviceId $DeviceId -EventType 'round_summary' -LogText ("round=$roundNumber aborted=$($stats.aborted) reason=$($stats.abortReason) planned=$($stats.plannedVisitSec)s actual=$($stats.actualVisitSec)s scrolls=$($stats.scrolls) taps=$($stats.taps) idles=$($stats.idles)") -Meta $summaryMeta)
    Write-RunLog -Context $Context -Level 'INFO' -Event 'round_summary' -Message "Round $roundNumber summary sent" -Data @{ task_id = $Task.id; round = $roundNumber; scrolls = $stats.scrolls; taps = $stats.taps; aborted = $stats.aborted }
    Trace-DeviceLog -Config $Config -Context $Context -DeviceId $DeviceId -TaskId $Task.id -Level $(if ($stats.aborted) { 'WARN' } else { 'INFO' }) -EventType $(if ($stats.aborted) { 'legacy_round_aborted' } else { 'legacy_round_complete' }) -Message $(if ($stats.aborted) { 'Legacy round aborted' } else { 'Legacy round completed' }) -Meta ([pscustomobject]@{
        task_id = $Task.id
        round = $roundNumber
        aborted = $stats.aborted
        abort_reason = $stats.abortReason
        planned_visit_sec = $stats.plannedVisitSec
        actual_visit_sec = $stats.actualVisitSec
    })

    $statsMeta = New-BaseMeta -Config $Config -DeviceId $DeviceId -SessionId $Meta.session_id
    foreach ($p in $summaryMeta.PSObject.Properties) {
        $statsMeta | Add-Member -NotePropertyName $p.Name -NotePropertyValue $p.Value -Force
    }

    Send-Heartbeat -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -Meta $summaryMeta -Status 'in_progress' -LogText "Round #$roundNumber completed" -EventType 'round_ping' -RepeatDone $roundNumber -RepeatTotal $repeatTotal -ProgressPercent 100 -Force $true

    try {
        Navigate-ToUrl -Url 'about:blank'
    } catch {
    }
    Clear-WebState -Url $url

    $success = -not $statsAborted
    if (-not $success) {
        [void](Post-Error -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -ErrorCode 'interrupted' -LogText "Round #$roundNumber aborted" -Meta $summaryMeta)
    }
    return [pscustomobject]@{
        success = $success
        finalStatus = if ($success) { 'completed' } else { 'error' }
        finalLog = if ($success) { "Round #$roundNumber completed" } else { "Round #$roundNumber aborted" }
        roundNumber = $roundNumber
        stats = if ($success) { $stats } else { $null }
        completionMeta = if ($success) { $summaryMeta } else { $null }
    }
    } catch {
        return (Report-TaskExecutionError -Step 'Invoke-OpenUrlTask' -ErrorRecord $_ -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -Meta $Meta)
    }
}
