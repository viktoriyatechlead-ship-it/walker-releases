# Update.ps1 - runner self-update.
# On launch, launch.ps1 checks version.json at updateUrl; if the hosted version is
# newer than local (version.txt), it downloads runner.zip, applies it over the folder
# (WITHOUT touching config*.json / state / output) and relaunches the runner.
# Any error / no network -> stay on the current version silently (the runner never
# crashes because of the updater).
# IMPORTANT: keep this file ASCII-only. Windows PowerShell 5.1 reads .ps1 as ANSI
# unless the file has a UTF-8 BOM; non-ASCII chars in strings break parsing.

function Get-LocalRunnerVersion {
    param([Parameter(Mandatory = $true)][string]$RootDir)
    $vf = Join-Path $RootDir 'version.txt'
    if (Test-Path -LiteralPath $vf) {
        $v = Get-Content -LiteralPath $vf -Raw -ErrorAction SilentlyContinue
        if (-not [string]::IsNullOrWhiteSpace([string]$v)) { return ([string]$v).Trim() }
    }
    return '0.0.0'
}

function ConvertTo-VersionOrNull {
    param([string]$Text)
    if ([string]::IsNullOrWhiteSpace($Text)) { return $null }
    $clean = ($Text.Trim() -replace '^[vV]', '')
    $parsed = $null
    if ([version]::TryParse($clean, [ref]$parsed)) { return $parsed }
    return $null
}

function Invoke-SelfUpdate {
    param(
        [Parameter(Mandatory = $true)][string]$RootDir,
        [Parameter(Mandatory = $true)][string]$ConfigPath
    )

    try {
        $resolvedConfigPath = Resolve-ConfigPath -RootDir $RootDir -ConfigPath $ConfigPath
        $cfg = Read-JsonFile -Path $resolvedConfigPath
    } catch {
        Write-Host "UPDATE: cannot read config, skip update ($($_.Exception.Message))"
        return
    }

    $updateUrl = [string](Get-ObjectPropertyValue -Object $cfg -Name 'updateUrl' -Default '')
    if ([string]::IsNullOrWhiteSpace($updateUrl)) { return }   # auto-update disabled
    $updateUrl = $updateUrl.TrimEnd('/')

    $localVersion = Get-LocalRunnerVersion -RootDir $RootDir
    Write-Host "UPDATE: local version $localVersion, checking $updateUrl/version.json ..."

    try {
        $manifest = Invoke-RestMethod -Uri "$updateUrl/version.json" -Method Get -TimeoutSec 12
    } catch {
        Write-Host "UPDATE: manifest unreachable, staying on current version ($($_.Exception.Message))"
        return
    }

    $remoteVersionText = [string](Get-ObjectPropertyValue -Object $manifest -Name 'version' -Default '')
    $remoteVer = ConvertTo-VersionOrNull -Text $remoteVersionText
    $localVer = ConvertTo-VersionOrNull -Text $localVersion
    if ($null -eq $remoteVer) {
        Write-Host "UPDATE: bad remote version '$remoteVersionText', skip"
        return
    }
    if ($null -ne $localVer -and $remoteVer -le $localVer) {
        Write-Host "UPDATE: already up to date ($localVersion)"
        return
    }

    $zipUrl = [string](Get-ObjectPropertyValue -Object $manifest -Name 'zipUrl' -Default '')
    if ([string]::IsNullOrWhiteSpace($zipUrl)) { $zipUrl = "$updateUrl/runner.zip" }
    $sha256 = [string](Get-ObjectPropertyValue -Object $manifest -Name 'sha256' -Default '')

    Write-Host "UPDATE: new version $remoteVersionText available, downloading $zipUrl"

    $tmpBase = Join-Path ([System.IO.Path]::GetTempPath()) ('walker-update-' + [Guid]::NewGuid().ToString('N'))
    $zipPath = "$tmpBase.zip"
    $extractDir = $tmpBase

    try {
        $oldProgress = $ProgressPreference
        $ProgressPreference = 'SilentlyContinue'
        Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -TimeoutSec 180 -UseBasicParsing
        $ProgressPreference = $oldProgress
    } catch {
        Write-Host "UPDATE: download failed, staying on current version ($($_.Exception.Message))"
        return
    }

    if (-not [string]::IsNullOrWhiteSpace($sha256)) {
        try {
            $actual = (Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash
            if ($actual -ne $sha256.Trim().ToUpper()) {
                Write-Host "UPDATE: checksum mismatch, abort (expected $sha256, got $actual)"
                Remove-Item -LiteralPath $zipPath -Force -ErrorAction SilentlyContinue
                return
            }
        } catch {}
    }

    try {
        if (Test-Path -LiteralPath $extractDir) { Remove-Item -LiteralPath $extractDir -Recurse -Force -ErrorAction SilentlyContinue }
        Expand-Archive -LiteralPath $zipPath -DestinationPath $extractDir -Force
    } catch {
        Write-Host "UPDATE: extract failed, staying on current version ($($_.Exception.Message))"
        Remove-Item -LiteralPath $zipPath -Force -ErrorAction SilentlyContinue
        return
    }

    # If the archive is wrapped in a single top folder, descend into it.
    $srcRoot = $extractDir
    $topItems = @(Get-ChildItem -LiteralPath $extractDir -Force)
    if ($topItems.Count -eq 1 -and $topItems[0].PSIsContainer) { $srcRoot = $topItems[0].FullName }

    # Files/folders we must NOT overwrite (local settings, state, logs).
    $preserve = @('config.json', 'config.worker1.json', 'config.worker2.json')
    try {
        Get-ChildItem -LiteralPath $srcRoot -Recurse -Force | ForEach-Object {
            $rel = $_.FullName.Substring($srcRoot.Length).TrimStart('\', '/')
            if ([string]::IsNullOrWhiteSpace($rel)) { return }
            $relLower = $rel.ToLower()
            if ($relLower -like 'state*' -or $relLower -like 'output*' -or $relLower -like '.git*') { return }
            if ($preserve -contains $rel) { return }
            $dest = Join-Path $RootDir $rel
            if ($_.PSIsContainer) {
                Ensure-Directory -Path $dest
            } else {
                Ensure-Directory -Path (Split-Path -Parent $dest)
                Copy-Item -LiteralPath $_.FullName -Destination $dest -Force
            }
        }
        Set-Content -LiteralPath (Join-Path $RootDir 'version.txt') -Value $remoteVersionText -NoNewline -Encoding ASCII
        Write-Host "UPDATE: version $remoteVersionText applied, relaunching runner ..."
    } catch {
        Write-Host "UPDATE: apply failed, staying on current version ($($_.Exception.Message))"
        Remove-Item -LiteralPath $zipPath -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $extractDir -Recurse -Force -ErrorAction SilentlyContinue
        return
    }

    Remove-Item -LiteralPath $zipPath -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $extractDir -Recurse -Force -ErrorAction SilentlyContinue

    # Relaunch the updated launcher and exit the current process.
    $launchPath = Join-Path $RootDir 'launch.ps1'
    try {
        $psExe = (Get-Process -Id $PID).Path
        if ([string]::IsNullOrWhiteSpace([string]$psExe)) { $psExe = 'powershell.exe' }
        Start-Process -FilePath $psExe -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $launchPath, '-ConfigPath', $ConfigPath)
    } catch {
        Write-Host "UPDATE: relaunch failed ($($_.Exception.Message)) - please restart the runner"
    }
    exit 0
}
