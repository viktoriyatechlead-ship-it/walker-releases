function Get-BehaviorProfile {
    param($Task)
    if ($null -eq $Task) { return $null }
    return Get-ObjectPropertyValue -Object $Task -Name 'behavior_profile' -Default $null
}

function Test-ProfileIsEffectivelyEmpty {
    param($Profile)

    if ($null -eq $Profile) { return $true }

    $macro       = Get-ObjectPropertyValue -Object $Profile -Name 'macro' -Default $null
    $macroSteps  = if ($null -ne $macro) { Get-ObjectPropertyValue -Object $macro -Name 'steps' -Default $null } else { $null }
    $bannerRules = Get-ObjectPropertyValue -Object $Profile -Name 'banner_rules' -Default $null

    $hasMacroSteps  = ($null -ne $macroSteps  -and @($macroSteps).Count -gt 0)
    $hasBannerRules = ($null -ne $bannerRules -and @($bannerRules).Count -gt 0)

    if ($true -eq (Get-ProfileMacroEnabled      -Profile $Profile)) { return $false }
    if ($true -eq (Get-ProfileBannerRulesEnabled -Profile $Profile)) { return $false }
    if ($hasMacroSteps)  { return $false }
    if ($hasBannerRules) { return $false }
    return $true
}

function Get-ProfileMacroEnabled {
    param($Profile)

    if ($null -eq $Profile) { return $false }
    $macroEnabled = Get-ObjectPropertyValue -Object $Profile -Name 'macro_enabled' -Default $null
    if ($null -ne $macroEnabled) { return [bool]$macroEnabled }
    $macro      = Get-ObjectPropertyValue -Object $Profile -Name 'macro' -Default $null
    $macroSteps = if ($null -ne $macro) { Get-ObjectPropertyValue -Object $macro -Name 'steps' -Default $null } else { $null }
    if ($null -ne $macroSteps) { return $true }
    return $false
}

function Get-ProfileBannerRulesEnabled {
    param($Profile)

    if ($null -eq $Profile) { return $false }
    $enabled = Get-ObjectPropertyValue -Object $Profile -Name 'banner_rules_enabled' -Default $null
    if ($null -ne $enabled) { return [bool]$enabled }
    $rules = Get-ObjectPropertyValue -Object $Profile -Name 'banner_rules' -Default $null
    if ($null -ne $rules) { return (@($rules).Count -gt 0) }
    return $false
}

function Get-ProfileVersion {
    param($Profile)

    if ($null -eq $Profile) { return 1 }
    $v = Get-ObjectPropertyValue -Object $Profile -Name 'version' -Default $null
    if ($null -ne $v) { return [int]$v }
    return 1
}

function Get-ProfileSlug {
    param($Profile)

    if ($null -eq $Profile) { return 'legacy' }
    $slug = Get-ObjectPropertyValue -Object $Profile -Name 'slug' -Default $null
    if ($null -ne $slug -and -not [string]::IsNullOrWhiteSpace([string]$slug)) { return [string]$slug }
    $name = Get-ObjectPropertyValue -Object $Profile -Name 'name' -Default $null
    if ($null -ne $name -and -not [string]::IsNullOrWhiteSpace([string]$name)) { return [string]$name }
    return 'legacy'
}

function Get-ProfileName {
    param($Profile)

    if ($null -eq $Profile) { return 'legacy' }
    $name = Get-ObjectPropertyValue -Object $Profile -Name 'name' -Default $null
    if ($null -ne $name -and -not [string]::IsNullOrWhiteSpace([string]$name)) { return [string]$name }
    return 'legacy'
}

function Get-ProfileBehaviorProfileId {
    param($Profile)

    if ($null -eq $Profile) { return $null }
    $bpid = Get-ObjectPropertyValue -Object $Profile -Name 'behavior_profile_id' -Default $null
    if ($null -ne $bpid) { return [int]$bpid }
    $id = Get-ObjectPropertyValue -Object $Profile -Name 'id' -Default $null
    if ($null -ne $id) { return [int]$id }
    return $null
}

function Get-BehaviorMacroSteps {
    param(
        $Profile,
        $Task,
        [int]$DefaultVisitSeconds,
        [bool]$MacroEnabled
    )

    $allowClicks       = [bool](Get-ObjectPropertyValue -Object $Task -Name 'allow_clicks'  -Default $false)
    $allowBannerClicks = [bool](Get-ObjectPropertyValue -Object $Task -Name 'click_banner'  -Default $false)

    if (-not $MacroEnabled) {
        return @(
            [pscustomobject]@{ type = 'scan_banners' },
            [pscustomobject]@{ type = 'accept_cookie' },
            [pscustomobject]@{ type = 'human_behavior'; visit_seconds = $DefaultVisitSeconds; allow_clicks = $allowClicks; allow_banner_clicks = $allowBannerClicks },
            [pscustomobject]@{ type = 'assert_no_error' }
        )
    }

    $macro      = Get-ObjectPropertyValue -Object $Profile -Name 'macro' -Default $null
    $macroSteps = if ($null -ne $macro) { Get-ObjectPropertyValue -Object $macro -Name 'steps' -Default $null } else { $null }
    $steps      = if ($null -ne $macroSteps) { @($macroSteps) } else { @() }

    if ($steps.Count -gt 0) { return $steps }
    return @()
}

function Get-BannerSelectors {
    param(
        $Profile,
        [bool]$BannerRulesEnabled
    )

    $rules = @()
    if ($BannerRulesEnabled -and $null -ne $Profile) {
        $r = Get-ObjectPropertyValue -Object $Profile -Name 'banner_rules' -Default $null
        if ($null -ne $r) { $rules = @($r) }
    }

    $selectors = New-Object System.Collections.Generic.List[string]
    foreach ($rule in $rules) {
        $sel = Get-ObjectPropertyValue -Object $rule -Name 'selector' -Default $null
        if ($null -ne $sel -and -not [string]::IsNullOrWhiteSpace([string]$sel)) {
            $selectors.Add([string]$sel)
        }
    }

    if ($selectors.Count -eq 0) {
        foreach ($s in @('iframe','ins',"[data-banner='true']","[class*='banner']","[id*='banner']","[class*='advert']","[id*='advert']","[class*='ads']","[id*='ads']")) {
            $selectors.Add($s)
        }
    }

    return $selectors.ToArray()
}

function Get-ErrorKeywords {
    param(
        $Profile,
        [bool]$BannerRulesEnabled
    )

    $keywords = @(
        'error','failed','forbidden','blocked','captcha','not found','temporarily unavailable','something went wrong',
        'error','access denied','captcha','service unavailable'
    )

    if ($BannerRulesEnabled -and $null -ne $Profile) {
        $rules = Get-ObjectPropertyValue -Object $Profile -Name 'banner_rules' -Default $null
        if ($null -ne $rules) {
            foreach ($rule in @($rules)) {
                $kws = Get-ObjectPropertyValue -Object $rule -Name 'error_keywords' -Default $null
                if ($null -ne $kws) {
                    foreach ($kw in @($kws)) {
                        if (-not [string]::IsNullOrWhiteSpace([string]$kw)) { $keywords += [string]$kw }
                    }
                }
            }
        }
    }

    return @($keywords | Select-Object -Unique)
}

function Convert-ToRectList {
    param(
        $Profile,
        [bool]$BannerRulesEnabled
    )

    $regions = New-Object System.Collections.Generic.List[object]
    if (-not $BannerRulesEnabled -or $null -eq $Profile) { return $regions.ToArray() }
    $rules = Get-ObjectPropertyValue -Object $Profile -Name 'banner_rules' -Default $null
    if ($null -eq $rules) { return $regions.ToArray() }

    foreach ($rule in @($rules)) {
        $region = Get-ObjectPropertyValue -Object $rule -Name 'region' -Default $null
        if ($null -eq $region) { $region = Get-ObjectPropertyValue -Object $rule -Name 'rect' -Default $null }
        if ($null -ne $region) {
            try {
                $regions.Add([pscustomobject]@{
                    left   = [int](Get-ObjectPropertyValue -Object $region -Name 'left'   -Default 0)
                    top    = [int](Get-ObjectPropertyValue -Object $region -Name 'top'    -Default 0)
                    right  = [int](Get-ObjectPropertyValue -Object $region -Name 'right'  -Default 0)
                    bottom = [int](Get-ObjectPropertyValue -Object $region -Name 'bottom' -Default 0)
                })
            } catch {}
        }
    }

    return $regions.ToArray()
}

function New-BaseMeta {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)][string]$DeviceId,
        [Parameter(Mandatory = $true)][string]$SessionId
    )

    $build = 0
    try { $build = [int]([Environment]::OSVersion.Version.Build) } catch { $build = 0 }

    $bp = Get-ObjectPropertyValue -Object $Config -Name 'behaviorProfile' -Default 'scanner'
    if ($null -eq $bp -or [string]::IsNullOrWhiteSpace([string]$bp)) { $bp = 'scanner' }

    [pscustomobject]([ordered]@{
        client_version   = Get-ClientVersion -Config $Config
        sdk_int          = $build
        device_model     = Get-WindowsDeviceModel
        device_type      = Get-DeviceType -Config $Config
        behavior_profile = [string]$bp
        session_id       = $SessionId
        platform         = 'windows'
    })
}

function New-TaskProfileMeta {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)]$Task,
        [Parameter(Mandatory = $true)]$Profile,
        [Parameter(Mandatory = $true)][string]$DeviceId,
        [Parameter(Mandatory = $true)][string]$SessionId,
        [Parameter(Mandatory = $true)][int]$RoundNumber,
        [Parameter(Mandatory = $true)][int]$RepeatTotal,
        [Parameter(Mandatory = $false)][bool]$MacroEnabled = $true,
        [Parameter(Mandatory = $false)][bool]$BannerRulesEnabled = $true
    )

    $meta = New-BaseMeta -Config $Config -DeviceId $DeviceId -SessionId $SessionId
    $meta | Add-Member -NotePropertyName 'behavior_profile_id'      -NotePropertyValue (Get-ProfileBehaviorProfileId -Profile $Profile) -Force
    $meta | Add-Member -NotePropertyName 'behavior_profile_name'    -NotePropertyValue (Get-ProfileName    -Profile $Profile) -Force
    $meta | Add-Member -NotePropertyName 'behavior_profile_slug'    -NotePropertyValue (Get-ProfileSlug    -Profile $Profile) -Force
    $meta | Add-Member -NotePropertyName 'behavior_profile_version' -NotePropertyValue (Get-ProfileVersion -Profile $Profile) -Force
    $meta | Add-Member -NotePropertyName 'behavior_profile'         -NotePropertyValue (Get-ProfileSlug    -Profile $Profile) -Force
    $meta | Add-Member -NotePropertyName 'macro_enabled'            -NotePropertyValue $MacroEnabled       -Force
    $meta | Add-Member -NotePropertyName 'banner_rules_enabled'     -NotePropertyValue $BannerRulesEnabled -Force

    $taskDeviceType = Get-ObjectPropertyValue -Object $Task -Name 'device_type' -Default $null
    if ($null -ne $taskDeviceType -and -not [string]::IsNullOrWhiteSpace([string]$taskDeviceType)) {
        $meta | Add-Member -NotePropertyName 'task_device_type' -NotePropertyValue ([string]$taskDeviceType) -Force
    }

    $taskId = Get-ObjectPropertyValue -Object $Task -Name 'id' -Default $null
    $meta | Add-Member -NotePropertyName 'round'        -NotePropertyValue $RoundNumber  -Force
    $meta | Add-Member -NotePropertyName 'total_rounds' -NotePropertyValue $RepeatTotal  -Force
    $meta | Add-Member -NotePropertyName 'task_id'      -NotePropertyValue $taskId       -Force
    $meta
}
