function Join-ApiUrl {
    param(
        [Parameter(Mandatory = $true)][string]$BaseUrl,
        [Parameter(Mandatory = $true)][string]$Path
    )

    $base = $BaseUrl.TrimEnd('/')
    if (-not $Path.StartsWith('/')) {
        $Path = '/' + $Path
    }
    return $base + $Path
}

function Get-ApiHttpTimeoutSec {
    param([Parameter(Mandatory = $true)]$Config)

    $timeout = [int](Get-ObjectPropertyValue -Object $Config -Name 'apiTimeoutSec' -Default 10)
    if ($timeout -lt 3) { return 3 }
    if ($timeout -gt 60) { return 60 }
    return $timeout
}

function Test-ApiBypassProxy {
    param([Parameter(Mandatory = $true)]$Config)

    $value = Get-ObjectPropertyValue -Object $Config -Name 'apiBypassProxy' -Default $true
    return [bool]$value
}

# HttpWebRequest with hard timeout — Invoke-RestMethod on Windows PS 5.1 can hang minutes behind proxy/IPv6.
function Invoke-ApiHttpJson {
    param(
        [Parameter(Mandatory = $true)][string]$Url,
        [Parameter(Mandatory = $true)][string]$Method,
        [AllowNull()][string]$Body = $null,
        [Parameter(Mandatory = $true)][int]$TimeoutSec,
        [bool]$BypassProxy = $true
    )

    $request = [System.Net.HttpWebRequest]::Create($Url)
    $request.Method = $Method
    $request.Timeout = $TimeoutSec * 1000
    $request.ReadWriteTimeout = $TimeoutSec * 1000
    $request.KeepAlive = $false
    $request.AllowAutoRedirect = $true
    if ($BypassProxy) {
        $request.Proxy = $null
    }

    if ($Method -eq 'POST') {
        $request.ContentType = 'application/json; charset=utf-8'
        $payload = if ($null -ne $Body) { $Body } else { '' }
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($payload)
        $request.ContentLength = $bytes.Length
        $stream = $request.GetRequestStream()
        try {
            $stream.Write($bytes, 0, $bytes.Length)
        } finally {
            $stream.Close()
        }
    }

    $response = $null
    try {
        $response = $request.GetResponse()
        $reader = New-Object System.IO.StreamReader($response.GetResponseStream())
        try {
            $text = $reader.ReadToEnd()
        } finally {
            $reader.Close()
        }
    } finally {
        if ($null -ne $response) {
            $response.Close()
        }
    }

    if ([string]::IsNullOrWhiteSpace($text)) {
        return $null
    }
    return ($text | ConvertFrom-Json)
}

function Invoke-ApiGetTask {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)][string]$DeviceId,
        [Parameter(Mandatory = $true)][string]$DeviceType
    )

    $url = Join-ApiUrl -BaseUrl ([string]$Config.apiBaseUrl) -Path ('/task?device_id=' + [System.Uri]::EscapeDataString($DeviceId) + '&device_type=' + [System.Uri]::EscapeDataString($DeviceType))
    try {
        return Invoke-ApiHttpJson -Url $url -Method 'GET' -TimeoutSec (Get-ApiHttpTimeoutSec -Config $Config) -BypassProxy:(Test-ApiBypassProxy -Config $Config)
    } catch {
        throw $_.Exception
    }
}

function Set-ApiPayloadDeviceType {
    param(
        [Parameter(Mandatory = $true)]$Payload,
        [Parameter(Mandatory = $true)][string]$DeviceType
    )

    if ($Payload -is [System.Collections.IDictionary]) {
        $Payload['device_type'] = $DeviceType
        return
    }

    $Payload | Add-Member -NotePropertyName 'device_type' -NotePropertyValue $DeviceType -Force
}

function Invoke-ApiPostJson {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)]$Payload,
        [Parameter(Mandatory = $true)]$Context,
        [Parameter(Mandatory = $true)][string]$EventName
    )

    $url = Join-ApiUrl -BaseUrl ([string]$Config.apiBaseUrl) -Path $Path
    $deviceTypeValue = if ($null -ne $Config.deviceType -and -not [string]::IsNullOrWhiteSpace([string]$Config.deviceType)) {
        [string]$Config.deviceType
    } else {
        'desktop'
    }
    Set-ApiPayloadDeviceType -Payload $Payload -DeviceType $deviceTypeValue
    $body = $Payload | ConvertTo-Json -Depth 20 -Compress
    try {
        [void](Invoke-ApiHttpJson -Url $url -Method 'POST' -Body $body -TimeoutSec (Get-ApiHttpTimeoutSec -Config $Config) -BypassProxy:(Test-ApiBypassProxy -Config $Config))
        $taskId = $null
        if ($Payload -is [System.Collections.IDictionary]) {
            if ($Payload.Contains('task_id')) { $taskId = $Payload['task_id'] }
        } else {
            $taskId = Get-ObjectPropertyValue -Object $Payload -Name 'task_id' -Default $null
        }
        Write-RunLog -Context $Context -Level 'INFO' -Event 'api_ok' -Message "API OK: $Path ($EventName)" -Data @{ path = $Path; event = $EventName; task_id = $taskId }
        return $true
    } catch {
        Write-RunLog -Context $Context -Level 'WARN' -Event 'api_fail' -Message "API FAILED: $Path ($EventName)" -Data @{ path = $Path; event = $EventName; error = $_.Exception.Message; body = $body }
        return $false
    }
}

function Post-DeviceLog {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)]$Context,
        [Parameter(Mandatory = $true)][string]$DeviceId,
        [AllowNull()]$TaskId = $null,
        [Parameter(Mandatory = $true)][string]$Level,
        [Parameter(Mandatory = $true)][string]$EventType,
        [Parameter(Mandatory = $true)][string]$Message,
        [AllowNull()]$Meta = $null
    )

    $payload = [ordered]@{
        device_id   = $DeviceId
        session_id  = if ($null -ne $Meta -and $Meta.PSObject.Properties.Name -contains 'session_id') { [string]$Meta.session_id } else { $null }
        source      = 'windows'
        level       = $Level
        event_type  = $EventType
        message     = $Message
        log         = $Message
        meta        = if ($null -ne $Meta) { $Meta } else { [pscustomobject]@{} }
    }

    if ($null -ne $TaskId -and [int]$TaskId -gt 0) {
        $payload.task_id = [int]$TaskId
    }

    Invoke-ApiPostJson -Config $Config -Path '/device/log' -Payload $payload -Context $Context -EventName 'device_log' | Out-Null
}

function Start-AsyncDeviceLogPost {
    param(
        [Parameter(Mandatory = $true)][string]$Url,
        [Parameter(Mandatory = $true)][string]$Body,
        [Parameter(Mandatory = $true)][int]$TimeoutSec,
        [bool]$BypassProxy = $true
    )

    $null = Start-Job -Name ('devicelog_' + [System.Guid]::NewGuid().ToString('N').Substring(0, 8)) -ScriptBlock {
        param($JobUrl, $JobBody, $JobTimeoutSec, $JobBypassProxy)
        try {
            $request = [System.Net.HttpWebRequest]::Create($JobUrl)
            $request.Method = 'POST'
            $request.Timeout = $JobTimeoutSec * 1000
            $request.ReadWriteTimeout = $JobTimeoutSec * 1000
            $request.KeepAlive = $false
            $request.ContentType = 'application/json; charset=utf-8'
            if ($JobBypassProxy) {
                $request.Proxy = $null
            }
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($JobBody)
            $request.ContentLength = $bytes.Length
            $stream = $request.GetRequestStream()
            try {
                $stream.Write($bytes, 0, $bytes.Length)
            } finally {
                $stream.Close()
            }
            $response = $request.GetResponse()
            $response.Close()
        } catch {
        }
    } -ArgumentList $Url, $Body, $TimeoutSec, $BypassProxy
}

function Trace-DeviceLog {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)]$Context,
        [Parameter(Mandatory = $true)][string]$DeviceId,
        [AllowNull()]$TaskId = $null,
        [Parameter(Mandatory = $true)][string]$Level,
        [Parameter(Mandatory = $true)][string]$EventType,
        [Parameter(Mandatory = $true)][string]$Message,
        [AllowNull()]$Meta = $null
    )

    $async = [bool](Get-ObjectPropertyValue -Object $Config -Name 'deviceLogAsync' -Default $true)
    if ($async) {
        try {
            $payload = [ordered]@{
                device_id   = $DeviceId
                session_id  = if ($null -ne $Meta -and $Meta.PSObject.Properties.Name -contains 'session_id') { [string]$Meta.session_id } else { $null }
                source      = 'windows'
                level       = $Level
                event_type  = $EventType
                message     = $Message
                log         = $Message
                meta        = if ($null -ne $Meta) { $Meta } else { [pscustomobject]@{} }
            }
            if ($null -ne $TaskId -and [int]$TaskId -gt 0) {
                $payload.task_id = [int]$TaskId
            }
            $deviceTypeValue = if ($null -ne $Config.deviceType -and -not [string]::IsNullOrWhiteSpace([string]$Config.deviceType)) {
                [string]$Config.deviceType
            } else {
                'desktop'
            }
            $payload.device_type = $deviceTypeValue
            $url = Join-ApiUrl -BaseUrl ([string]$Config.apiBaseUrl) -Path '/device/log'
            $body = $payload | ConvertTo-Json -Depth 20 -Compress
            Start-AsyncDeviceLogPost -Url $url -Body $body -TimeoutSec (Get-ApiHttpTimeoutSec -Config $Config) -BypassProxy:(Test-ApiBypassProxy -Config $Config)
        } catch {
            Write-RunLog -Context $Context -Level 'WARN' -Event 'device_log_failed' -Message "Device log enqueue failed: $EventType" -Data @{ error = $_.Exception.Message }
        }
        return
    }

    try {
        Post-DeviceLog -Config $Config -Context $Context -DeviceId $DeviceId -TaskId $TaskId -Level $Level -EventType $EventType -Message $Message -Meta $Meta
    } catch {
        Write-RunLog -Context $Context -Level 'WARN' -Event 'device_log_failed' -Message "Device log failed: $EventType" -Data @{ error = $_.Exception.Message }
    }
}

function Post-Event {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)]$Context,
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][int]$TaskId,
        [Parameter(Mandatory = $true)][string]$DeviceId,
        [Parameter(Mandatory = $true)][string]$EventType,
        [Parameter(Mandatory = $true)][string]$LogText,
        [Parameter(Mandatory = $true)]$Meta,
        [AllowNull()]$Extra = $null
    )

    $payload = [ordered]@{
        task_id    = $TaskId
        device_id  = $DeviceId
        event_type = $EventType
        log        = $LogText
        meta       = $Meta
    }

    if ($null -ne $Extra) {
        foreach ($key in $Extra.PSObject.Properties.Name) {
            $payload[$key] = $Extra.$key
        }
    }

    $ok = Invoke-ApiPostJson -Config $Config -Path $Path -Payload $payload -Context $Context -EventName $EventType
    try {
        Post-DeviceLog -Config $Config -Context $Context -DeviceId $DeviceId -TaskId $TaskId -Level 'INFO' -EventType $EventType -Message $LogText -Meta $Meta
    } catch {
    }
}

function Post-Start {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)]$Context,
        [Parameter(Mandatory = $true)]$Task,
        [Parameter(Mandatory = $true)][string]$DeviceId,
        [Parameter(Mandatory = $true)]$Meta
    )

    $payload = [ordered]@{
        task_id    = $Task.id
        device_id  = $DeviceId
        log        = "START task $($Task.id)"
        event_type = 'task_start'
        meta       = $Meta
    }

    $ok = Invoke-ApiPostJson -Config $Config -Path '/task/start' -Payload $payload -Context $Context -EventName 'task_start'
    try {
        Post-DeviceLog -Config $Config -Context $Context -DeviceId $DeviceId -TaskId $Task.id -Level 'INFO' -EventType 'task_start' -Message "START task $($Task.id)" -Meta $Meta
    } catch {
    }
}

function Post-Complete {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)]$Context,
        [Parameter(Mandatory = $true)]$Task,
        [Parameter(Mandatory = $true)][string]$DeviceId,
        [Parameter(Mandatory = $true)]$Meta
    )

    $payload = [ordered]@{
        task_id    = $Task.id
        device_id  = $DeviceId
        log        = 'DONE: completed_ok'
        event_type = 'task_complete'
        meta       = $Meta
    }

    $ok = Invoke-ApiPostJson -Config $Config -Path '/task/complete' -Payload $payload -Context $Context -EventName 'task_complete'
    try {
        Post-DeviceLog -Config $Config -Context $Context -DeviceId $DeviceId -TaskId $Task.id -Level 'INFO' -EventType 'task_complete' -Message 'DONE: completed_ok' -Meta $Meta
    } catch {
    }
}

function Post-Error {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)]$Context,
        [Parameter(Mandatory = $true)]$Task,
        [Parameter(Mandatory = $true)][string]$DeviceId,
        [Parameter(Mandatory = $true)][string]$ErrorCode,
        [Parameter(Mandatory = $true)][string]$LogText,
        [Parameter(Mandatory = $true)]$Meta,
        [AllowNull()][int]$RoundNumber = 0
    )

    $metaObj = $Meta
    if ($null -eq $metaObj) {
        $metaObj = [pscustomobject]@{}
    }

    try {
        $adminComment = [string](Get-ObjectPropertyValue -Object $metaObj -Name 'admin_comment' -Default '')
        if ([string]::IsNullOrWhiteSpace($adminComment)) {
            $metaObj | Add-Member -NotePropertyName 'admin_comment' -NotePropertyValue (Build-AdminComment -ErrorCode $ErrorCode -LogText $LogText -Meta $metaObj) -Force
        }
        $pageState = [string](Get-ObjectPropertyValue -Object $metaObj -Name 'page_state' -Default '')
        if ([string]::IsNullOrWhiteSpace($pageState)) {
            $metaObj | Add-Member -NotePropertyName 'page_state' -NotePropertyValue (Infer-PageState -Meta $metaObj -ErrorCode $ErrorCode) -Force
        }
        $severity = [string](Get-ObjectPropertyValue -Object $metaObj -Name 'severity' -Default '')
        if ([string]::IsNullOrWhiteSpace($severity)) {
            $metaObj | Add-Member -NotePropertyName 'severity' -NotePropertyValue (Infer-ErrorSeverity -ErrorCode $ErrorCode -Meta $metaObj) -Force
        }
        if ($null -eq (Get-ObjectPropertyValue -Object $metaObj -Name 'checks' -Default $null)) {
            $checks = Build-ErrorChecks -Meta $metaObj
            if (@($checks.PSObject.Properties).Count -gt 0) {
                $metaObj | Add-Member -NotePropertyName 'checks' -NotePropertyValue $checks -Force
            }
        }
    } catch {
        Write-StepError -Step 'Post-Error.meta' -ErrorRecord $_ -Context $Context -Level 'WARN'
    }

    $payload = [ordered]@{
        task_id    = $Task.id
        device_id  = $DeviceId
        error      = $ErrorCode
        log        = $LogText
        event_type = 'task_error'
        meta       = $metaObj
    }

    $screenshotPath = [string](Get-ObjectPropertyValue -Object $metaObj -Name 'screenshot_path' -Default '')
    if ([string]::IsNullOrWhiteSpace($screenshotPath)) {
        try {
            $captureRound = [int](Get-ObjectPropertyValue -Object $metaObj -Name 'round' -Default $RoundNumber)
            if ($captureRound -le 0) {
                $captureRound = 1
            }
            $prefix = "task_${($Task.id)}_round_${captureRound}_error_${ErrorCode}"
            $capturedPath = Capture-PageShot -Context $Context -Prefix $prefix -Config $Config -Task $Task -DeviceId $DeviceId -RoundNumber $captureRound -ErrorCode $ErrorCode
            if (-not [string]::IsNullOrWhiteSpace([string]$capturedPath)) {
                $screenshotPath = [string]$capturedPath
                $metaObj | Add-Member -NotePropertyName 'screenshot_path' -NotePropertyValue $screenshotPath -Force
            }
        } catch {
            Write-RunLog -Context $Context -Level 'WARN' -Event 'task_error' -Message 'Fallback screenshot capture failed' -Data @{ error = $_.Exception.Message; code = $ErrorCode }
        }
    }

    if (-not [string]::IsNullOrWhiteSpace($screenshotPath) -and (Test-Path -LiteralPath $screenshotPath)) {
        try {
            $shotBytes = [System.IO.File]::ReadAllBytes($screenshotPath)
            if ($shotBytes.Length -gt 0) {
                $payload['screenshot_base64'] = [Convert]::ToBase64String($shotBytes)
            }
        } catch {
            Write-RunLog -Context $Context -Level 'WARN' -Event 'task_error' -Message 'Failed to read screenshot for error payload' -Data @{ path = $screenshotPath; error = $_.Exception.Message }
        }
    }

    $ok = Invoke-ApiPostJson -Config $Config -Path '/task/error' -Payload $payload -Context $Context -EventName 'task_error'
    try {
        Post-DeviceLog -Config $Config -Context $Context -DeviceId $DeviceId -TaskId $Task.id -Level 'ERROR' -EventType 'task_error' -Message $LogText -Meta $metaObj
    } catch {
    }
}

function Infer-PageState {
    param(
        [Parameter(Mandatory = $true)]$Meta,
        [Parameter(Mandatory = $true)][string]$ErrorCode
    )

    $visibleTextLength = [int](Get-ObjectPropertyValue -Object $Meta -Name 'visible_text_length' -Default 0)
    $headingCount = [int](Get-ObjectPropertyValue -Object $Meta -Name 'heading_count' -Default 0)
    $cardCount = [int](Get-ObjectPropertyValue -Object $Meta -Name 'card_count' -Default 0)
    $linkCount = [int](Get-ObjectPropertyValue -Object $Meta -Name 'link_count' -Default 0)
    $buttonCount = [int](Get-ObjectPropertyValue -Object $Meta -Name 'button_count' -Default 0)
    $imagesPending = [int](Get-ObjectPropertyValue -Object $Meta -Name 'images_pending' -Default 0)
    $readyState = ([string](Get-ObjectPropertyValue -Object $Meta -Name 'ready_state' -Default '')).ToLowerInvariant()

    if ($visibleTextLength -gt 0 -or $headingCount -gt 0 -or $cardCount -gt 0 -or $linkCount -gt 0 -or $buttonCount -gt 0) {
        return 'content_ready'
    }
    if ($imagesPending -gt 0 -or $readyState -in @('loading','interactive')) {
        return 'loading'
    }
    if ($ErrorCode -eq 'empty_page') {
        return 'empty'
    }
    return 'ready'
}

function Infer-ErrorSeverity {
    param(
        [Parameter(Mandatory = $true)][string]$ErrorCode,
        [Parameter(Mandatory = $true)]$Meta
    )

    $visibleTextLength = [int](Get-ObjectPropertyValue -Object $Meta -Name 'visible_text_length' -Default 0)
    $headingCount = [int](Get-ObjectPropertyValue -Object $Meta -Name 'heading_count' -Default 0)
    $cardCount = [int](Get-ObjectPropertyValue -Object $Meta -Name 'card_count' -Default 0)

    if ($ErrorCode -eq 'empty_page' -and ($visibleTextLength -gt 0 -or $headingCount -gt 0 -or $cardCount -gt 0)) {
        return 'warning'
    }
    if ($ErrorCode -eq 'webview_lost_focus') {
        return 'warning'
    }
    if ($ErrorCode -in @('page_not_loaded','dns_error','ssl_error')) {
        return 'real_error'
    }
    return 'real_error'
}

function Build-ErrorChecks {
    param(
        [Parameter(Mandatory = $true)]$Meta
    )

    $readyState = [string](Get-ObjectPropertyValue -Object $Meta -Name 'ready_state' -Default '')
    return [pscustomobject]@{
        document_ready      = ($readyState -eq 'complete')
        visible_text_length = [int](Get-ObjectPropertyValue -Object $Meta -Name 'visible_text_length' -Default 0)
        heading_count       = [int](Get-ObjectPropertyValue -Object $Meta -Name 'heading_count' -Default 0)
        card_count          = [int](Get-ObjectPropertyValue -Object $Meta -Name 'card_count' -Default 0)
        link_count          = [int](Get-ObjectPropertyValue -Object $Meta -Name 'link_count' -Default 0)
        button_count        = [int](Get-ObjectPropertyValue -Object $Meta -Name 'button_count' -Default 0)
        images_total        = [int](Get-ObjectPropertyValue -Object $Meta -Name 'images_total' -Default 0)
        images_loaded       = [int](Get-ObjectPropertyValue -Object $Meta -Name 'images_loaded' -Default 0)
        images_pending      = [int](Get-ObjectPropertyValue -Object $Meta -Name 'images_pending' -Default 0)
    }
}

function Build-AdminComment {
    param(
        [Parameter(Mandatory = $true)][string]$ErrorCode,
        [Parameter(Mandatory = $true)][string]$LogText,
        [Parameter(Mandatory = $true)]$Meta
    )

    $pageState = Infer-PageState -Meta $Meta -ErrorCode $ErrorCode
    $visibleTextLength = [int](Get-ObjectPropertyValue -Object $Meta -Name 'visible_text_length' -Default 0)
    $headingCount = [int](Get-ObjectPropertyValue -Object $Meta -Name 'heading_count' -Default 0)
    $cardCount = [int](Get-ObjectPropertyValue -Object $Meta -Name 'card_count' -Default 0)
    $linkCount = [int](Get-ObjectPropertyValue -Object $Meta -Name 'link_count' -Default 0)
    $buttonCount = [int](Get-ObjectPropertyValue -Object $Meta -Name 'button_count' -Default 0)
    $imagesPending = [int](Get-ObjectPropertyValue -Object $Meta -Name 'images_pending' -Default 0)
    $readyState = [string](Get-ObjectPropertyValue -Object $Meta -Name 'ready_state' -Default '')

    switch ($ErrorCode) {
        'webview_lost_focus' { return 'WebView lost focus or went to background. This is a warning, not necessarily a site error.' }
        'page_not_loaded' { return 'The page did not fully load before timeout. Check network, redirects, and heavy resources.' }
        'webview_not_ready' { return 'WebView did not become ready in time. This is a startup/render issue, not necessarily a site error.' }
        'dns_error' { return 'DNS resolution failed. No valid DOM content was available on the client.' }
        'ssl_error' { return 'SSL/certificate prevented the page from opening. The browser hit a security problem.' }
        'empty_page' {
            if ($visibleTextLength -gt 0 -or $headingCount -gt 0 -or $cardCount -gt 0 -or $linkCount -gt 0 -or $buttonCount -gt 0) {
                return "Live content is already visible: text=$visibleTextLength, headings=$headingCount, cards=$cardCount, links=$linkCount, buttons=$buttonCount. empty_page triggered too early."
            }
            if ($imagesPending -gt 0 -or $readyState -in @('loading','interactive')) {
                return "The page was still loading: readyState=$readyState, pending_images=$imagesPending. This was an early snapshot, not a final empty page."
            }
            return 'No visible text or basic DOM content was detected on the page.'
        }
        default {
            $suffix = ''
            if (-not [string]::IsNullOrWhiteSpace([string]$LogText)) {
                $suffix = ' Log: ' + $LogText
            }
            return "Client classified error $ErrorCode with page_state=$pageState.$suffix"
        }
    }
}

function Apply-PageProbeMeta {
    param(
        [Parameter(Mandatory = $true)]$Meta,
        [Parameter(Mandatory = $true)]$Probe
    )

    $readyState = Get-ObjectPropertyValue -Object $Probe -Name 'ready_state' -Default $null
    if ($null -eq $readyState) {
        $readyState = Get-ObjectPropertyValue -Object $Probe -Name 'readyState' -Default ''
    }
    $bodySample = Get-ObjectPropertyValue -Object $Probe -Name 'body_sample' -Default $null
    if ($null -eq $bodySample) {
        $bodySample = Get-ObjectPropertyValue -Object $Probe -Name 'bodySample' -Default ''
    }
    $Meta | Add-Member -NotePropertyName 'ready_state' -NotePropertyValue ([string]$readyState) -Force
    $Meta | Add-Member -NotePropertyName 'body_sample' -NotePropertyValue ([string]$bodySample) -Force
    $Meta | Add-Member -NotePropertyName 'visible_text_length' -NotePropertyValue ([int](Get-ObjectPropertyValue -Object $Probe -Name 'visible_text_length' -Default 0)) -Force
    $Meta | Add-Member -NotePropertyName 'heading_count' -NotePropertyValue ([int](Get-ObjectPropertyValue -Object $Probe -Name 'heading_count' -Default 0)) -Force
    $Meta | Add-Member -NotePropertyName 'card_count' -NotePropertyValue ([int](Get-ObjectPropertyValue -Object $Probe -Name 'card_count' -Default 0)) -Force
    $Meta | Add-Member -NotePropertyName 'link_count' -NotePropertyValue ([int](Get-ObjectPropertyValue -Object $Probe -Name 'link_count' -Default 0)) -Force
    $Meta | Add-Member -NotePropertyName 'button_count' -NotePropertyValue ([int](Get-ObjectPropertyValue -Object $Probe -Name 'button_count' -Default 0)) -Force
    $Meta | Add-Member -NotePropertyName 'images_total' -NotePropertyValue ([int](Get-ObjectPropertyValue -Object $Probe -Name 'images_total' -Default 0)) -Force
    $Meta | Add-Member -NotePropertyName 'images_loaded' -NotePropertyValue ([int](Get-ObjectPropertyValue -Object $Probe -Name 'images_loaded' -Default 0)) -Force
    $Meta | Add-Member -NotePropertyName 'images_pending' -NotePropertyValue ([int](Get-ObjectPropertyValue -Object $Probe -Name 'images_pending' -Default 0)) -Force
    return $Meta
}

function Send-TaskComplete {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)]$Context,
        [Parameter(Mandatory = $true)]$Task,
        [Parameter(Mandatory = $true)][string]$DeviceId,
        [Parameter(Mandatory = $true)]$Result,
        [Parameter(Mandatory = $true)][string]$SessionId
    )

    $roundNumber = [int](Get-ObjectPropertyValue -Object $Result -Name 'roundNumber' -Default 0)
    $stats = Get-ObjectPropertyValue -Object $Result -Name 'stats' -Default $null
    $repeatTotal = [Math]::Max([int]$Task.repeat, 1)

    $completeMeta = New-BaseMeta -Config $Config -DeviceId $DeviceId -SessionId $SessionId
    $completeMeta | Add-Member -NotePropertyName 'successful_rounds' -NotePropertyValue 1 -Force
    $completeMeta | Add-Member -NotePropertyName 'planned_rounds' -NotePropertyValue $repeatTotal -Force
    $completeMeta | Add-Member -NotePropertyName 'round' -NotePropertyValue $roundNumber -Force
    $completeMeta | Add-Member -NotePropertyName 'total_rounds' -NotePropertyValue $repeatTotal -Force
    $completeMeta | Add-Member -NotePropertyName 'allow_clicks' -NotePropertyValue ([bool]$Task.allow_clicks) -Force
    $completeMeta | Add-Member -NotePropertyName 'allow_banner_clicks' -NotePropertyValue ([bool]$Task.click_banner) -Force

    if ($null -ne $stats) {
        $completeMeta | Add-Member -NotePropertyName 'banner_avoids' -NotePropertyValue ([int](Get-ObjectPropertyValue -Object $stats -Name 'bannerAvoids' -Default 0)) -Force
        $completeMeta | Add-Member -NotePropertyName 'scrolls' -NotePropertyValue ([int](Get-ObjectPropertyValue -Object $stats -Name 'scrolls' -Default 0)) -Force
        $completeMeta | Add-Member -NotePropertyName 'taps' -NotePropertyValue ([int](Get-ObjectPropertyValue -Object $stats -Name 'taps' -Default 0)) -Force
        $completeMeta | Add-Member -NotePropertyName 'idles' -NotePropertyValue ([int](Get-ObjectPropertyValue -Object $stats -Name 'idles' -Default 0)) -Force
        $completeMeta | Add-Member -NotePropertyName 'planned_visit_sec' -NotePropertyValue ([int](Get-ObjectPropertyValue -Object $stats -Name 'plannedVisitSec' -Default 0)) -Force
        $completeMeta | Add-Member -NotePropertyName 'actual_visit_sec' -NotePropertyValue ([int](Get-ObjectPropertyValue -Object $stats -Name 'actualVisitSec' -Default 0)) -Force
    }

    [void](Post-Complete -Config $Config -Context $Context -Task $Task -DeviceId $DeviceId -Meta $completeMeta)
}

function Send-Heartbeat {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)]$Context,
        [Parameter(Mandatory = $true)]$Task,
        [Parameter(Mandatory = $true)][string]$DeviceId,
        [Parameter(Mandatory = $true)]$Meta,
        [Parameter(Mandatory = $true)][string]$Status,
        [Parameter(Mandatory = $true)][string]$LogText,
        [Parameter(Mandatory = $true)][string]$EventType,
        [Parameter(Mandatory = $true)][int]$RepeatDone,
        [Parameter(Mandatory = $true)][int]$RepeatTotal,
        [Parameter(Mandatory = $true)][int]$ProgressPercent,
        [Parameter(Mandatory = $true)][bool]$Force
    )

    if (-not $Force -and $script:lastPingStatus -eq $Status) {
        return
    }

    $payload = [ordered]@{
        task_id          = $Task.id
        device_id        = $DeviceId
        repeat_done      = $RepeatDone
        progress_percent  = $ProgressPercent
    }

    if ($RepeatTotal -gt 0) {
        $payload.repeat_total = $RepeatTotal
    }

    if (-not [string]::IsNullOrWhiteSpace($Status)) {
        $payload.status = $Status
        $script:lastPingStatus = $Status
    } elseif ($Force -and -not [string]::IsNullOrWhiteSpace($script:lastPingStatus)) {
        $payload.status = $script:lastPingStatus
    }

    if (-not [string]::IsNullOrWhiteSpace($EventType)) {
        $payload.event_type = $EventType
    }

    if (-not [string]::IsNullOrWhiteSpace($LogText)) {
        $payload.log = $LogText
    }

    $payload.meta = $Meta

    $ok = Invoke-ApiPostJson -Config $Config -Path '/task/ping' -Payload $payload -Context $Context -EventName $EventType
    if ($ok) {
        return
    }

    Start-Sleep -Seconds ([int]$Config.heartbeatRetryDelaySec)
    $ok2 = Invoke-ApiPostJson -Config $Config -Path '/task/ping' -Payload $payload -Context $Context -EventName $EventType
    if (-not $ok2) {
        [void](Post-Event -Config $Config -Context $Context -Path '/task/event' -TaskId $Task.id -DeviceId $DeviceId -EventType 'worker_exception' -LogText 'Heartbeat ping failed twice' -Meta ([pscustomobject]@{ error = 'ping_failed' }))
    }
}

function Post-Traffic {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)][string]$DeviceId,
        [AllowNull()]$TaskId = $null,
        [Parameter(Mandatory = $true)][long]$BytesTotal,
        [Parameter(Mandatory = $true)]$Domains,
        [string]$Mode = 'proxy'
    )
    if ($BytesTotal -le 0) { return }
    $payload = [ordered]@{
        device_id   = $DeviceId
        bytes_total = $BytesTotal
        mode        = if ($Mode -eq 'direct') { 'direct' } else { 'proxy' }
        domains     = @($Domains | ForEach-Object { [ordered]@{ domain = $_.domain; bytes = $_.bytes } })
    }
    if ($null -ne $TaskId -and [int]$TaskId -gt 0) {
        $payload.task_id = [int]$TaskId
    }
    $url = Join-ApiUrl -BaseUrl ([string]$Config.apiBaseUrl) -Path '/api/traffic'
    $body = $payload | ConvertTo-Json -Depth 10 -Compress
    try {
        Invoke-ApiHttpJson -Url $url -Method 'POST' -Body $body -TimeoutSec (Get-ApiHttpTimeoutSec -Config $Config) -BypassProxy:$true | Out-Null
    } catch {}
}

function Get-ProxyConfig {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)][string]$DeviceId
    )
    $url = Join-ApiUrl -BaseUrl ([string]$Config.apiBaseUrl) -Path ('/api/config/' + [System.Uri]::EscapeDataString($DeviceId))
    try {
        return Invoke-ApiHttpJson -Url $url -Method 'GET' -TimeoutSec (Get-ApiHttpTimeoutSec -Config $Config) -BypassProxy:$true
    } catch {
        return $null
    }
}

