@echo off
setlocal
cd /d "%~dp0"
title Standalone Windows Runner - Worker 1
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0launch.ps1" -ConfigPath "%~dp0config.worker1.json"
endlocal
