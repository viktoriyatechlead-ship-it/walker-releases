<#
release.ps1 - builds a release of the self-updating runner.

Steps:
  1. Sets the new version in version.txt (-Version, otherwise auto-increment patch).
  2. Packs runner code into release\runner.zip (NO state/output/logs/config.json/.git).
  3. Computes SHA256 and writes release\version.json (version, zipUrl, sha256, notes).
  4. If -PublishDir is set (local walker-releases repo folder) - copies version.json
     and runner.zip there, ready to git commit/push.

Run on Windows:
  powershell -NoProfile -ExecutionPolicy Bypass -File .\release.ps1 -Version 1.0.2 -Notes "fix CDP"
  powershell -NoProfile -ExecutionPolicy Bypass -File .\release.ps1            # auto +0.0.1

Hosting (default): GitHub walker-releases (raw, branch main).
  updateUrl in config: https://raw.githubusercontent.com/viktoriyatechlead-ship-it/walker-releases/main

Keep this file ASCII-only (Windows PowerShell 5.1 reads .ps1 as ANSI without a BOM).
#>
param(
    [string]$Version = '',
    [string]$Notes = '',
    [string]$BaseUrl = 'https://raw.githubusercontent.com/viktoriyatechlead-ship-it/walker-releases/main',
    [string]$PublishDir = ''
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$releaseDir = Join-Path $root 'release'

function Bump-Patch {
    param([string]$Current)
    $clean = ($Current.Trim() -replace '^[vV]', '')
    $v = $null
    if (-not [version]::TryParse($clean, [ref]$v)) { return '1.0.0' }
    $build = if ($v.Build -lt 0) { 0 } else { $v.Build }
    return ('{0}.{1}.{2}' -f $v.Major, $v.Minor, ($build + 1))
}

# --- 1. Version ---
$versionFile = Join-Path $root 'version.txt'
$current = if (Test-Path -LiteralPath $versionFile) { (Get-Content -LiteralPath $versionFile -Raw).Trim() } else { '0.0.0' }
if ([string]::IsNullOrWhiteSpace($Version)) { $Version = Bump-Patch -Current $current }
Set-Content -LiteralPath $versionFile -Value $Version -NoNewline -Encoding ASCII
Write-Host "  Version: $current -> $Version"

# --- 2. Pack ---
if (Test-Path -LiteralPath $releaseDir) { Remove-Item -LiteralPath $releaseDir -Recurse -Force }
New-Item -ItemType Directory -Path $releaseDir | Out-Null
$staging = Join-Path $releaseDir '_staging'
New-Item -ItemType Directory -Path $staging | Out-Null

# Only code goes into the archive. Exclude personal configs, state, logs, backups.
$excludeTop = @('state', 'output', 'release', '.git')
$excludeFiles = @('config.json', 'config.worker1.json', 'config.worker2.json', '.DS_Store')
$excludeExt = @('.log', '.bak')

Get-ChildItem -LiteralPath $root -Force | Where-Object {
    $excludeTop -notcontains $_.Name
} | ForEach-Object {
    if ($_.PSIsContainer) {
        Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $staging $_.Name) -Recurse -Force
    } elseif (($excludeFiles -notcontains $_.Name) -and ($excludeExt -notcontains $_.Extension.ToLower())) {
        Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $staging $_.Name) -Force
    }
}
foreach ($junk in @('last-run.log', 'last-run-worker1.log', 'last-run-worker2.log')) {
    $pth = Join-Path $staging $junk
    if (Test-Path -LiteralPath $pth) { Remove-Item -LiteralPath $pth -Force }
}

$zipPath = Join-Path $releaseDir 'runner.zip'
Compress-Archive -Path (Join-Path $staging '*') -DestinationPath $zipPath -Force
Remove-Item -LiteralPath $staging -Recurse -Force

# --- 3. Manifest ---
$sha = (Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash
$manifest = [ordered]@{
    version = $Version
    zipUrl  = ($BaseUrl.TrimEnd('/') + '/runner.zip')
    sha256  = $sha
    notes   = $Notes
    builtAt = (Get-Date).ToString('yyyy-MM-ddTHH:mm:ss')
}
$jsonPath = Join-Path $releaseDir 'version.json'
($manifest | ConvertTo-Json -Depth 4) | Set-Content -LiteralPath $jsonPath -Encoding UTF8

$sizeKb = [int]((Get-Item $zipPath).Length / 1KB)
Write-Host "  runner.zip: $sizeKb KB"
Write-Host "  sha256:     $sha"
Write-Host "  version.json + runner.zip -> $releaseDir"

# --- 4. Publish to walker-releases (if provided) ---
if (-not [string]::IsNullOrWhiteSpace($PublishDir)) {
    if (-not (Test-Path -LiteralPath $PublishDir)) { throw "PublishDir not found: $PublishDir" }
    Copy-Item -LiteralPath $zipPath -Destination (Join-Path $PublishDir 'runner.zip') -Force
    Copy-Item -LiteralPath $jsonPath -Destination (Join-Path $PublishDir 'version.json') -Force
    Write-Host "  Copied to $PublishDir - now: git add . && git commit -m 'release $Version' && git push"
}

Write-Host ''
Write-Host "Done. Release $Version built."
