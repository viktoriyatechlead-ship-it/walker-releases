function Get-BrowserExeFromRegistry {
    param([Parameter(Mandatory = $true)][string]$ExeName)

    $regPaths = @(
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\$ExeName",
        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\$ExeName"
    )
    foreach ($regPath in $regPaths) {
        try {
            if (-not (Test-Path -LiteralPath $regPath)) { continue }
            $value = (Get-ItemProperty -LiteralPath $regPath -ErrorAction Stop).'(default)'
            if ([string]::IsNullOrWhiteSpace([string]$value)) { continue }
            $resolved = [string]$value
            if (Test-Path -LiteralPath $resolved -PathType Leaf) {
                return (Resolve-Path -LiteralPath $resolved).Path
            }
        } catch {
        }
    }
    return $null
}

function Resolve-BrowserExeFromPath {
    param([Parameter(Mandatory = $true)][string]$ExeName)

    $pathDirs = @($env:PATH -split ';' | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    foreach ($dir in $pathDirs) {
        try {
            $full = Join-Path $dir $ExeName
            if (Test-Path -LiteralPath $full -PathType Leaf) {
                return (Resolve-Path -LiteralPath $full).Path
            }
        } catch {
        }
    }
    return $null
}

function Resolve-BrowserCandidatePath {
    param([Parameter(Mandatory = $true)][string]$Candidate)

    if ([string]::IsNullOrWhiteSpace($Candidate)) { return $null }

    # Full paths first: Test-Path works on all PowerShell versions; Get-Command breaks on "Program Files".
    if ($Candidate -match '[\\/]') {
        if (Test-Path -LiteralPath $Candidate -PathType Leaf) {
            return (Resolve-Path -LiteralPath $Candidate).Path
        }
        return $null
    }

    $exeName = $Candidate
    if ($exeName -notmatch '\.exe$') {
        $exeName = "$exeName.exe"
    }

    $fromRegistry = Get-BrowserExeFromRegistry -ExeName $exeName
    if ($null -ne $fromRegistry) { return $fromRegistry }

    $fromPath = Resolve-BrowserExeFromPath -ExeName $exeName
    if ($null -ne $fromPath) { return $fromPath }

    $cmd = Get-Command $exeName -ErrorAction SilentlyContinue
    if ($null -ne $cmd) {
        $source = [string]$cmd.Source
        if (-not [string]::IsNullOrWhiteSpace($source) -and (Test-Path -LiteralPath $source -PathType Leaf)) {
            return (Resolve-Path -LiteralPath $source).Path
        }
    }

    return $null
}

function Resolve-BrowserPath {
    param(
        [Parameter(Mandatory = $true)]$BrowserConfig
    )

    $preferred = @()
    $preferredValue = Get-ObjectPropertyValue -Object $BrowserConfig -Name 'preferred' -Default $null
    if ($null -ne $preferredValue) {
        $preferred = @($preferredValue)
    }

    if ($preferred.Count -eq 0) {
        $preferred = @('edge', 'chrome')
    }

    $candidates = New-Object System.Collections.Generic.List[string]

    foreach ($item in $preferred) {
        switch (Normalize-Text $item) {
            'edge' {
                $candidates.Add('C:\Program Files\Microsoft\Edge\Application\msedge.exe')
                $candidates.Add('C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe')
                $candidates.Add('msedge.exe')
            }
            'chrome' {
                $candidates.Add('C:\Program Files\Google\Chrome\Application\chrome.exe')
                $candidates.Add('C:\Program Files (x86)\Google\Chrome\Application\chrome.exe')
                $candidates.Add('chrome.exe')
            }
            default {
                $candidates.Add([string]$item)
            }
        }
    }

    $seen = @{}
    foreach ($candidate in $candidates) {
        $key = Normalize-Text $candidate
        if ($seen.ContainsKey($key)) { continue }
        $seen[$key] = $true

        $resolved = Resolve-BrowserCandidatePath -Candidate $candidate
        if ($null -ne $resolved) {
            return $resolved
        }
    }

    throw 'Could not find Microsoft Edge or Google Chrome. Install one of them or set browser.preferred to a valid path.'
}

function Clear-BrowserProfileLocks {
    # Remove Singleton lock files from the profile - otherwise a new Edge/Chrome hands
    # the session to an already-running instance and never opens the debug port
    # (the "Timed out waiting for DevTools endpoint" error).
    param([Parameter(Mandatory = $true)][string]$UserDataDir)
    foreach ($name in @('SingletonLock', 'SingletonCookie', 'SingletonSocket')) {
        $p = Join-Path $UserDataDir $name
        try { if (Test-Path -LiteralPath $p) { Remove-Item -LiteralPath $p -Force -ErrorAction SilentlyContinue } } catch {}
    }
}

function Stop-ProcessOnPort {
    # Kill a process holding the debug port from a previous/hung run.
    param([Parameter(Mandatory = $true)][int]$Port)
    try {
        $conns = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
        foreach ($c in $conns) {
            try { Stop-Process -Id $c.OwningProcess -Force -ErrorAction SilentlyContinue } catch {}
        }
    } catch {
        # Get-NetTCPConnection may be unavailable - fall back to netstat.
        try {
            $lines = netstat -ano | Select-String ":$Port\s" | Select-String 'LISTENING'
            foreach ($l in $lines) {
                $parts = ($l.ToString() -split '\s+') | Where-Object { $_ -ne '' }
                $procId = $parts[-1]
                if ($procId -match '^\d+$') { try { Stop-Process -Id ([int]$procId) -Force -ErrorAction SilentlyContinue } catch {} }
            }
        } catch {}
    }
}

function Start-BrowserProcess {
    param(
        [Parameter(Mandatory = $true)][string]$BrowserPath,
        [Parameter(Mandatory = $true)][int]$Port,
        [Parameter(Mandatory = $true)][string]$UserDataDir,
        [Parameter(Mandatory = $true)][string[]]$ExtraArgs
    )

    Ensure-Directory -Path $UserDataDir
    # CDP fix: free the port and clear profile locks so the debug endpoint comes up reliably.
    Stop-ProcessOnPort -Port $Port
    Clear-BrowserProfileLocks -UserDataDir $UserDataDir

    $args = @(
        '--new-window'
        '--remote-debugging-port=' + $Port
        '--no-first-run'
        '--no-default-browser-check'
        '--disable-background-networking'
        '--disable-extensions'
        '--disable-popup-blocking'
        '--user-data-dir=' + $UserDataDir
        'about:blank'
    ) + @($ExtraArgs)

    Start-Process -FilePath $BrowserPath -ArgumentList $args -PassThru
}

function Wait-ForDebuggerEndpoint {
    param(
        [Parameter(Mandatory = $true)][int]$Port,
        [Parameter(Mandatory = $true)][int]$TimeoutSec
    )

    $deadline = (Get-Date).AddSeconds($TimeoutSec)
    $uri = "http://127.0.0.1:$Port/json/list"

    while ((Get-Date) -lt $deadline) {
        try {
            $targets = Invoke-RestMethod -Uri $uri -Method Get -TimeoutSec 3
            $pageTarget = @($targets | Where-Object { $_.type -eq 'page' } | Select-Object -First 1)
            if ($pageTarget.Count -gt 0 -and $pageTarget[0].webSocketDebuggerUrl) {
                return [pscustomobject]@{
                    target = $pageTarget[0]
                    list   = $targets
                }
            }
        } catch {
        }

        Start-Sleep -Milliseconds 300
    }

    throw "Timed out waiting for DevTools endpoint on port $Port"
}

