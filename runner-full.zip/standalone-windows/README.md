# Standalone Windows Task Worker

Это автономный PowerShell-аналог Android-клиента. Он не зависит от APK и работает как отдельное Windows-устройство: берёт текущую задачу из удалённой админки, открывает ссылку в браузере, симулирует поведение пользователя, ловит ошибки и отправляет отчёты обратно в API.

## Что делает
- Берёт задачу через `GET /task?device_id=...`.
- Выполняет `open_url` задачи в браузере.
- Перед каждым раундом чистит cookies/storage/cache.
- Автоматически принимает cookie-баннеры.
- Не кликает по рекламе, если `click_banner=false`.
- Снимает скриншот при ошибках.
- Отправляет `/task/start`, `/task/complete`, `/task/error`, `/task/event`, `/task/ping`.
- Отправляет расширенный timeline в `/device/log`.
- Держит стабильный `device_id` в `state/device_id.txt`.

## Требования
- Windows 10/11.
- PowerShell 5.1 или PowerShell 7.
- Microsoft Edge или Google Chrome.

## Структура
```text
standalone-windows/
  run.ps1              # вход, главный цикл
  config.example.json
  lib/
    Common.ps1         # логи, конфиг, утилиты
    Device.ps1         # device_id, device_type
    Browser.ps1        # запуск Edge/Chrome
    Cdp.ps1            # websocket, CDP-команды
    Profiles.ps1       # behavior_profile
    Api.ps1            # /task, /device/log, ошибки
    Page.ps1           # probe, cookies, скрины
    Tasks.ps1          # legacy + macro выполнение
```

На Windows копируй **всю папку `standalone-windows`**, не один `run.ps1`.

## Запуск

Два воркера параллельно (как раньше — двойной клик):

```bat
start.bat
```

Откроются 2 окна: Worker 1 и Worker 2. У каждого свой браузер, `device_id` и задача из API.

По отдельности (для отладки):

```bat
start-worker1.bat
start-worker2.bat
```

Через PowerShell напрямую:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\run.ps1 -ConfigPath .\config.example.json
powershell -NoProfile -ExecutionPolicy Bypass -File .\run.ps1 -ConfigPath .\config.worker1.json
powershell -NoProfile -ExecutionPolicy Bypass -File .\run.ps1 -ConfigPath .\config.worker2.json
```

## Два воркера на одном ПК

Каждый воркер — отдельный процесс PowerShell со своим браузером и своим устройством в админке.

| Воркер | Конфиг | CDP порт | `device_id` | Логи |
|---|---|---|---|---|
| 1 | `config.worker1.json` | `9222` | `state/worker1/device_id.txt` | `last-run-worker1.log`, `output/worker1/` |
| 2 | `config.worker2.json` | `9223` | `state/worker2/device_id.txt` | `last-run-worker2.log`, `output/worker2/` |

В конфиге воркера задаётся:

- `workerId` — номер воркера;
- `remoteDebuggingPort` — порт DevTools (у воркеров должны отличаться);
- `stateDir` — отдельная папка для `device_id`;
- `outputRoot` — отдельная папка для логов и скриншотов.

Одиночный режим (1 браузер) через `config.example.json` по-прежнему доступен через PowerShell, но `start.bat` теперь запускает сразу 2 воркера.

## Что менять в конфиге
- `workerId`, `stateDir`, `outputRoot`, `remoteDebuggingPort` - для параллельных воркеров.
- `apiBaseUrl` - адрес удалённой админки.
- `apiTimeoutSec` - таймауты API.
- `heartbeatIntervalSec` - интервал `/task/ping`.
- `emptyQueueWaitSec` и `geoBlockedMinSec`/`geoBlockedMaxSec` - паузы, когда задач нет.
- `captureOnSuccess` - сохранять ли скриншоты на удачных проходах.
- `deviceType` - тип устройства в админке, для этого скрипта должен быть `desktop`.
- `browser.preferred` - какой браузер использовать первым.
- Ошибки дополняются `admin_comment`, `page_state`, `severity`, `checks` и автоматически прикладывают скриншоты, если они есть.

## Выходные данные
После запуска создаётся `output\<timestamp>\`:
- `logs\run.jsonl` - структурированные логи.
- `screenshots\` - скриншоты ошибок.
- `summary.json` - краткий итог запуска.

## Быстрая проверка
1. Поставить Edge или Chrome.
2. Проверить, что `apiBaseUrl` указывает на живую админку.
3. Запустить скрипт и убедиться, что он начал брать задачу из `/task`.
4. Смотреть `logs\run.jsonl`: должны идти события `start`, `browser_started`, `devtools_ready`, `task_start`, `page_probe`, `round_summary`, `task_complete`.
5. Если сайт падает или не грузится, в `screenshots\` должен появляться PNG.

## Важно
- Скрипт рассчитан на постоянную работу, пока его не остановят вручную.
- Текущий `device_id` хранится локально в `state\device_id.txt`.
- Никакой связи с Android-проектом или Gradle здесь нет.
