<#
release.ps1 — собирает релиз самообновляющегося раннера.

Что делает:
  1. Ставит новую версию в version.txt (параметр -Version, иначе авто-инкремент patch).
  2. Пакует код раннера в release\runner.zip (БЕЗ state/output/логов/config.json/.git).
  3. Считает SHA256 и пишет release\version.json (version, zipUrl, sha256, notes).
  4. Если задан -PublishDir (локальная папка репо walker-releases) — копирует туда
     version.json и runner.zip, готовые к git commit/push.

Запуск на Windows:
  powershell -NoProfile -ExecutionPolicy Bypass -File .\release.ps1 -Version 1.0.1 -Notes "fix CDP"
  powershell -NoProfile -ExecutionPolicy Bypass -File .\release.ps1            # авто +0.0.1

Хостинг (по умолчанию): GitHub walker-releases (raw, ветка main).
  updateUrl в config: https://raw.githubusercontent.com/viktoriyatechlead-ship-it/walker-releases/main
#>
param(
    [string]$Version = '',
    [string]$Notes = '',
    [string]$BaseUrl = 'https://raw.githubusercontent.com/viktoriyatechlead-ship-it/walker-releases/main',
    [string]$PublishDir = ''
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$releaseDir = Join-Path $root 'release'

function Bump-Patch {
    param([string]$Current)
    $clean = ($Current.Trim() -replace '^[vV]', '')
    $v = $null
    if (-not [version]::TryParse($clean, [ref]$v)) { return '1.0.0' }
    $build = if ($v.Build -lt 0) { 0 } else { $v.Build }
    return ('{0}.{1}.{2}' -f $v.Major, $v.Minor, ($build + 1))
}

# --- 1. Версия ---
$versionFile = Join-Path $root 'version.txt'
$current = if (Test-Path -LiteralPath $versionFile) { (Get-Content -LiteralPath $versionFile -Raw).Trim() } else { '0.0.0' }
if ([string]::IsNullOrWhiteSpace($Version)) { $Version = Bump-Patch -Current $current }
Set-Content -LiteralPath $versionFile -Value $Version -NoNewline -Encoding ASCII
Write-Host "  Версия: $current -> $Version"

# --- 2. Упаковка ---
if (Test-Path -LiteralPath $releaseDir) { Remove-Item -LiteralPath $releaseDir -Recurse -Force }
New-Item -ItemType Directory -Path $releaseDir | Out-Null
$staging = Join-Path $releaseDir '_staging'
New-Item -ItemType Directory -Path $staging | Out-Null

# В архив идёт только код. Исключаем личные конфиги, состояние, логи, бэкапы.
$excludeTop = @('state', 'output', 'release', '.git')
$excludeFiles = @('config.json', 'config.worker1.json', 'config.worker2.json', '.DS_Store')
$excludeExt = @('.log', '.bak')

Get-ChildItem -LiteralPath $root -Force | Where-Object {
    $excludeTop -notcontains $_.Name
} | ForEach-Object {
    if ($_.PSIsContainer) {
        Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $staging $_.Name) -Recurse -Force
    } elseif (($excludeFiles -notcontains $_.Name) -and ($excludeExt -notcontains $_.Extension.ToLower())) {
        Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $staging $_.Name) -Force
    }
}
# Подчистить, если папки логов всё же попали внутрь
foreach ($junk in @('last-run.log', 'last-run-worker1.log', 'last-run-worker2.log')) {
    $p = Join-Path $staging $junk
    if (Test-Path -LiteralPath $p) { Remove-Item -LiteralPath $p -Force }
}

$zipPath = Join-Path $releaseDir 'runner.zip'
Compress-Archive -Path (Join-Path $staging '*') -DestinationPath $zipPath -Force
Remove-Item -LiteralPath $staging -Recurse -Force

# --- 3. Манифест ---
$sha = (Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash
$manifest = [ordered]@{
    version = $Version
    zipUrl  = ($BaseUrl.TrimEnd('/') + '/runner.zip')
    sha256  = $sha
    notes   = $Notes
    builtAt = (Get-Date).ToString('yyyy-MM-ddTHH:mm:ss')
}
$jsonPath = Join-Path $releaseDir 'version.json'
($manifest | ConvertTo-Json -Depth 4) | Set-Content -LiteralPath $jsonPath -Encoding UTF8

$sizeKb = [int]((Get-Item $zipPath).Length / 1KB)
Write-Host "  runner.zip: $sizeKb KB"
Write-Host "  sha256:     $sha"
Write-Host "  version.json + runner.zip -> $releaseDir"

# --- 4. Публикация в репо walker-releases (если указан) ---
if (-not [string]::IsNullOrWhiteSpace($PublishDir)) {
    if (-not (Test-Path -LiteralPath $PublishDir)) { throw "PublishDir не найден: $PublishDir" }
    Copy-Item -LiteralPath $zipPath -Destination (Join-Path $PublishDir 'runner.zip') -Force
    Copy-Item -LiteralPath $jsonPath -Destination (Join-Path $PublishDir 'version.json') -Force
    Write-Host "  Скопировано в $PublishDir — осталось: git add . && git commit -m `"release $Version`" && git push"
}

Write-Host ''
Write-Host "Готово. Релиз $Version собран."
