param(
    [string]$ConfigPath = (Join-Path $PSScriptRoot 'config.example.json')
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$libDir = Join-Path $PSScriptRoot 'lib'
. (Join-Path $libDir 'Common.ps1')
. (Join-Path $libDir 'Device.ps1')
. (Join-Path $libDir 'Browser.ps1')
. (Join-Path $libDir 'Cdp.ps1')
. (Join-Path $libDir 'Profiles.ps1')
. (Join-Path $libDir 'Api.ps1')
. (Join-Path $libDir 'Page.ps1')
. (Join-Path $libDir 'Tasks.ps1')

$script:lastPingStatus = ''
$config = Read-JsonFile -Path $ConfigPath
$apiBaseUrlValue = Get-ObjectPropertyValue -Object $config -Name 'apiBaseUrl' -Default $null
if ($null -eq $apiBaseUrlValue -or [string]::IsNullOrWhiteSpace([string]$apiBaseUrlValue)) {
    $config | Add-Member -NotePropertyName 'apiBaseUrl' -NotePropertyValue 'http://80.249.147.84:8010' -Force
}
if ($null -eq (Get-ObjectPropertyValue -Object $config -Name 'apiTimeoutSec' -Default $null)) { $config | Add-Member -NotePropertyName 'apiTimeoutSec' -NotePropertyValue 10 -Force }
if ($null -eq (Get-ObjectPropertyValue -Object $config -Name 'apiBypassProxy' -Default $null)) { $config | Add-Member -NotePropertyName 'apiBypassProxy' -NotePropertyValue $true -Force }
if ($null -eq (Get-ObjectPropertyValue -Object $config -Name 'deviceLogAsync' -Default $null)) { $config | Add-Member -NotePropertyName 'deviceLogAsync' -NotePropertyValue $true -Force }
if ($null -eq (Get-ObjectPropertyValue -Object $config -Name 'heartbeatIntervalSec' -Default $null)) { $config | Add-Member -NotePropertyName 'heartbeatIntervalSec' -NotePropertyValue 15 -Force }
if ($null -eq (Get-ObjectPropertyValue -Object $config -Name 'heartbeatRetryDelaySec' -Default $null)) { $config | Add-Member -NotePropertyName 'heartbeatRetryDelaySec' -NotePropertyValue 5 -Force }
if ($null -eq (Get-ObjectPropertyValue -Object $config -Name 'webViewReadyTimeoutSec' -Default $null)) { $config | Add-Member -NotePropertyName 'webViewReadyTimeoutSec' -NotePropertyValue 15 -Force }
if ($null -eq (Get-ObjectPropertyValue -Object $config -Name 'pageReadyTimeoutSec' -Default $null)) { $config | Add-Member -NotePropertyName 'pageReadyTimeoutSec' -NotePropertyValue 25 -Force }
if ($null -eq (Get-ObjectPropertyValue -Object $config -Name 'pageReadyForHumanMaxWaitMs' -Default $null)) { $config | Add-Member -NotePropertyName 'pageReadyForHumanMaxWaitMs' -NotePropertyValue 8000 -Force }
if ($null -eq (Get-ObjectPropertyValue -Object $config -Name 'emptyQueueWaitSec' -Default $null)) { $config | Add-Member -NotePropertyName 'emptyQueueWaitSec' -NotePropertyValue 60 -Force }
if ($null -eq (Get-ObjectPropertyValue -Object $config -Name 'geoBlockedMinSec' -Default $null)) { $config | Add-Member -NotePropertyName 'geoBlockedMinSec' -NotePropertyValue 60 -Force }
if ($null -eq (Get-ObjectPropertyValue -Object $config -Name 'geoBlockedMaxSec' -Default $null)) { $config | Add-Member -NotePropertyName 'geoBlockedMaxSec' -NotePropertyValue 120 -Force }
if ($null -eq (Get-ObjectPropertyValue -Object $config -Name 'captureOnSuccess' -Default $null)) { $config | Add-Member -NotePropertyName 'captureOnSuccess' -NotePropertyValue $false -Force }
if ($null -eq (Get-ObjectPropertyValue -Object $config -Name 'clientVersion' -Default $null)) { $config | Add-Member -NotePropertyName 'clientVersion' -NotePropertyValue 'windows-ps/1.0' -Force }
if ($null -eq (Get-ObjectPropertyValue -Object $config -Name 'behaviorProfile' -Default $null)) { $config | Add-Member -NotePropertyName 'behaviorProfile' -NotePropertyValue 'scanner' -Force }
if ($null -eq (Get-ObjectPropertyValue -Object $config -Name 'remoteDebuggingPort' -Default $null)) { $config | Add-Member -NotePropertyName 'remoteDebuggingPort' -NotePropertyValue 9222 -Force }
if ($null -eq (Get-ObjectPropertyValue -Object $config -Name 'browserReadyTimeoutSec' -Default $null)) { $config | Add-Member -NotePropertyName 'browserReadyTimeoutSec' -NotePropertyValue 20 -Force }
if ($null -eq (Get-ObjectPropertyValue -Object $config -Name 'maxTextSampleChars' -Default $null)) { $config | Add-Member -NotePropertyName 'maxTextSampleChars' -NotePropertyValue 1200 -Force }

$workerSettings = Resolve-WorkerSettings -Config $config -RootDir $PSScriptRoot
$runId = New-RunTimestamp
$runRoot = Join-Path $workerSettings.OutputRoot $runId
$logDir = Join-Path $runRoot 'logs'
$screenshotDir = Join-Path $runRoot 'screenshots'
$profileDir = Join-Path $runRoot 'browser-profile'
$stateDir = $workerSettings.StateDir

Ensure-Directory -Path $runRoot
Ensure-Directory -Path $logDir
Ensure-Directory -Path $screenshotDir
Ensure-Directory -Path $profileDir
Ensure-Directory -Path $stateDir

$context = [pscustomobject]@{
    RunId        = $runId
    RunRoot      = $runRoot
    LogPath      = (Join-Path $logDir 'run.jsonl')
    SummaryPath  = (Join-Path $runRoot 'summary.json')
    ScreenshotDir = $screenshotDir
    ProfileDir   = $profileDir
    WorkerId     = $workerSettings.WorkerId
}

$deviceId = Get-OrCreateDeviceId -StateDir $stateDir
$sessionId = 'sess-' + [System.Guid]::NewGuid().ToString('N').Substring(0, 12)
$baseMeta = New-BaseMeta -Config $config -DeviceId $deviceId -SessionId $sessionId
$browserConfig = Get-ObjectPropertyValue -Object $config -Name 'browser' -Default $null
$browserPath = Resolve-BrowserPath -BrowserConfig $browserConfig
$port = $workerSettings.Port
$browserReadyTimeoutSec = [int](Get-ObjectPropertyValue -Object $config -Name 'browserReadyTimeoutSec' -Default 20)
$extraArgs = @()
if ($null -ne $browserConfig) {
    $browserExtraArgs = Get-ObjectPropertyValue -Object $browserConfig -Name 'extraArgs' -Default $null
    if ($null -ne $browserExtraArgs) { $extraArgs = @($browserExtraArgs) }
}

$proxyMode = 'direct'
$script:BlockedDomains = @()
$script:BrowserProcess = $null
$script:CdpConnected = $false
$script:MainTargetId = ''
$script:ProxyConfigHash = ''
$script:ActiveProxyMode = 'direct'
$script:ActiveExtraArgs = @()

function Get-ProxyHash {
    param([string]$Mode, [string]$ProxyHost, [string]$Port)
    return "${Mode}|${ProxyHost}|${Port}"
}

function Invoke-BrowserRestart {
    param([string]$NewMode, [array]$NewExtraArgs)

    Write-RunLog -Context $context -Level 'INFO' -Event 'proxy_restart' -Message "Restarting browser: proxy mode changed to $NewMode"

    if ($script:CdpConnected) {
        try { Close-CdpWebSocket } catch {}
        $script:CdpConnected = $false
    }
    if ($null -ne $script:BrowserProcess -and -not $script:BrowserProcess.HasExited) {
        try { Stop-Process -Id $script:BrowserProcess.Id -Force } catch {}
        Start-Sleep -Milliseconds 2500
    }
    $script:BrowserProcess = $null

    $script:BrowserProcess = Start-BrowserProcess -BrowserPath $browserPath -Port $port -UserDataDir $profileDir -ExtraArgs $NewExtraArgs
    $endpointInfo = Wait-ForDebuggerEndpoint -Port $port -TimeoutSec $browserReadyTimeoutSec
    $target = $endpointInfo.target
    Connect-CdpWebSocket -WebSocketUrl $target.webSocketDebuggerUrl
    $script:CdpConnected = $true
    $newTargetId = [string](Get-ObjectPropertyValue -Object $target -Name 'id' -Default '')
    if (-not [string]::IsNullOrWhiteSpace($newTargetId)) {
        Set-MainCdpTarget -TargetId $newTargetId -Port $port
        $script:MainTargetId = $newTargetId
    }
    foreach ($cdpStep in @('Page.enable', 'Runtime.enable', 'DOM.enable', 'Network.enable', 'Input.enable', 'Storage.enable')) {
        try { Invoke-CdpCommand -Method $cdpStep -TimeoutSec 10 | Out-Null } catch {}
    }
    try {
        Invoke-CdpCommand -Method 'Network.setBlockedURLs' -Params @{
            urls = @(
                '*optimizationguide-pa.googleapis.com*',
                '*safebrowsing.googleapis.com*',
                '*update.googleapis.com*',
                '*clients4.google.com*',
                '*clients2.google.com*',
                '*play.googleapis.com*',
                '*doubleclick.net*',
                '*google-analytics.com*'
            )
        } -TimeoutSec 8 | Out-Null
    } catch {}
    try {
        Invoke-CdpCommand -Method 'Network.setExtraHTTPHeaders' -Params @{
            headers = @{ 'Accept-Language' = 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7' }
        } -TimeoutSec 8 | Out-Null
    } catch {}
    # Fetch interception is only for proxy auth the browser must answer itself. Behind gost the
    # login is empty, and an enabled Fetch pauses every request with nobody to continue it.
    if ($NewMode -eq 'proxy' -and -not [string]::IsNullOrWhiteSpace($script:ProxyLogin)) {
        try { Invoke-CdpCommand -Method 'Fetch.enable' -Params @{ handleAuthRequests = $true } -TimeoutSec 10 | Out-Null } catch {}
    }
    try { Set-CdpStealth } catch {}
    $script:ActiveProxyMode = $NewMode
    $script:ActiveExtraArgs = $NewExtraArgs
    Write-RunLog -Context $context -Level 'INFO' -Event 'proxy_restart_done' -Message "Browser restarted with proxy mode: $NewMode"
}

try {
    $proxyApiResponse = Get-ProxyConfig -Config $config -DeviceId $deviceId
    # Static proxy fallback: if the API gave no proxy, use the 'proxy' block from config (ASCII only).
    $staticProxyCfg = Get-ObjectPropertyValue -Object $config -Name 'proxy' -Default $null
    $apiHasProxy = ($null -ne $proxyApiResponse -and [bool](Get-ObjectPropertyValue -Object $proxyApiResponse -Name 'proxy_enabled' -Default $false))
    if (-not $apiHasProxy -and $null -ne $staticProxyCfg) {
        $spHost = [string](Get-ObjectPropertyValue -Object $staticProxyCfg -Name 'host' -Default '')
        if (-not [string]::IsNullOrWhiteSpace($spHost)) {
            $proxyApiResponse = [pscustomobject]@{
                proxy_enabled = $true
                mode          = 'proxy'
                proxy         = [pscustomobject]@{
                    host     = $spHost
                    port     = [string](Get-ObjectPropertyValue -Object $staticProxyCfg -Name 'port' -Default '443')
                    login    = [string](Get-ObjectPropertyValue -Object $staticProxyCfg -Name 'login' -Default '')
                    password = [string](Get-ObjectPropertyValue -Object $staticProxyCfg -Name 'password' -Default '')
                }
            }
        }
    }
    if ($null -ne $proxyApiResponse -and
        [bool](Get-ObjectPropertyValue -Object $proxyApiResponse -Name 'proxy_enabled' -Default $false) -and
        [string](Get-ObjectPropertyValue -Object $proxyApiResponse -Name 'mode' -Default 'direct') -eq 'proxy') {
        $proxyData = Get-ObjectPropertyValue -Object $proxyApiResponse -Name 'proxy' -Default $null
        if ($null -ne $proxyData) {
            $proxyHost = [string](Get-ObjectPropertyValue -Object $proxyData -Name 'host' -Default '')
            $proxyPort = [string](Get-ObjectPropertyValue -Object $proxyData -Name 'port' -Default '3128')
            $proxyLogin = [string](Get-ObjectPropertyValue -Object $proxyData -Name 'login' -Default '')
            $proxyPassword = [string](Get-ObjectPropertyValue -Object $proxyData -Name 'password' -Default '')
            if (-not [string]::IsNullOrWhiteSpace($proxyHost)) {
                $proxyMode = 'proxy'
                $gostExe = Join-Path $root 'gost.exe'
                if ((-not (Test-Path -LiteralPath $gostExe)) -and -not [string]::IsNullOrWhiteSpace($proxyLogin)) {
                    try {
                        $gz = Join-Path $env:TEMP 'gostwin.zip'
                        [Net.ServicePointManager]::SecurityProtocol = 'Tls12'
                        Invoke-WebRequest -Uri 'https://github.com/ginuerzh/gost/releases/download/v2.11.5/gost-windows-amd64-2.11.5.zip' -OutFile $gz -TimeoutSec 120 -UseBasicParsing
                        $exdir = Join-Path $env:TEMP ('gostdl-' + [Guid]::NewGuid().ToString('N'))
                        Expand-Archive -LiteralPath $gz -DestinationPath $exdir -Force
                        $found = Get-ChildItem -LiteralPath $exdir -Filter '*.exe' -Recurse | Select-Object -First 1
                        if ($null -ne $found) { Copy-Item -LiteralPath $found.FullName -Destination $gostExe -Force }
                        Remove-Item -LiteralPath $gz -Force -ErrorAction SilentlyContinue
                        Remove-Item -LiteralPath $exdir -Recurse -Force -ErrorAction SilentlyContinue
                        Write-Host 'PROXY: gost.exe downloaded'
                    } catch { Write-Host "PROXY: gost download failed ($($_.Exception.Message))" }
                }
                if ((Test-Path -LiteralPath $gostExe) -and -not [string]::IsNullOrWhiteSpace($proxyLogin)) {
                    # Local no-auth forwarder via gost -> upstream proxy with auth. Browser never sees a proxy auth dialog.
                    $localPort = 9000 + [int]$workerSettings.WorkerId
                    try { Stop-ProcessOnPort -Port $localPort } catch {}
                    $fwd = "http://${proxyLogin}:${proxyPassword}@${proxyHost}:${proxyPort}"
                    Start-Process -FilePath $gostExe -ArgumentList "-L=http://127.0.0.1:$localPort", "-F=$fwd" -WindowStyle Hidden | Out-Null
                    Start-Sleep -Milliseconds 1500
                    # Remember the upstream address: the per-task refresh compares against it, not the local forwarder.
                    $script:UpstreamHashHost = $proxyHost; $script:UpstreamHashPort = $proxyPort
                    $proxyHost = '127.0.0.1'; $proxyPort = "$localPort"; $proxyLogin = ''; $proxyPassword = ''
                    Write-Host "PROXY: gost forwarder on 127.0.0.1:$localPort"
                }
                $extraArgs = @("--proxy-server=http://${proxyHost}:${proxyPort}") + $extraArgs
                Set-CdpProxyCredentials -Login $proxyLogin -Password $proxyPassword
            }
        }
    }
    $rawBlocked = Get-ObjectPropertyValue -Object $proxyApiResponse -Name 'blocked_domains' -Default @()
    if ($null -ne $rawBlocked) { $script:BlockedDomains = @($rawBlocked) }
    $script:ProxyConfigHash = Get-ProxyHash -Mode $proxyMode -ProxyHost $(if ($null -ne $proxyHost) { $proxyHost } else { '' }) -Port $(if ($null -ne $proxyPort) { $proxyPort } else { '' })
    if ($script:UpstreamHashHost) { $script:ProxyConfigHash = Get-ProxyHash -Mode $proxyMode -ProxyHost $script:UpstreamHashHost -Port $script:UpstreamHashPort }
    $script:ActiveProxyMode = $proxyMode
    $script:ActiveExtraArgs = $extraArgs
} catch {}

Write-RunLog -Context $context -Level 'INFO' -Event 'start' -Message 'Standalone Windows task worker started' -Data @{ runId = $runId; worker_id = $workerSettings.WorkerId; device_id = $deviceId; browser = $browserPath; port = $port; state_dir = $stateDir; apiBaseUrl = $config.apiBaseUrl }
Trace-DeviceLog -Config $config -Context $context -DeviceId $deviceId -Level 'INFO' -EventType 'start' -Message 'Standalone Windows task worker started' -Meta ([pscustomobject]@{ runId = $runId; worker_id = $workerSettings.WorkerId; browser = $browserPath; port = $port; state_dir = $stateDir; apiBaseUrl = $config.apiBaseUrl })

$queuedTask = $null
$lastFetchReason = $null

try {
    $script:BrowserProcess = Start-BrowserProcess -BrowserPath $browserPath -Port $port -UserDataDir $profileDir -ExtraArgs $extraArgs
    Write-RunLog -Context $context -Level 'INFO' -Event 'browser_started' -Message 'Browser process started' -Data @{ pid = $script:BrowserProcess.Id }
    Trace-DeviceLog -Config $config -Context $context -DeviceId $deviceId -Level 'INFO' -EventType 'browser_started' -Message 'Browser process started' -Meta ([pscustomobject]@{ pid = $script:BrowserProcess.Id })

    $endpointInfo = Wait-ForDebuggerEndpoint -Port $port -TimeoutSec $browserReadyTimeoutSec
    $target = $endpointInfo.target
    Write-RunLog -Context $context -Level 'INFO' -Event 'devtools_ready' -Message 'DevTools endpoint is ready' -Data @{ title = $target.title; url = $target.url }
    Trace-DeviceLog -Config $config -Context $context -DeviceId $deviceId -Level 'INFO' -EventType 'devtools_ready' -Message 'DevTools endpoint is ready' -Meta ([pscustomobject]@{ title = $target.title; url = $target.url })

    Connect-CdpWebSocket -WebSocketUrl $target.webSocketDebuggerUrl
    $script:CdpConnected = $true
    $script:MainTargetId = [string](Get-ObjectPropertyValue -Object $target -Name 'id' -Default '')
    if (-not [string]::IsNullOrWhiteSpace($script:MainTargetId)) {
        Set-MainCdpTarget -TargetId $script:MainTargetId -Port $port
    }
    Write-RunLog -Context $context -Level 'INFO' -Event 'cdp_connected' -Message 'CDP websocket connected' -Data @{ webSocketUrl = $target.webSocketDebuggerUrl; targetId = $script:MainTargetId }
    Trace-DeviceLog -Config $config -Context $context -DeviceId $deviceId -Level 'INFO' -EventType 'cdp_connected' -Message 'CDP websocket connected' -Meta ([pscustomobject]@{ webSocketUrl = $target.webSocketDebuggerUrl })

    foreach ($cdpStep in @('Page.enable', 'Runtime.enable', 'DOM.enable', 'Network.enable', 'Input.enable', 'Storage.enable')) {
        try {
            Write-RunLog -Context $context -Level 'INFO' -Event 'cdp_init' -Message "CDP init step started: $cdpStep" -Data @{ step = $cdpStep }
            Trace-DeviceLog -Config $config -Context $context -DeviceId $deviceId -Level 'INFO' -EventType 'cdp_init' -Message "CDP init step started: $cdpStep" -Meta ([pscustomobject]@{ step = $cdpStep })
            Invoke-CdpCommand -Method $cdpStep -TimeoutSec 10 | Out-Null
            Write-RunLog -Context $context -Level 'INFO' -Event 'cdp_init' -Message "CDP init step done: $cdpStep" -Data @{ step = $cdpStep }
            Trace-DeviceLog -Config $config -Context $context -DeviceId $deviceId -Level 'INFO' -EventType 'cdp_init_done' -Message "CDP init step done: $cdpStep" -Meta ([pscustomobject]@{ step = $cdpStep })
        } catch {
            if ($cdpStep -in @('Storage.enable', 'Input.enable')) {
                Write-RunLog -Context $context -Level 'WARN' -Event 'cdp_init' -Message "CDP init step skipped: $cdpStep" -Data @{ step = $cdpStep; error = $_.Exception.Message }
                Trace-DeviceLog -Config $config -Context $context -DeviceId $deviceId -Level 'WARN' -EventType 'cdp_init_skipped' -Message "CDP init step skipped: $cdpStep" -Meta ([pscustomobject]@{ step = $cdpStep; error = $_.Exception.Message })
                continue
            }
            throw
        }
    }
    try {
        Invoke-CdpCommand -Method 'Network.setBlockedURLs' -Params @{
            urls = @(
                '*optimizationguide-pa.googleapis.com*',
                '*safebrowsing.googleapis.com*',
                '*update.googleapis.com*',
                '*clients4.google.com*',
                '*clients2.google.com*',
                '*play.googleapis.com*',
                '*doubleclick.net*',
                '*google-analytics.com*'
            )
        } -TimeoutSec 8 | Out-Null
    } catch {}
    try {
        Invoke-CdpCommand -Method 'Network.setExtraHTTPHeaders' -Params @{
            headers = @{ 'Accept-Language' = 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7' }
        } -TimeoutSec 8 | Out-Null
    } catch {}

    # Fetch interception is only for proxy auth the browser must answer itself. Behind gost the
    # login is empty, and an enabled Fetch pauses every request with nobody to continue it.
    if ($proxyMode -eq 'proxy' -and -not [string]::IsNullOrWhiteSpace($script:ProxyLogin)) {
        try {
            Invoke-CdpCommand -Method 'Fetch.enable' -Params @{ handleAuthRequests = $true } -TimeoutSec 10 | Out-Null
            Write-RunLog -Context $context -Level 'INFO' -Event 'proxy_fetch_enabled' -Message 'Fetch.enable with proxy auth handling activated'
        } catch {
            Write-RunLog -Context $context -Level 'WARN' -Event 'proxy_fetch_failed' -Message "Fetch.enable failed: $($_.Exception.Message)"
        }
    }

    try { Set-CdpStealth; Write-RunLog -Context $context -Level 'INFO' -Event 'stealth' -Message 'Stealth fingerprint injected' } catch {}

    $localDeviceType = Get-DeviceType -Config $config
    Write-RunLog -Context $context -Level 'INFO' -Event 'worker_ready' -Message 'Worker ready. Browser stays on about:blank until a task arrives from API.' -Data @{
        device_id   = $deviceId
        device_type = $localDeviceType
        apiBaseUrl  = $config.apiBaseUrl
    }
    Trace-DeviceLog -Config $config -Context $context -DeviceId $deviceId -Level 'INFO' -EventType 'worker_ready' -Message 'Worker ready. Browser stays on about:blank until a task arrives from API.' -Meta ([pscustomobject]@{
        device_id   = $deviceId
        device_type = $localDeviceType
        apiBaseUrl  = $config.apiBaseUrl
    })

    $consecutiveFailures = 0
    while ($true) {
        $task = $null
        if ($null -ne $queuedTask) {
            $task = $queuedTask
            $queuedTask = $null
        } else {
            try {
                $apiResponse = Invoke-ApiGetTask -Config $config -DeviceId $deviceId -DeviceType (Get-DeviceType -Config $config)
            } catch {
                $err = $_.Exception.Message
                Write-RunLog -Context $context -Level 'ERROR' -Event 'fetch_error' -Message "Fetch task error: $err" -Data @{ exception = $_.Exception.GetType().Name }
                Trace-DeviceLog -Config $config -Context $context -DeviceId $deviceId -Level 'ERROR' -EventType 'fetch_error' -Message "Fetch task error: $err" -Meta $baseMeta
                Wait-WithChecks -DurationMs (10000) | Out-Null
                continue
            }

            if ($null -eq $apiResponse -or $null -eq $apiResponse.task) {
                $lastFetchReason = $null
                if ($null -ne $apiResponse) {
                    $lastFetchReason = Get-ObjectPropertyValue -Object $apiResponse -Name 'reason' -Default $null
                    if ($null -ne $lastFetchReason) { $lastFetchReason = [string]$lastFetchReason }
                }
                $waitSec = if ($lastFetchReason -eq 'geo_blocked') { Random-IntInclusive -Min ([int]$config.geoBlockedMinSec) -Max ([int]$config.geoBlockedMaxSec) } else { [int]$config.emptyQueueWaitSec }
                Write-RunLog -Context $context -Level 'INFO' -Event 'empty_queue' -Message "No tasks from API, waiting $waitSec seconds (device_id=$deviceId)" -Data @{ reason = $lastFetchReason; device_id = $deviceId; device_type = $localDeviceType; apiBaseUrl = $config.apiBaseUrl; wait_sec = $waitSec }
                Trace-DeviceLog -Config $config -Context $context -DeviceId $deviceId -Level 'INFO' -EventType 'empty_queue' -Message "No tasks from API, waiting $waitSec seconds (device_id=$deviceId)" -Meta ([pscustomobject]@{ reason = $lastFetchReason; device_id = $deviceId; device_type = $localDeviceType; apiBaseUrl = $config.apiBaseUrl; wait_sec = $waitSec })
                Wait-WithChecks -DurationMs ($waitSec * 1000) | Out-Null
                continue
            }

            $apiDevice = Get-ObjectPropertyValue -Object $apiResponse -Name 'device' -Default $null
            $apiDeviceType = if ($null -ne $apiDevice) { Get-ObjectPropertyValue -Object $apiDevice -Name 'device_type' -Default $null } else { $null }
            if ($null -ne $apiDeviceType) {
                Write-RunLog -Context $context -Level 'INFO' -Event 'device_classified' -Message "Backend classified device as $apiDeviceType" -Data @{ device_type = [string]$apiDeviceType; local_device_type = (Get-DeviceType -Config $config) }
                Trace-DeviceLog -Config $config -Context $context -DeviceId $deviceId -Level 'INFO' -EventType 'device_classified' -Message "Backend classified device as $apiDeviceType" -Meta ([pscustomobject]@{ device_type = [string]$apiDeviceType; local_device_type = (Get-DeviceType -Config $config) })
            }
            $task = $apiResponse.task
            $assignedDeviceId = Get-TaskAssignedDeviceId -Task $task
            if ($null -ne $assignedDeviceId -and $assignedDeviceId -ne $deviceId) {
                Write-RunLog -Context $context -Level 'INFO' -Event 'task_skipped' -Message "Task assigned to another device" -Data @{ assigned_device_id = $assignedDeviceId; local_device_id = $deviceId; task_id = $task.id }
                Trace-DeviceLog -Config $config -Context $context -DeviceId $deviceId -TaskId $task.id -Level 'INFO' -EventType 'task_skipped' -Message 'Task assigned to another device' -Meta ([pscustomobject]@{ assigned_device_id = $assignedDeviceId; local_device_id = $deviceId; task_id = $task.id })
                $task = $null
            }
        }

        if ($null -eq $task) {
            continue
        }

        if (-not (Ensure-CdpSession -Port $port -PreferredTargetId $script:MainTargetId)) {
            Write-RunLog -Context $context -Level 'WARN' -Event 'cdp_reconnect' -Message 'CDP session restore failed before task' -Data @{ task_id = $task.id; port = $port }
            Wait-WithChecks -DurationMs 3000 | Out-Null
            if (-not (Ensure-CdpSession -Port $port -PreferredTargetId $script:MainTargetId)) {
                Write-RunLog -Context $context -Level 'ERROR' -Event 'cdp_reconnect' -Message 'CDP session restore failed twice, skipping task' -Data @{ task_id = $task.id; port = $port }
                Wait-WithChecks -DurationMs 5000 | Out-Null
                continue
            }
        }

        if ([string]$task.type -ne 'open_url') {
            [void](Post-Error -Config $config -Context $context -Task $task -DeviceId $deviceId -ErrorCode 'js_exception' -LogText "Unknown task type: $($task.type)" -Meta ([pscustomobject]@{ reason = 'unknown_task_type' }))
            continue
        }

        # Refresh proxy config before each task (blocked_domains + limit check + change detection)
        try {
            $freshProxy = Get-ProxyConfig -Config $config -DeviceId $deviceId
            if ($null -ne $freshProxy) {
                $rawBlocked = Get-ObjectPropertyValue -Object $freshProxy -Name 'blocked_domains' -Default @()
                if ($null -ne $rawBlocked) { $script:BlockedDomains = @($rawBlocked) }

                $limitExceeded = [bool](Get-ObjectPropertyValue -Object $freshProxy -Name 'limit_exceeded' -Default $false)
                if ($limitExceeded) {
                    $mbToday = [string](Get-ObjectPropertyValue -Object $freshProxy -Name 'bytes_today_mb' -Default '0')
                    Write-RunLog -Context $context -Level 'WARN' -Event 'proxy_limit_exceeded' -Message "Traffic limit exceeded today (${mbToday} MB), device in direct mode" -Data @{ device_id = $deviceId; bytes_today_mb = $mbToday }
                }

                # Detect proxy mode/host/port change -> restart browser with new args
                $freshMode = [string](Get-ObjectPropertyValue -Object $freshProxy -Name 'mode' -Default 'direct')
                $freshEnabled = [bool](Get-ObjectPropertyValue -Object $freshProxy -Name 'proxy_enabled' -Default $false)
                $freshProxyData = if ($freshEnabled -and $freshMode -eq 'proxy') { Get-ObjectPropertyValue -Object $freshProxy -Name 'proxy' -Default $null } else { $null }
                $freshHost = if ($null -ne $freshProxyData) { [string](Get-ObjectPropertyValue -Object $freshProxyData -Name 'host' -Default '') } else { '' }
                $freshPort = if ($null -ne $freshProxyData) { [string](Get-ObjectPropertyValue -Object $freshProxyData -Name 'port' -Default '') } else { '' }
                $freshHash = Get-ProxyHash -Mode $freshMode -ProxyHost $freshHost -Port $freshPort

                if ($freshHash -ne $script:ProxyConfigHash -and $script:ProxyConfigHash -ne '') {
                    $freshLogin = if ($null -ne $freshProxyData) { [string](Get-ObjectPropertyValue -Object $freshProxyData -Name 'login' -Default '') } else { '' }
                    $freshPassword = if ($null -ne $freshProxyData) { [string](Get-ObjectPropertyValue -Object $freshProxyData -Name 'password' -Default '') } else { '' }
                    $newExtraArgs = @()
                    if ($freshMode -eq 'proxy' -and -not [string]::IsNullOrWhiteSpace($freshHost)) {
                        $gostExe = Join-Path $root 'gost.exe'
                        if (-not [string]::IsNullOrWhiteSpace($freshLogin) -and (Test-Path -LiteralPath $gostExe)) {
                            # Same as at startup: a local no-auth gost forwarder carries the login, so the
                            # browser needs neither credentials nor Fetch interception (which stalls pages).
                            $localPort = 9000 + [int]$workerSettings.WorkerId
                            try { Stop-ProcessOnPort -Port $localPort } catch {}
                            Start-Process -FilePath $gostExe -ArgumentList "-L=http://127.0.0.1:$localPort", "-F=http://${freshLogin}:${freshPassword}@${freshHost}:${freshPort}" -WindowStyle Hidden | Out-Null
                            Start-Sleep -Milliseconds 1500
                            $newExtraArgs = @("--proxy-server=http://127.0.0.1:$localPort")
                            Set-CdpProxyCredentials -Login '' -Password ''
                            Write-RunLog -Context $context -Level 'INFO' -Event 'proxy_gost_restart' -Message "Proxy switched on the fly via gost on 127.0.0.1:$localPort"
                        } else {
                            $newExtraArgs = @("--proxy-server=http://${freshHost}:${freshPort}")
                            Set-CdpProxyCredentials -Login $freshLogin -Password $freshPassword
                        }
                    } else {
                        Set-CdpProxyCredentials -Login '' -Password ''
                    }
                    # Carry over non-proxy extra args from original config
                    foreach ($arg in $script:ActiveExtraArgs) {
                        if (-not $arg.StartsWith('--proxy-server=')) { $newExtraArgs += $arg }
                    }
                    try {
                        Invoke-BrowserRestart -NewMode $freshMode -NewExtraArgs $newExtraArgs
                        $script:ProxyConfigHash = $freshHash
                    } catch {
                        Write-RunLog -Context $context -Level 'WARN' -Event 'proxy_restart_failed' -Message "Browser restart for proxy change failed: $($_.Exception.Message)"
                    }
                }
            }
        } catch {}

        # Check if task URL domain is blocked
        $taskUrl = [string](Get-ObjectPropertyValue -Object $task -Name 'url' -Default '')
        $taskHost = ''
        try { $taskHost = ([Uri]$taskUrl).Host } catch {}
        if ($taskHost -ne '' -and $script:BlockedDomains.Count -gt 0 -and $script:BlockedDomains -contains $taskHost) {
            Write-RunLog -Context $context -Level 'WARN' -Event 'blocked_domain' -Message "Task URL domain is blocked: $taskHost" -Data @{ task_id = $task.id; domain = $taskHost }
            [void](Post-Error -Config $config -Context $context -Task $task -DeviceId $deviceId -ErrorCode 'blocked_domain' -LogText "Domain $taskHost is blocked by proxy settings" -Meta ([pscustomobject]@{ blocked_domain = $taskHost; reason = 'blocked_domain' }))
            continue
        }

        # Per-task proxy_mode override ('proxy' | 'direct' | 'auto')
        $taskProxyMode = [string](Get-ObjectPropertyValue -Object $task -Name 'proxy_mode' -Default 'auto')
        if ($taskProxyMode -ne 'auto' -and $taskProxyMode -ne $script:ActiveProxyMode) {
            $targetMode = $taskProxyMode
            $newArgs = $script:ActiveExtraArgs | Where-Object { $_ -notlike '--proxy-server=*' }
            if ($targetMode -eq 'proxy' -and -not [string]::IsNullOrWhiteSpace($proxyHost)) {
                $newArgs = @("--proxy-server=http://${proxyHost}:${proxyPort}") + $newArgs
            }
            Invoke-BrowserRestart -NewMode $targetMode -NewExtraArgs $newArgs
        }

        Reset-SessionTraffic

        $result = $null
        try {
            $result = Invoke-BehaviorProfileTask -Config $config -Context $context -Task $task -DeviceId $deviceId -Meta $baseMeta
        } catch {
            $result = Report-TaskExecutionError -Step 'run.task_loop' -ErrorRecord $_ -Config $config -Context $context -Task $task -DeviceId $deviceId -Meta $baseMeta
        }

        Invoke-CdpDrain
        Process-NetworkTrafficEvents
        $trafficSummary = Get-SessionTrafficSummary
        if ($trafficSummary.bytes_total -gt 0) {
            Post-Traffic -Config $config -DeviceId $deviceId -TaskId $task.id -BytesTotal $trafficSummary.bytes_total -Domains $trafficSummary.domains -Mode $script:ActiveProxyMode
        }

        if ($null -eq $result) {
            Wait-WithChecks -DurationMs 10000 | Out-Null
            continue
        }

        $taskSuccess = [bool](Get-ObjectPropertyValue -Object $result -Name 'success' -Default $false)
        if (-not $taskSuccess) {
            $consecutiveFailures++
            [void](Ensure-CdpSession -Port $port -PreferredTargetId $script:MainTargetId)
            Wait-WithChecks -DurationMs 2000 | Out-Null
            # Wedged-browser recovery: reconnecting the socket is useless if the renderer
            # itself is hung (Runtime.evaluate timeouts). After 2 failures in a row, do a
            # full browser restart to recover.
            if ($consecutiveFailures -ge 2) {
                Write-RunLog -Context $context -Level 'WARN' -Event 'browser_recover' -Message "Restarting browser after $consecutiveFailures consecutive failures (wedged CDP recovery)" -Data @{ failures = $consecutiveFailures }
                try {
                    Invoke-BrowserRestart -NewMode $script:ActiveProxyMode -NewExtraArgs $script:ActiveExtraArgs
                    Write-RunLog -Context $context -Level 'INFO' -Event 'browser_recover' -Message 'Browser restarted for recovery'
                } catch {
                    Write-RunLog -Context $context -Level 'WARN' -Event 'browser_recover' -Message "Recovery restart failed: $($_.Exception.Message)"
                }
                $consecutiveFailures = 0
            }
        } else {
            $consecutiveFailures = 0
        }
        if ($taskSuccess) {
            $completionMeta = Get-ObjectPropertyValue -Object $result -Name 'completionMeta' -Default $null
            if ($null -ne $completionMeta) {
                [void](Post-Complete -Config $config -Context $context -Task $task -DeviceId $deviceId -Meta $completionMeta)
            } else {
                Send-TaskComplete -Config $config -Context $context -Task $task -DeviceId $deviceId -Result $result -SessionId $baseMeta.session_id
            }
        }

        try {
            $nextResponse = Invoke-ApiGetTask -Config $config -DeviceId $deviceId -DeviceType (Get-DeviceType -Config $config)
        } catch {
            $err = $_.Exception.Message
            Write-RunLog -Context $context -Level 'ERROR' -Event 'fetch_error' -Message "Fetch task error: $err" -Data @{ exception = $_.Exception.GetType().Name }
                Trace-DeviceLog -Config $config -Context $context -DeviceId $deviceId -Level 'ERROR' -EventType 'fetch_error' -Message "Fetch task error: $err" -Meta $baseMeta
            Wait-WithChecks -DurationMs (10000) | Out-Null
            continue
        }

        $nextResponseTask = if ($null -ne $nextResponse) { Get-ObjectPropertyValue -Object $nextResponse -Name 'task' -Default $null } else { $null }
        if ($null -eq $nextResponse -or $null -eq $nextResponseTask) {
            $lastFetchReason = $null
            if ($null -ne $nextResponse) {
                $r = Get-ObjectPropertyValue -Object $nextResponse -Name 'reason' -Default $null
                if ($null -ne $r) { $lastFetchReason = [string]$r }
            }
            $waitSec = if ($lastFetchReason -eq 'geo_blocked') { Random-IntInclusive -Min ([int]$config.geoBlockedMinSec) -Max ([int]$config.geoBlockedMaxSec) } else { [int]$config.emptyQueueWaitSec }
            Write-RunLog -Context $context -Level 'INFO' -Event 'empty_queue' -Message "No tasks from API, waiting $waitSec seconds (device_id=$deviceId)" -Data @{ reason = $lastFetchReason; device_id = $deviceId; device_type = $localDeviceType; apiBaseUrl = $config.apiBaseUrl; wait_sec = $waitSec }
            Trace-DeviceLog -Config $config -Context $context -DeviceId $deviceId -Level 'INFO' -EventType 'empty_queue' -Message "No tasks from API, waiting $waitSec seconds (device_id=$deviceId)" -Meta ([pscustomobject]@{ reason = $lastFetchReason; device_id = $deviceId; device_type = $localDeviceType; apiBaseUrl = $config.apiBaseUrl; wait_sec = $waitSec })
            Wait-WithChecks -DurationMs ($waitSec * 1000) | Out-Null
            continue
        }

        $nextDevice = Get-ObjectPropertyValue -Object $nextResponse -Name 'device' -Default $null
        $nextDeviceType = if ($null -ne $nextDevice) { Get-ObjectPropertyValue -Object $nextDevice -Name 'device_type' -Default $null } else { $null }
        if ($null -ne $nextDeviceType) {
            Write-RunLog -Context $context -Level 'INFO' -Event 'device_classified' -Message "Backend classified device as $nextDeviceType" -Data @{ device_type = [string]$nextDeviceType; local_device_type = (Get-DeviceType -Config $config) }
            Trace-DeviceLog -Config $config -Context $context -DeviceId $deviceId -Level 'INFO' -EventType 'device_classified' -Message "Backend classified device as $nextDeviceType" -Meta ([pscustomobject]@{ device_type = [string]$nextDeviceType; local_device_type = (Get-DeviceType -Config $config) })
        }
        $nextTask = $nextResponseTask
        $assignedDeviceId = Get-TaskAssignedDeviceId -Task $nextTask
        if ($null -ne $assignedDeviceId -and $assignedDeviceId -ne $deviceId) {
            Write-RunLog -Context $context -Level 'INFO' -Event 'task_skipped' -Message "Task assigned to another device" -Data @{ assigned_device_id = $assignedDeviceId; local_device_id = $deviceId; task_id = $nextTask.id }
            Trace-DeviceLog -Config $config -Context $context -DeviceId $deviceId -TaskId $nextTask.id -Level 'INFO' -EventType 'task_skipped' -Message 'Task assigned to another device' -Meta ([pscustomobject]@{ assigned_device_id = $assignedDeviceId; local_device_id = $deviceId; task_id = $nextTask.id })
            $nextTask = $null
        }
        if ($taskSuccess -and $null -ne $nextTask -and [int]$nextTask.id -eq [int]$task.id) {
            $pauseMin = if ($null -ne $nextTask.pause_min) { [int]$nextTask.pause_min } else { 0 }
            $pauseMax = if ($null -ne $nextTask.pause_max) { [int]$nextTask.pause_max } else { $pauseMin }
            $pauseSec = Random-IntInclusive -Min $pauseMin -Max $pauseMax
            Write-RunLog -Context $context -Level 'INFO' -Event 'same_task_pause' -Message "Task repeated, pausing $pauseSec seconds before next round" -Data @{ task_id = $task.id; pause_sec = $pauseSec }
            Wait-WithChecks -DurationMs ($pauseSec * 1000) | Out-Null
        }

        $queuedTask = $nextTask
    }
} catch {
    Write-StepError -Step 'run.fatal' -ErrorRecord $_ -Context $context
    try {
        Trace-DeviceLog -Config $config -Context $context -DeviceId $deviceId -Level 'ERROR' -EventType 'fatal' -Message 'Runner failed' -Meta ([pscustomobject]@{
            error = $_.Exception.Message
            type  = $_.Exception.GetType().FullName
            stack = $_.ScriptStackTrace
        })
    } catch {
    }
    throw
} finally {
    try {
        $summary = [pscustomobject]@{
            runId = $runId
            device_id = $deviceId
            apiBaseUrl = $config.apiBaseUrl
        }
        $summary | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $context.SummaryPath -Encoding utf8
    } catch {
    }

    if ($script:CdpConnected) {
        Close-CdpWebSocket
    }

    if ($null -ne $script:BrowserProcess) {
        try {
            if (-not $script:BrowserProcess.HasExited) {
                Stop-Process -Id $script:BrowserProcess.Id -Force
            }
        } catch {
        }
    }
}
