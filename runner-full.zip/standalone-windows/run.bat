@echo off
setlocal
cd /d "%~dp0"

set "CONFIG=%~1"
if "%CONFIG%"=="" set "CONFIG=%~dp0config.example.json"

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0launch.ps1" -ConfigPath "%CONFIG%"
set "EXIT_CODE=%ERRORLEVEL%"
endlocal & exit /b %EXIT_CODE%
