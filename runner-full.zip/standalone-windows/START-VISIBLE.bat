@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Walker Runner - VISIBLE (worker 1)
echo ============================================================
echo  Walker Runner - visible mode (worker 1)
echo  Server: http://80.249.147.84:8010
echo  This window stays open so you can watch it work.
echo  Close this window (or Ctrl+C) to stop the runner.
echo ============================================================
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0launch.ps1" -ConfigPath "%~dp0config.worker1.json"
echo.
echo [runner stopped] Press any key to close...
pause >nul
