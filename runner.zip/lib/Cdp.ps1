# CDP over WebSocket — pattern from Chrome DevTools Protocol guides for PowerShell 5.1:
# store ClientWebSocket in $script: scope, use .Wait()/.Result, pass URL string to ConnectAsync.

$script:CdpSocket = $null
$script:CdpMessageId = 0
$script:CdpEvents = $null
$script:MainCdpTargetId = $null
$script:CdpDebugPort = 0
$script:ProxyLogin = $null
$script:ProxyPassword = $null
$script:NetworkUrlMap = @{}
$script:NetworkBytesMap = @{}

function Initialize-CdpScriptState {
    if ($null -eq $script:CdpEvents) {
        $script:CdpEvents = New-Object System.Collections.ArrayList
    }
}

function Connect-CdpWebSocket {
    param(
        [Parameter(Mandatory = $true)][string]$WebSocketUrl
    )

    Initialize-CdpScriptState
    Close-CdpWebSocket

    $ws = New-Object System.Net.WebSockets.ClientWebSocket
    $null = $ws.ConnectAsync(
        $WebSocketUrl,
        [System.Threading.CancellationToken]::None
    ).Wait()

    $script:CdpSocket = $ws
    $script:CdpMessageId = 0
    if ($script:CdpEvents.Count -gt 0) {
        $script:CdpEvents.Clear()
    }
}

function Test-CdpConnected {
    return (
        $null -ne $script:CdpSocket -and
        $script:CdpSocket.State -eq [System.Net.WebSockets.WebSocketState]::Open
    )
}

function Close-CdpWebSocket {
    if ($null -eq $script:CdpSocket) {
        return
    }

    try {
        if ($script:CdpSocket.State -eq [System.Net.WebSockets.WebSocketState]::Open) {
            $null = $script:CdpSocket.CloseAsync(
                [System.Net.WebSockets.WebSocketCloseStatus]::NormalClosure,
                'done',
                [System.Threading.CancellationToken]::None
            ).Wait()
        }
    } catch {
    }

    try {
        $script:CdpSocket.Dispose()
    } catch {
    }

    $script:CdpSocket = $null
}

function Send-CdpText {
    param(
        [Parameter(Mandatory = $true)][string]$Text
    )

    if (-not (Test-CdpConnected)) {
        throw 'CDP WebSocket is not connected'
    }

    $bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
    $segment = [System.ArraySegment[byte]]::new($bytes)
    $null = $script:CdpSocket.SendAsync(
        $segment,
        [System.Net.WebSockets.WebSocketMessageType]::Text,
        $true,
        [System.Threading.CancellationToken]::None
    ).Wait()
}

function Receive-CdpText {
    param(
        [Parameter(Mandatory = $true)][int]$TimeoutMs
    )

    if (-not (Test-CdpConnected)) {
        return $null
    }

    $cts = New-Object System.Threading.CancellationTokenSource
    $cts.CancelAfter($TimeoutMs)
    $stream = $null

    try {
        $buffer = New-Object byte[] 8192
        $stream = New-Object System.IO.MemoryStream

        while ($true) {
            $segment = [System.ArraySegment[byte]]::new($buffer)
            $receiveTask = $script:CdpSocket.ReceiveAsync($segment, $cts.Token)
            $null = $receiveTask.Wait($TimeoutMs)
            if (-not $receiveTask.IsCompleted) {
                return $null
            }

            $result = $receiveTask.Result
            if ($result.MessageType -eq [System.Net.WebSockets.WebSocketMessageType]::Close) {
                return $null
            }

            if ($result.Count -gt 0) {
                $stream.Write($buffer, 0, $result.Count)
            }

            if ($result.EndOfMessage) {
                break
            }
        }

        return [System.Text.Encoding]::UTF8.GetString($stream.ToArray())
    } catch {
        return $null
    } finally {
        $cts.Dispose()
        if ($null -ne $stream) {
            $stream.Dispose()
        }
    }
}

function Invoke-CdpCommand {
    param(
        [Parameter(Mandatory = $true)][string]$Method,
        [AllowNull()]$Params = $null,
        [int]$TimeoutSec = 10
    )

    try {
    Initialize-CdpScriptState

    $script:CdpMessageId = $script:CdpMessageId + 1
    $messageId = $script:CdpMessageId

    $payload = @{
        id     = $messageId
        method = $Method
    }

    if ($null -ne $Params) {
        $paramCount = 0
        if ($Params -is [System.Collections.IDictionary]) {
            $paramCount = $Params.Count
        } else {
            $paramCount = @($Params.PSObject.Properties).Count
        }

        if ($paramCount -gt 0) {
            $payload.params = $Params
        }
    }

    $json = $payload | ConvertTo-Json -Depth 20 -Compress
    Send-CdpText -Text $json

    $deadline = (Get-Date).AddSeconds($TimeoutSec)

    while ((Get-Date) -lt $deadline) {
        $remainingMs = [Math]::Max(200, [int](($deadline - (Get-Date)).TotalMilliseconds))
        $messageText = Receive-CdpText -TimeoutMs $remainingMs

        if ([string]::IsNullOrWhiteSpace($messageText)) {
            continue
        }

        $message = $messageText | ConvertFrom-Json

        $responseId = Get-ObjectPropertyValue -Object $message -Name 'id' -Default $null
        if ($null -ne $responseId -and [int]$responseId -eq [int]$messageId) {
            $errorPayload = Get-ObjectPropertyValue -Object $message -Name 'error' -Default $null
            if ($null -ne $errorPayload) {
                $details = $errorPayload | ConvertTo-Json -Depth 20 -Compress
                throw "CDP command failed ($Method): $details"
            }
            return (Get-ObjectPropertyValue -Object $message -Name 'result' -Default $null)
        }

        [void]$script:CdpEvents.Add($message)
    }

    throw "Timed out waiting for CDP response to $Method"
    } catch {
        $msg = $_.Exception.Message
        $isOptionalCdp = ($Method -in @('Storage.enable', 'Input.enable') -and ($msg -like "*wasn*t found*" -or $msg -like "*-32601*"))
        $isDisconnected = ($msg -like '*not connected*')
        if (-not $isOptionalCdp -and -not $isDisconnected) {
            Write-StepError -Step "CDP:$Method" -ErrorRecord $_
            throw
        }
        if ($isDisconnected) {
            throw $msg
        }
    }
}

function Invoke-CdpEvaluate {
    param(
        [Parameter(Mandatory = $true)][string]$Expression,
        [int]$TimeoutSec = 10,
        [bool]$AwaitPromise = $true,
        [bool]$ReturnByValue = $true
    )

    try {
    $result = Invoke-CdpCommand -Method 'Runtime.evaluate' -Params @{
        expression    = $Expression
        awaitPromise  = $AwaitPromise
        returnByValue = $ReturnByValue
        userGesture   = $true
    } -TimeoutSec $TimeoutSec

    $exceptionDetails = Get-ObjectPropertyValue -Object $result -Name 'exceptionDetails' -Default $null
    if ($null -ne $exceptionDetails) {
        $details = $exceptionDetails | ConvertTo-Json -Depth 20 -Compress
        throw "Runtime.evaluate failed: $details"
    }

    $evalResult = Get-ObjectPropertyValue -Object $result -Name 'result' -Default $null
    if ($ReturnByValue -and $null -ne $evalResult) {
        return (Get-ObjectPropertyValue -Object $evalResult -Name 'value' -Default $null)
    }

    return $result
    } catch {
        Write-StepError -Step 'CDP:Runtime.evaluate' -ErrorRecord $_ -Level 'WARN'
        throw
    }
}

function Set-MainCdpTarget {
    param(
        [Parameter(Mandatory = $true)][string]$TargetId,
        [Parameter(Mandatory = $true)][int]$Port
    )

    $script:MainCdpTargetId = $TargetId
    $script:CdpDebugPort = $Port
}

function Find-MainCdpTarget {
    param(
        [Parameter(Mandatory = $true)][int]$Port,
        [string]$PreferredTargetId = ''
    )

    $targets = @(Get-CdpPageTargets -Port $Port)
    if ($targets.Count -eq 0) {
        return $null
    }

    if (-not [string]::IsNullOrWhiteSpace($PreferredTargetId)) {
        foreach ($pageTarget in $targets) {
            $targetId = [string](Get-ObjectPropertyValue -Object $pageTarget -Name 'id' -Default '')
            if ($targetId -eq $PreferredTargetId) {
                return $pageTarget
            }
        }
    }

    $nonBlankTargets = @(
        $targets | Where-Object {
            $url = [string](Get-ObjectPropertyValue -Object $_ -Name 'url' -Default '')
            -not [string]::IsNullOrWhiteSpace($url) -and $url -ne 'about:blank'
        }
    )
    if ($nonBlankTargets.Count -gt 0) {
        return $nonBlankTargets[0]
    }

    return $targets[0]
}

function Ensure-CdpSession {
    param(
        [Parameter(Mandatory = $true)][int]$Port,
        [string]$PreferredTargetId = '',
        [bool]$ReinitDomains = $true
    )

    if (Test-CdpConnected) {
        return $true
    }

    $target = Find-MainCdpTarget -Port $Port -PreferredTargetId $PreferredTargetId
    if ($null -eq $target) {
        return $false
    }

    $webSocketUrl = [string](Get-ObjectPropertyValue -Object $target -Name 'webSocketDebuggerUrl' -Default '')
    $targetId = [string](Get-ObjectPropertyValue -Object $target -Name 'id' -Default '')
    if ([string]::IsNullOrWhiteSpace($webSocketUrl)) {
        return $false
    }

    try {
        Connect-CdpWebSocket -WebSocketUrl $webSocketUrl
    } catch {
        return $false
    }

    if (-not [string]::IsNullOrWhiteSpace($targetId)) {
        Set-MainCdpTarget -TargetId $targetId -Port $Port
    }

    if ($ReinitDomains) {
        foreach ($cdpStep in @('Page.enable', 'Runtime.enable', 'DOM.enable', 'Network.enable')) {
            try {
                Invoke-CdpCommand -Method $cdpStep -TimeoutSec 10 | Out-Null
            } catch {
            }
        }
    }

    return (Test-CdpConnected)
}

function Get-CdpPageTargets {
    param(
        [Parameter(Mandatory = $true)][int]$Port
    )

    try {
        $targets = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/json/list" -Method Get -TimeoutSec 3
        return @($targets | Where-Object { $_.type -eq 'page' })
    } catch {
        return @()
    }
}

function Get-CdpPageTargetIds {
    param(
        [Parameter(Mandatory = $true)][int]$Port
    )

    $ids = New-Object System.Collections.Generic.List[string]
    foreach ($pageTarget in (Get-CdpPageTargets -Port $Port)) {
        $targetId = [string](Get-ObjectPropertyValue -Object $pageTarget -Name 'id' -Default '')
        if (-not [string]::IsNullOrWhiteSpace($targetId)) {
            [void]$ids.Add($targetId)
        }
    }
    return @($ids)
}

function Activate-CdpPageTarget {
    param(
        [Parameter(Mandatory = $true)][string]$TargetId,
        [Parameter(Mandatory = $true)][int]$Port
    )

    try {
        $null = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/json/activate/$TargetId" -Method Get -TimeoutSec 3
        return $true
    } catch {
        return $false
    }
}

function Wait-ForNewCdpTabsLoaded {
    param(
        [Parameter(Mandatory = $true)][int]$Port,
        [Parameter(Mandatory = $true)][string]$MainTargetId,
        [Parameter(Mandatory = $true)][string[]]$BeforeTargetIds,
        [int]$MaxWaitMs = 15000,
        [int]$PollMs = 250
    )

    $deadline = (Get-Date).AddMilliseconds($MaxWaitMs)
    $sawNewTab = $false

    while ((Get-Date) -lt $deadline) {
        $newTargets = @(
            Get-CdpPageTargets -Port $Port | Where-Object {
                $targetId = [string](Get-ObjectPropertyValue -Object $_ -Name 'id' -Default '')
                $targetId -ne $MainTargetId -and $targetId -notin $BeforeTargetIds
            }
        )

        if ($newTargets.Count -eq 0) {
            if ($sawNewTab) {
                return $true
            }
            return $false
        }

        $sawNewTab = $true
        $allLoaded = $true
        foreach ($pageTarget in $newTargets) {
            $url = [string](Get-ObjectPropertyValue -Object $pageTarget -Name 'url' -Default '')
            if ([string]::IsNullOrWhiteSpace($url) -or $url -eq 'about:blank') {
                $allLoaded = $false
                break
            }
        }

        if ($allLoaded) {
            Start-Sleep -Milliseconds 500
            return $true
        }

        Start-Sleep -Milliseconds $PollMs
    }

    return $sawNewTab
}

function Restore-MainBrowserTab {
    param(
        [int]$PopupSettleMs = 350,
        [string[]]$BeforeTargetIds = @(),
        [bool]$WaitForNewTabs = $false,
        [int]$MaxWaitForPopupMs = 15000
    )

    if (-not (Test-CdpConnected)) {
        return
    }

    if (
        $WaitForNewTabs -and
        $BeforeTargetIds.Count -gt 0 -and
        -not [string]::IsNullOrWhiteSpace($script:MainCdpTargetId) -and
        $script:CdpDebugPort -gt 0
    ) {
        if ($PopupSettleMs -gt 0) {
            Start-Sleep -Milliseconds $PopupSettleMs
        }
        [void](Wait-ForNewCdpTabsLoaded -Port $script:CdpDebugPort -MainTargetId $script:MainCdpTargetId -BeforeTargetIds $BeforeTargetIds -MaxWaitMs $MaxWaitForPopupMs)
    } elseif ($PopupSettleMs -gt 0) {
        Start-Sleep -Milliseconds $PopupSettleMs
    }

    try {
        Invoke-CdpCommand -Method 'Page.bringToFront' -TimeoutSec 3 | Out-Null
    } catch {
    }

    if (-not [string]::IsNullOrWhiteSpace($script:MainCdpTargetId) -and $script:CdpDebugPort -gt 0) {
        [void](Activate-CdpPageTarget -TargetId $script:MainCdpTargetId -Port $script:CdpDebugPort)
        try {
            Invoke-CdpCommand -Method 'Page.bringToFront' -TimeoutSec 3 | Out-Null
        } catch {
        }
    }
}

function Clear-WebState {
    param(
        [Parameter(Mandatory = $true)][string]$Url
    )

    try {
        Invoke-CdpCommand -Method 'Network.clearBrowserCookies' -TimeoutSec 5 | Out-Null
    } catch {
    }

    try {
        if (-not [string]::IsNullOrWhiteSpace($Url)) {
            $uri = [Uri]$Url
            if ($uri.Scheme -in @('http', 'https')) {
                $origin = $uri.GetLeftPart([System.UriPartial]::Authority)
                Invoke-CdpCommand -Method 'Storage.clearDataForOrigin' -Params @{
                    origin       = $origin
                    storageTypes = 'all'
                } -TimeoutSec 10 | Out-Null
            }
        }
    } catch {
    }

    try {
        Invoke-CdpEvaluate -Expression @'
(() => {
  try { localStorage.clear(); } catch (e) {}
  try { sessionStorage.clear(); } catch (e) {}
  return true;
})()
'@ -TimeoutSec 5 | Out-Null
    } catch {
    }
}

function Set-CdpStealth {
    # Inject anti-detection + fingerprint randomization before page scripts (runs on every new document).
    # A fresh random seed each document -> different canvas/WebGL/hardware fingerprint per visit.
    try {
        $js = @'
(() => {
  let s = (Math.floor(Math.random()*2147483000)) >>> 0;
  const rnd = () => { s = (s*1664525+1013904223)>>>0; return s/4294967296; };
  const cores = 4 + Math.floor(rnd()*5)*2;
  const mem = [4,8][Math.floor(rnd()*2)];
  try { Object.defineProperty(navigator,'webdriver',{get:()=>undefined}); } catch(e){}
  try { if(!window.chrome) window.chrome={runtime:{}}; } catch(e){}
  try { Object.defineProperty(navigator,'languages',{get:()=>['ru-RU','ru','en-US','en']}); } catch(e){}
  try { Object.defineProperty(navigator,'plugins',{get:()=>[1,2,3,4,5]}); } catch(e){}
  try { Object.defineProperty(navigator,'hardwareConcurrency',{get:()=>cores}); } catch(e){}
  try { Object.defineProperty(navigator,'deviceMemory',{get:()=>mem}); } catch(e){}
  try { const q=navigator.permissions.query.bind(navigator.permissions); navigator.permissions.query=(p)=> (p&&p.name==='notifications')?Promise.resolve({state:Notification.permission}):q(p); } catch(e){}
  try { const gp=WebGLRenderingContext.prototype.getParameter; WebGLRenderingContext.prototype.getParameter=function(p){ if(p===37445)return 'Intel Inc.'; if(p===37446)return 'Intel Iris OpenGL Engine'; return gp.call(this,p); }; } catch(e){}
  try {
    const gid=CanvasRenderingContext2D.prototype.getImageData;
    const tdu=HTMLCanvasElement.prototype.toDataURL;
    const noisify=(cv)=>{ try{ const c=cv.getContext('2d'); if(!c||!cv.width||!cv.height)return; const im=gid.call(c,0,0,cv.width,cv.height); for(let i=0;i<im.data.length;i+=Math.floor(rnd()*1500)+700){ im.data[i]=im.data[i]^(Math.floor(rnd()*3)); } c.putImageData(im,0,0);}catch(e){} };
    HTMLCanvasElement.prototype.toDataURL=function(){ try{noisify(this);}catch(e){} return tdu.apply(this,arguments); };
  } catch(e){}
})()
'@
        Invoke-CdpCommand -Method 'Page.addScriptToEvaluateOnNewDocument' -Params @{ source = $js } -TimeoutSec 8 | Out-Null
    } catch {}
}

function Set-CdpProxyCredentials {
    param(
        [Parameter(Mandatory = $true)][string]$Login,
        [Parameter(Mandatory = $true)][string]$Password
    )
    $script:ProxyLogin = $Login
    $script:ProxyPassword = $Password
}

function Process-PendingCdpAuthEvents {
    if ([string]::IsNullOrWhiteSpace($script:ProxyLogin)) { return }
    Initialize-CdpScriptState

    $toKeep = New-Object System.Collections.ArrayList
    foreach ($msg in $script:CdpEvents) {
        $method = Get-ObjectPropertyValue -Object $msg -Name 'method' -Default $null
        if ($method -eq 'Fetch.authRequired') {
            $params = Get-ObjectPropertyValue -Object $msg -Name 'params' -Default $null
            if ($null -ne $params) {
                $requestId = [string](Get-ObjectPropertyValue -Object $params -Name 'requestId' -Default '')
                if (-not [string]::IsNullOrWhiteSpace($requestId)) {
                    try {
                        Invoke-CdpCommand -Method 'Fetch.continueWithAuth' -Params @{
                            requestId             = $requestId
                            authChallengeResponse = @{
                                response = 'ProvideCredentials'
                                username = [string]$script:ProxyLogin
                                password = [string]$script:ProxyPassword
                            }
                        } -TimeoutSec 5 | Out-Null
                    } catch {}
                }
            }
        } else {
            [void]$toKeep.Add($msg)
        }
    }
    $script:CdpEvents.Clear()
    foreach ($m in $toKeep) { [void]$script:CdpEvents.Add($m) }
}

function Invoke-CdpDrain {
    # Read all pending CDP events from the WebSocket buffer into $script:CdpEvents.
    # Network.responseReceived / Network.loadingFinished arrive asynchronously;
    # they only get stored during Invoke-CdpCommand waits. After the last CDP command
    # completes, remaining events sit unread in the socket — this drains them.
    Initialize-CdpScriptState
    if (-not (Test-CdpConnected)) { return }
    $emptyStreak = 0
    while ($emptyStreak -lt 3) {
        $text = Receive-CdpText -TimeoutMs 300
        if ([string]::IsNullOrWhiteSpace($text)) {
            $emptyStreak++
            continue
        }
        $emptyStreak = 0
        try {
            $msg = $text | ConvertFrom-Json
            [void]$script:CdpEvents.Add($msg)
        } catch {}
    }
}

function Reset-SessionTraffic {
    $script:NetworkUrlMap = @{}
    $script:NetworkBytesMap = @{}
}

function Process-NetworkTrafficEvents {
    Initialize-CdpScriptState
    $toKeep = New-Object System.Collections.ArrayList
    foreach ($msg in $script:CdpEvents) {
        $method = Get-ObjectPropertyValue -Object $msg -Name 'method' -Default $null
        if ($method -eq 'Network.responseReceived') {
            $params = Get-ObjectPropertyValue -Object $msg -Name 'params' -Default $null
            if ($null -ne $params) {
                $requestId = [string](Get-ObjectPropertyValue -Object $params -Name 'requestId' -Default '')
                $response = Get-ObjectPropertyValue -Object $params -Name 'response' -Default $null
                if (-not [string]::IsNullOrWhiteSpace($requestId) -and $null -ne $response) {
                    $url = [string](Get-ObjectPropertyValue -Object $response -Name 'url' -Default '')
                    if (-not [string]::IsNullOrWhiteSpace($url)) {
                        try {
                            $uri = [Uri]$url
                            $script:NetworkUrlMap[$requestId] = $uri.Host
                        } catch {}
                    }
                }
            }
            [void]$toKeep.Add($msg)
        } elseif ($method -eq 'Network.loadingFinished') {
            $params = Get-ObjectPropertyValue -Object $msg -Name 'params' -Default $null
            if ($null -ne $params) {
                $requestId = [string](Get-ObjectPropertyValue -Object $params -Name 'requestId' -Default '')
                $encodedDataLength = [long](Get-ObjectPropertyValue -Object $params -Name 'encodedDataLength' -Default 0)
                if (-not [string]::IsNullOrWhiteSpace($requestId) -and $encodedDataLength -gt 0) {
                    if ($script:NetworkBytesMap.ContainsKey($requestId)) {
                        $script:NetworkBytesMap[$requestId] += $encodedDataLength
                    } else {
                        $script:NetworkBytesMap[$requestId] = $encodedDataLength
                    }
                }
            }
        } else {
            [void]$toKeep.Add($msg)
        }
    }
    $script:CdpEvents.Clear()
    foreach ($m in $toKeep) { [void]$script:CdpEvents.Add($m) }
}

function Get-SessionTrafficSummary {
    $domainBytes = @{}
    $totalBytes = [long]0

    foreach ($requestId in $script:NetworkBytesMap.Keys) {
        $bytes = $script:NetworkBytesMap[$requestId]
        $domain = if ($script:NetworkUrlMap.ContainsKey($requestId)) { $script:NetworkUrlMap[$requestId] } else { 'unknown' }
        if ([string]::IsNullOrWhiteSpace($domain)) { $domain = 'unknown' }
        if ($domainBytes.ContainsKey($domain)) {
            $domainBytes[$domain] += $bytes
        } else {
            $domainBytes[$domain] = $bytes
        }
        $totalBytes += $bytes
    }

    $domains = @()
    foreach ($domain in $domainBytes.Keys) {
        $domains += [pscustomobject]@{ domain = $domain; bytes = $domainBytes[$domain] }
    }

    return [pscustomobject]@{
        bytes_total = $totalBytes
        domains     = ($domains | Sort-Object bytes -Descending)
    }
}
