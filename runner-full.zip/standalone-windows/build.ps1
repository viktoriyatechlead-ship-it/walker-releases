<#
.SYNOPSIS
    Собирает vmos-runner.exe из исходников
    Запускать на Windows: .\build.ps1

.PARAMETER ServerUrl
    URL сервера (по умолчанию — продакшн)

.PARAMETER OutputDir
    Куда положить результат (по умолчанию — папка dist рядом)
#>
param(
    [string]$ServerUrl  = 'http://lruxkyz77g1r748dgcu7ptc7.167.233.197.194.sslip.io',
    [string]$OutputDir  = (Join-Path $PSScriptRoot 'dist')
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

Write-Host ''
Write-Host '  =========================================='
Write-Host '   VMOS Runner — Build'
Write-Host '  =========================================='
Write-Host ''

# ── 1. PS2EXE ─────────────────────────────────────────────────────────────────
Write-Host '  [1/4] Проверяем PS2EXE ...'
if (-not (Get-Module -ListAvailable -Name 'ps2exe')) {
    Write-Host '        Устанавливаем ps2exe из PSGallery ...'
    Install-Module -Name ps2exe -Scope CurrentUser -Force -AllowClobber
}
Import-Module ps2exe -Force
Write-Host '        OK'

# ── 2. Сшиваем монолит ────────────────────────────────────────────────────────
Write-Host '  [2/4] Собираем монолитный скрипт ...'

$libOrder = @('Common.ps1','Device.ps1','Browser.ps1','Cdp.ps1','Profiles.ps1','Api.ps1','Page.ps1','Tasks.ps1')
$libDir   = Join-Path $PSScriptRoot 'lib'

$lines = [System.Collections.Generic.List[string]]::new()

# Шапка — параметры убираем, URL зашиваем как константу
$lines.Add("# VMOS Runner — compiled monolith")
$lines.Add("# Built: $(Get-Date -Format 'yyyy-MM-dd HH:mm')")
$lines.Add("# Server: $ServerUrl")
$lines.Add('')
$lines.Add('Set-StrictMode -Version Latest')
$lines.Add('$ErrorActionPreference = "Stop"')
$lines.Add('')

# Конфиг зашит прямо в скрипт как строка, читается из файла рядом с exe если есть
$lines.Add(@'
$_embeddedConfig = @{
    apiBaseUrl                  = $null   # заполняется ниже
    apiTimeoutSec               = 10
    heartbeatIntervalSec        = 15
    heartbeatRetryDelaySec      = 5
    emptyQueueWaitSec           = 60
    geoBlockedMinSec            = 60
    geoBlockedMaxSec            = 120
    webViewReadyTimeoutSec      = 15
    pageReadyTimeoutSec         = 25
    pageReadyForHumanMaxWaitMs  = 8000
    captureOnSuccess            = $false
    clientVersion               = 'windows-ps/1.0'
    deviceType                  = 'desktop'
    behaviorProfile             = 'scanner'
    outputRoot                  = (Join-Path $env:APPDATA 'VMOS\output')
    stateDir                    = (Join-Path $env:APPDATA 'VMOS\state')
    browser                     = @{
        preferred  = @('edge','chrome')
        extraArgs  = @(
            '--disable-features=IsolateOrigins,site-per-process'
            '--disable-background-networking'
            '--disable-default-apps'
            '--disable-extensions'
            '--disable-sync'
            '--no-first-run'
            '--no-default-browser-check'
            '--disable-popup-blocking'
        )
    }
    errorKeywords = @('error','failed','forbidden','blocked','captcha','not found','temporarily unavailable','something went wrong','ошибка','доступ запрещен','капча','сервис недоступен')
    bannerSelectors = @('iframe','ins','[data-banner="true"]','[class*="banner"]','[id*="banner"]','[class*="advert"]','[id*="advert"]','[class*="ads"]','[id*="ads"]')
}
'@)

$lines.Add('')
$lines.Add("# URL сервера — зашит при сборке")
$lines.Add("`$_embeddedConfig.apiBaseUrl = '$ServerUrl'")
$lines.Add('')

# Если рядом с exe есть config.json — берём оттуда (позволяет переопределить)
$lines.Add(@'
$_exeDir     = Split-Path -Parent ([System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName)
$_configFile = Join-Path $_exeDir 'config.json'
if (Test-Path $_configFile) {
    try {
        $config = Get-Content $_configFile -Raw -Encoding UTF8 | ConvertFrom-Json
    } catch {
        $config = [pscustomobject]$_embeddedConfig
    }
} else {
    $config = [pscustomobject]$_embeddedConfig
}
# гарантируем apiBaseUrl
if (-not $config.apiBaseUrl) { $config | Add-Member -Force -NotePropertyName apiBaseUrl -NotePropertyValue $_embeddedConfig.apiBaseUrl }

# Данные (output, state) храним в %APPDATA%\VMOS
$_vmosData = Join-Path $env:APPDATA 'VMOS'
foreach ($d in @('output','state')) { $null = New-Item -ItemType Directory -Force -Path (Join-Path $_vmosData $d) }
if (-not $config.outputRoot) { $config | Add-Member -Force -NotePropertyName outputRoot -NotePropertyValue (Join-Path $_vmosData 'output') }
if (-not $config.stateDir)   { $config | Add-Member -Force -NotePropertyName stateDir   -NotePropertyValue (Join-Path $_vmosData 'state') }
'@)
$lines.Add('')

# Вставляем lib-файлы (без param/using блоков)
foreach ($lib in $libOrder) {
    $path = Join-Path $libDir $lib
    if (-not (Test-Path $path)) { Write-Warning "Lib not found: $path"; continue }

    $lines.Add("# ── lib/$lib ────────────────────────────────────────────────────")
    $content = Get-Content $path -Raw -Encoding UTF8

    # Убираем param() блок если есть
    $content = $content -replace '(?s)^param\s*\(.*?\)\s*', ''
    # Убираем using namespace
    $content = $content -replace '(?m)^using\s+namespace\s+.+$', ''

    $lines.Add($content.Trim())
    $lines.Add('')
}

# Основная логика run.ps1 — убираем param() и dot-source строки
$mainContent = Get-Content (Join-Path $PSScriptRoot 'run.ps1') -Raw -Encoding UTF8
$mainContent = $mainContent -replace '(?s)^param\s*\(.*?\)\s*', ''
$mainContent = $mainContent -replace '(?m)^\.\s+\(Join-Path.*?\.ps1.*?\)\s*$', ''  # убираем . (Join-Path $libDir ...)
$mainContent = $mainContent -replace '\$ConfigPath', '$_configFile'

# Убираем блок Read-JsonFile + присваивание $config (мы уже сделали это выше)
$mainContent = $mainContent -replace '(?m)^\$config\s*=\s*Read-JsonFile.*$', ''
$mainContent = $mainContent -replace "(?s)Set-StrictMode.*?`n", ''
$mainContent = $mainContent -replace '(?m)^\$ErrorActionPreference.*$', ''

$lines.Add('# ── run.ps1 main ──────────────────────────────────────────────────────')
$lines.Add($mainContent.Trim())

# Пишем монолит
$null = New-Item -ItemType Directory -Force -Path $OutputDir
$monolithPath = Join-Path $OutputDir 'vmos-monolith.ps1'
$lines | Set-Content -Path $monolithPath -Encoding UTF8
Write-Host "        Монолит: $monolithPath ($((Get-Item $monolithPath).Length / 1KB -as [int]) KB)"

# ── 3. Компилируем в EXE ──────────────────────────────────────────────────────
Write-Host '  [3/4] Компилируем в EXE ...'
$exePath = Join-Path $OutputDir 'vmos-runner.exe'

Invoke-PS2EXE `
    -InputFile  $monolithPath `
    -OutputFile $exePath `
    -NoConsole `
    -Title      'VMOS Runner' `
    -Description 'VMOS Desktop Runner' `
    -Company    'VMOS' `
    -Version    '1.0.0'

if (Test-Path $exePath) {
    $sizeMb = [math]::Round((Get-Item $exePath).Length / 1MB, 1)
    Write-Host "        EXE: $exePath ($sizeMb MB)"
} else {
    Write-Error 'Сборка не удалась — exe не создан'
}

# ── 4. Копируем вспомогательные файлы ─────────────────────────────────────────
Write-Host '  [4/4] Копируем install.bat, uninstall.bat ...'
Copy-Item (Join-Path $PSScriptRoot 'install.bat')   (Join-Path $OutputDir 'install.bat')   -Force
Copy-Item (Join-Path $PSScriptRoot 'uninstall.bat') (Join-Path $OutputDir 'uninstall.bat') -Force

# README для получателя
@"
VMOS Runner — Инструкция

Сервер: $ServerUrl

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ЗАПУСК ОДНИМ ФАЙЛОМ:
  Дважды кликните vmos-runner.exe
  Раннер запустится в фоне (без окна).

УСТАНОВКА С АВТОЗАПУСКОМ:
  1. Правая кнопка на install.bat
  2. "Запуск от имени администратора"
  Раннер будет стартовать автоматически при входе в Windows.

ОСТАНОВИТЬ:
  Диспетчер задач → найти powershell.exe → Завершить задачу

УДАЛИТЬ:
  Правая кнопка на uninstall.bat → "Запуск от имени администратора"

СМЕНИТЬ СЕРВЕР:
  Создайте файл config.json рядом с vmos-runner.exe
  и укажите: { "apiBaseUrl": "http://ВАШ-СЕРВЕР" }
  EXE подхватит его при следующем запуске.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"@ | Set-Content (Join-Path $OutputDir 'README.txt') -Encoding UTF8

Write-Host ''
Write-Host '  =========================================='
Write-Host "   Готово! Файлы в: $OutputDir"
Write-Host '  =========================================='
Write-Host ''
Write-Host '   Отдать пользователю:'
Write-Host '     vmos-runner.exe   — запуск одним файлом'
Write-Host '     install.bat       — установка с автозапуском'
Write-Host '     README.txt        — инструкция'
Write-Host ''
