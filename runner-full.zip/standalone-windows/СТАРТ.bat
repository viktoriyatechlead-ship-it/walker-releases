@echo off
cd /d "%~dp0"

set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"

start "" /B "%PS%" -WindowStyle Hidden -NoProfile -ExecutionPolicy Bypass -File "%~dp0launch.ps1" -ConfigPath "%~dp0config.json"
