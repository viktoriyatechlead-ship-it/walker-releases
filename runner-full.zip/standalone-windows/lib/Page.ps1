function Wait-ForPageReady {
    param(        [Parameter(Mandatory = $true)][int]$TimeoutSec,
        [Parameter(Mandatory = $true)][int]$PollDelayMs
    )

    $deadline = (Get-Date).AddSeconds($TimeoutSec)

    while ((Get-Date) -lt $deadline) {
        try {
            $state = Invoke-CdpEvaluate -Expression 'document.readyState' -TimeoutSec 5
            if ($state -eq 'interactive' -or $state -eq 'complete') {
                return $state
            }
        } catch {
        }

        Process-PendingCdpAuthEvents
        Process-NetworkTrafficEvents
        Start-Sleep -Milliseconds $PollDelayMs
    }

    throw "Page did not reach readyState=interactive/complete within $TimeoutSec seconds"
}

function Get-PageProbe {
    param(        [Parameter(Mandatory = $true)]$Config,
        [string[]]$BannerSelectors = $null,
        [string[]]$ErrorKeywords = $null
    )

    $configErrorKeywords = Get-ObjectPropertyValue -Object $Config -Name 'errorKeywords' -Default @()
    $configBannerSelectors = Get-ObjectPropertyValue -Object $Config -Name 'bannerSelectors' -Default @()
    $effectiveErrorKeywords = if ($null -ne $ErrorKeywords -and @($ErrorKeywords).Count -gt 0) { @($ErrorKeywords) } else { @($configErrorKeywords) }
    $effectiveBannerSelectors = if ($null -ne $BannerSelectors -and @($BannerSelectors).Count -gt 0) { @($BannerSelectors) } else { @($configBannerSelectors) }
    $errorJson = $effectiveErrorKeywords | ConvertTo-Json -Compress
    $bannerSelectorsJson = $effectiveBannerSelectors | ConvertTo-Json -Compress
    $maxSample = [int]$Config.maxTextSampleChars

    $expression = @"
(() => {
  const errorKeywords = $errorJson;
  const bannerSelectors = $bannerSelectorsJson;
  const body = document.body ? String(document.body.innerText || document.body.textContent || '') : '';
  const lowered = body.toLowerCase();
  const selector = bannerSelectors.join(',');
  const banners = selector ? Array.from(document.querySelectorAll(selector)) : [];
  const bannerData = banners.map((el) => {
    const rect = el.getBoundingClientRect();
    return {
      tag: el.tagName || '',
      id: el.id || '',
      cls: String(el.className || '').slice(0, 120),
      left: Math.round(rect.left),
      top: Math.round(rect.top),
      width: Math.round(rect.width),
      height: Math.round(rect.height)
    };
  }).filter((b) => b.width > 4 && b.height > 4).slice(0, 20);

  const errorHits = errorKeywords.filter((k) => lowered.includes(String(k).toLowerCase()));
  const headings = document.querySelectorAll('h1,h2,h3,h4,h5,h6').length;
  const cards = document.querySelectorAll('article,section,li,[class*="card"],[class*="tile"],[class*="product"],[class*="item"]').length;
  const links = document.querySelectorAll('a').length;
  const buttons = document.querySelectorAll('button,[role="button"],input[type="button"],input[type="submit"]').length;
  const images = Array.from(document.images || []);
  const imagesLoaded = images.filter(function(img) { return !!img.complete && Number(img.naturalWidth || 0) > 0; }).length;
  const imagesPending = Math.max(images.length - imagesLoaded, 0);
  const visibleTextLength = body.replace(/\s+/g, ' ').trim().length;

  const safePoint = (() => {
    const vw = Math.max(document.documentElement.clientWidth || 0, window.innerWidth || 0);
    const vh = Math.max(document.documentElement.clientHeight || 0, window.innerHeight || 0);

    function insideBanner(x, y) {
      return bannerData.some((b) => x >= b.left && x <= (b.left + b.width) && y >= b.top && y <= (b.top + b.height));
    }

    for (let i = 0; i < 25; i++) {
      const x = Math.floor(vw * (0.12 + Math.random() * 0.76));
      const y = Math.floor(vh * (0.20 + Math.random() * 0.58));
      if (!insideBanner(x, y)) {
        return { ok: true, x, y };
      }
    }

    return { ok: false };
  })();

  return {
    title: document.title || '',
    url: location.href || '',
    readyState: document.readyState || '',
    bannerCount: bannerData.length,
    banners: bannerData,
    errorHits: errorHits,
    bodySample: body.slice(0, $maxSample),
    safePoint: safePoint,
    visible_text_length: visibleTextLength,
    heading_count: headings,
    card_count: cards,
    link_count: links,
    button_count: buttons,
    images_total: images.length,
    images_loaded: imagesLoaded,
    images_pending: imagesPending,
    ready_state: document.readyState || ''
  };
})()
"@

    try {
        return Invoke-CdpEvaluate -Expression $expression -TimeoutSec 10
    } catch {
        Write-StepError -Step 'Get-PageProbe' -ErrorRecord $_ -Level 'WARN'
        return $null
    }
}

function Is-WordPressLikePage {
    param(
        [string]$PageUrl,
        $Probe = $null
    )

    $raw = @(
        $PageUrl
        if ($null -ne $Probe) { [string]$Probe.url }
        if ($null -ne $Probe) { [string]$Probe.title }
        if ($null -ne $Probe) { [string]$Probe.bodySample }
    ) -join ' '
    $raw = $raw.ToLowerInvariant()
    return ($raw.Contains('wp-content') -or $raw.Contains('wp-json') -or $raw.Contains('wp-admin') -or $raw.Contains('wordpress') -or $raw.Contains('elementor') -or $raw.Contains('woocommerce') -or $raw.Contains('jetpack'))
}

function Is-MeaningfullyLoaded {
    param($Probe)

    if ($null -eq $Probe) { return $false }
    $visible = 0
    $headings = 0
    $cards = 0
    $links = 0
    $buttons = 0
    $imagesTotal = 0
    $imagesLoaded = 0
    try { $visible = [int]$Probe.visible_text_length } catch {}
    try { $headings = [int]$Probe.heading_count } catch {}
    try { $cards = [int]$Probe.card_count } catch {}
    try { $links = [int]$Probe.link_count } catch {}
    try { $buttons = [int]$Probe.button_count } catch {}
    try { $imagesTotal = [int]$Probe.images_total } catch {}
    try { $imagesLoaded = [int]$Probe.images_loaded } catch {}

    return ($visible -gt 0 -or $headings -gt 0 -or $cards -gt 0 -or $links -gt 0 -or $buttons -gt 0 -or ($imagesTotal -gt 0 -and $imagesLoaded -ge $imagesTotal))
}

function Wait-ForPageSettled {
    param(        [Parameter(Mandatory = $true)]$Config,
        [string[]]$BannerSelectors = $null,
        [string[]]$ErrorKeywords = $null,
        [int]$TimeoutMs = 7000,
        [string]$PageUrl = $null
    )

    $deadline = (Get-Date).AddMilliseconds($TimeoutMs)
    $lastProbe = $null
    while ((Get-Date) -lt $deadline) {
        $probe = Get-PageProbe -Config $Config -BannerSelectors $BannerSelectors -ErrorKeywords $ErrorKeywords
        $lastProbe = $probe
        if (Is-MeaningfullyLoaded -Probe $probe) {
            return $probe
        }
        Start-Sleep -Milliseconds 500
    }
    return $lastProbe
}

function Collect-StablePageProbe {
    param(        [Parameter(Mandatory = $true)]$Config,
        [string]$PageUrl = $null,
        [string[]]$BannerSelectors = $null,
        [string[]]$ErrorKeywords = $null,
        [bool]$SslWarningDetected = $false
    )

    try {
    $wordPressLike = Is-WordPressLikePage -PageUrl $PageUrl -Probe $null
    $primaryTimeout = if ($SslWarningDetected -and $wordPressLike) { 15000 } elseif ($SslWarningDetected) { 10000 } elseif ($wordPressLike) { 12000 } else { 7000 }
    $probe = Wait-ForPageSettled -Config $Config -BannerSelectors $BannerSelectors -ErrorKeywords $ErrorKeywords -TimeoutMs $primaryTimeout -PageUrl $PageUrl
    if ($null -eq $probe) {
        $probe = Get-PageProbe -Config $Config -BannerSelectors $BannerSelectors -ErrorKeywords $ErrorKeywords
    }

    if (($SslWarningDetected -or (Is-WordPressLikePage -PageUrl $PageUrl -Probe $probe)) -and -not (Is-MeaningfullyLoaded -Probe $probe)) {
        Start-Sleep -Milliseconds (if ((Is-WordPressLikePage -PageUrl $PageUrl -Probe $probe)) { 4000 } else { 2500 })
        $probe = Wait-ForPageSettled -Config $Config -BannerSelectors $BannerSelectors -ErrorKeywords $ErrorKeywords -TimeoutMs (if ((Is-WordPressLikePage -PageUrl $PageUrl -Probe $probe)) { 7000 } else { 5000 }) -PageUrl $PageUrl
        if ($null -eq $probe) {
            $probe = Get-PageProbe -Config $Config -BannerSelectors $BannerSelectors -ErrorKeywords $ErrorKeywords
        }
    }

    return $probe
    } catch {
        Write-StepError -Step 'Collect-StablePageProbe' -ErrorRecord $_ -Level 'WARN'
        return $null
    }
}

function Test-NavigationSucceeded {
    param(
        [Parameter(Mandatory = $true)][string]$Url
    )

    if ($script:CdpDebugPort -gt 0) {
        [void](Ensure-CdpSession -Port $script:CdpDebugPort -PreferredTargetId $script:MainCdpTargetId)
    }

    if (-not (Test-CdpConnected)) {
        return $false
    }

    try {
        $current = [string](Invoke-CdpEvaluate -Expression 'location.href' -TimeoutSec 5)
        if ([string]::IsNullOrWhiteSpace($current) -or $current -eq 'about:blank') {
            return $false
        }

        $targetUri = [Uri]$Url
        $currentUri = [Uri]$current
        if ($currentUri.Host -eq $targetUri.Host) {
            return $true
        }

        $blockedHosts = @('about', 'chrome', 'edge', 'devtools')
        foreach ($blockedHost in $blockedHosts) {
            if ($currentUri.Host -like "$blockedHost*") {
                return $false
            }
        }

        return $true
    } catch {
        return $false
    }
}

function Navigate-ToUrl {
    param(        [Parameter(Mandatory = $true)][string]$Url
    )

    if ($script:CdpDebugPort -gt 0) {
        [void](Ensure-CdpSession -Port $script:CdpDebugPort -PreferredTargetId $script:MainCdpTargetId)
    }

    try {
        Invoke-CdpCommand -Method 'Page.navigate' -Params ([ordered]@{
            url = $Url
        }) -TimeoutSec 30 | Out-Null
        return
    } catch {
        if (Test-NavigationSucceeded -Url $Url) {
            return
        }
        if ($script:CdpDebugPort -gt 0) {
            [void](Ensure-CdpSession -Port $script:CdpDebugPort -PreferredTargetId $script:MainCdpTargetId)
            if (Test-NavigationSucceeded -Url $Url) {
                return
            }
        }
        Write-StepError -Step "Navigate-ToUrl:$Url" -ErrorRecord $_
        throw
    }
}

function Test-PageIsVisibleForHuman {
    try {
        $state = Invoke-CdpEvaluate -Expression 'document.readyState' -TimeoutSec 5
        return ($state -eq 'interactive' -or $state -eq 'complete')
    } catch {
        return $true
    }
}

function Invoke-PageScrollBy {
    param(
        [Parameter(Mandatory = $true)][int]$DeltaY
    )

    $delta = [int]$DeltaY
    $expression = @"
(() => {
  window.scrollBy(0, $delta);
  const root = document.scrollingElement || document.documentElement || document.body;
  return {
    scrollY: window.scrollY,
    delta: $delta,
    height: root ? root.scrollHeight : 0
  };
})()
"@
    return Invoke-CdpEvaluate -Expression $expression -TimeoutSec 5
}

function Dispatch-MouseWheel {
    param(
        [int]$X = 600,
        [int]$Y = 520,
        [int]$DeltaY
    )

    try {
        Invoke-CdpCommand -Method 'Input.synthesizeScrollGesture' -Params @{
            x                 = $X
            y                 = $Y
            yDistance         = -$DeltaY
            speed             = 800
            repeatCount       = 1
            gestureSourceType = 'mouse'
        } -TimeoutSec 5 | Out-Null
    } catch {
        Invoke-PageScrollBy -DeltaY $DeltaY | Out-Null
    }
}

function Invoke-PageClickAt {
    param(
        [Parameter(Mandatory = $true)][int]$X,
        [Parameter(Mandatory = $true)][int]$Y
    )

    $beforeTargetIds = @()
    if ($script:CdpDebugPort -gt 0) {
        try {
            $beforeTargetIds = Get-CdpPageTargetIds -Port $script:CdpDebugPort
        } catch {
            $beforeTargetIds = @()
        }
    }

    $expression = @"
(() => {
  const el = document.elementFromPoint($X, $Y);
  if (!el) return false;
  el.click();
  return true;
})()
"@
    $clicked = $false
    try {
        $clicked = [bool](Invoke-CdpEvaluate -Expression $expression -TimeoutSec 5)
    } catch {
        $clicked = $false
    }

    if (-not $clicked) {
        Dispatch-MouseClick -X $X -Y $Y
    }

    try {
        Restore-MainBrowserTab -BeforeTargetIds $beforeTargetIds -WaitForNewTabs $true
    } catch {
    }
}

function Dispatch-MouseClick {
    param(
        [int]$X,
        [int]$Y
    )

    Invoke-CdpCommand -Method 'Input.dispatchMouseEvent' -Params ([ordered]@{
        type         = 'mousePressed'
        x            = $X
        y            = $Y
        button       = 'left'
        clickCount   = 1
        pointerType  = 'mouse'
    }) -TimeoutSec 5 | Out-Null

    Invoke-CdpCommand -Method 'Input.dispatchMouseEvent' -Params ([ordered]@{
        type         = 'mouseReleased'
        x            = $X
        y            = $Y
        button       = 'left'
        clickCount   = 1
        pointerType  = 'mouse'
    }) -TimeoutSec 5 | Out-Null
}

function Capture-Screenshot {
    param(        [Parameter(Mandatory = $true)][string]$Path,
        [AllowNull()]$Config = $null,
        [AllowNull()]$Task = $null,
        [AllowNull()]$Context = $null,
        [AllowNull()]$DeviceId = $null,
        [AllowNull()][int]$RoundNumber = 0,
        [AllowNull()][string]$ErrorCode = $null,
        [AllowNull()][string]$StepName = $null
    )

    $result = Invoke-CdpCommand -Method 'Page.captureScreenshot' -Params ([ordered]@{
        format                = 'png'
        fromSurface           = $true
        captureBeyondViewport  = $true
    }) -TimeoutSec 20

    $imageData = [string](Get-ObjectPropertyValue -Object $result -Name 'data' -Default '')
    if ([string]::IsNullOrWhiteSpace($imageData)) {
        throw 'Page.captureScreenshot did not return image data'
    }

    $bytes = [System.Convert]::FromBase64String($imageData)
    [System.IO.File]::WriteAllBytes($Path, $bytes)

    if ($null -ne $Config -and $null -ne $Task -and $null -ne $Context -and $null -ne $DeviceId) {
        try {
            $payload = [ordered]@{
                task_id = $Task.id
                device_id = $DeviceId
                round = $RoundNumber
                error_code = if (-not [string]::IsNullOrWhiteSpace($ErrorCode)) { $ErrorCode } else { $StepName }
                step = $StepName
                file_name = [System.IO.Path]::GetFileName($Path)
                mime_type = 'image/png'
                screenshot_base64 = [Convert]::ToBase64String($bytes)
                screenshot_path = $Path
            }
            [void](Invoke-ApiPostJson -Config $Config -Path '/task/screenshot' -Payload $payload -Context $Context -EventName 'task_screenshot')
        } catch {
            Write-RunLog -Context $Context -Level 'WARN' -Event 'task_screenshot' -Message "Screenshot upload failed" -Data @{ error = $_.Exception.Message; path = $Path }
        }
    }

    return $true
}

function Capture-ErrorScreenshot {
    param(
        [Parameter(Mandatory = $true)]$Context,
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)]$Task,
        [Parameter(Mandatory = $true)][string]$DeviceId,
        [Parameter(Mandatory = $true)][int]$RoundNumber,
        [Parameter(Mandatory = $true)][string]$StepName,
        [AllowNull()][string]$ErrorCode = $null
    )

    $prefix = "task_$($Task.id)_round_${RoundNumber}_$StepName"
    $path = Capture-PageShot -Context $Context -Prefix $prefix -Config $Config -Task $Task -DeviceId $DeviceId -RoundNumber $RoundNumber -ErrorCode $(if ($ErrorCode) { $ErrorCode } else { $StepName })
    if ($null -ne $path) {
        Write-RunLog -Context $Context -Level 'INFO' -Event 'error_screenshot' -Message "Error screenshot captured" -Data @{ task_id = $Task.id; round = $RoundNumber; path = $path; step = $StepName }
    }
    return $path
}


function Accept-KnownCookiePopup {
    param(        [Parameter(Mandatory = $true)]$Context
    )

    $selectors = @(
        '#cookie-buttons button',
        '#cookies-box button',
        '[class*="cookiesstyles__ButtonsWrapper"] button'
    )

    $js = @"
(() => {
  const selectors = $(@($selectors) | ConvertTo-Json -Compress);
  for (let i = 0; i < selectors.length; i++) {
    const el = document.querySelector(selectors[i]);
    if (el) {
      try {
        el.click();
        return JSON.stringify({ clicked: true, selector: selectors[i] });
      } catch (err) {
        return JSON.stringify({ clicked: false, selector: selectors[i], error: (err && err.message) ? err.message : 'click_failed' });
      }
    }
  }
  return null;
})()
"@

    try {
        $value = Invoke-CdpEvaluate -Expression $js -TimeoutSec 3
        if ($null -ne $value -and $value -ne 'null') {
            $obj = $value | ConvertFrom-Json
            if ($obj.clicked) {
                return $obj.selector
            }
        }
    } catch {
    }

    return $null
}

function Accept-CookiesIfNeeded {
    param(        [Parameter(Mandatory = $true)]$Context
    )

    $js = @'
(() => {
  const selectors = [
    'button',
    '[role="button"]',
    'a',
    'input[type="button"]',
    'input[type="submit"]'
  ];
  const targets = [];
  function normalize(text) {
    return (text || '').toString().trim().toLowerCase();
  }
  function score(element) {
    const text = normalize(element.innerText || element.value || '');
    if (!text) return 0;
    let s = 0;
    if (text.includes('accept') || text.includes('agree') || text.includes('allow')) s += 5;
    if (text.includes('cookie')) s += 3;
    if (text.includes('all')) s += 1;
    return s;
  }
  selectors.forEach(sel => {
    document.querySelectorAll(sel).forEach(el => {
      const sc = score(el);
      if (sc >= 5) {
        targets.push({ score: sc, text: normalize(el.innerText || el.value || ''), selectorPath: getSelector(el) });
      }
    });
  });
  targets.sort((a, b) => b.score - a.score);
  if (targets.length === 0) return JSON.stringify({ clicked: false });
  const target = targets[0];
  const element = document.querySelector(target.selectorPath);
  if (!element) return JSON.stringify({ clicked: false });
  element.click();
  return JSON.stringify({ clicked: true, text: target.text });

  function getSelector(el) {
    if (!(el instanceof Element)) return '';
    const path = [];
    while (el && el.nodeType === Node.ELEMENT_NODE) {
      let selector = el.nodeName.toLowerCase();
      if (el.id) {
        selector += '#' + el.id;
        path.unshift(selector);
        break;
      } else {
        let sib = el, nth = 1;
        while (sib = sib.previousElementSibling) {
          if (sib.nodeName.toLowerCase() == selector) nth++;
        }
        if (nth != 1) selector += ':nth-of-type(' + nth + ')';
      }
      path.unshift(selector);
      el = el.parentElement;
    }
    return path.join(' > ');
  }
})()
'@

    try {
        $value = Invoke-CdpEvaluate -Expression $js -TimeoutSec 3
        if ($null -ne $value -and $value -ne 'null') {
            $obj = $value | ConvertFrom-Json
            if ($obj.clicked) {
                return $true
            }
        }
    } catch {
    }

    return $false
}

function Log-CookieEvent {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)]$Context,
        [Parameter(Mandatory = $true)]$Task,
        [Parameter(Mandatory = $true)][string]$DeviceId,
        [Parameter(Mandatory = $true)][int]$RoundNumber,
        [Parameter(Mandatory = $true)][string]$Selector,
        [Parameter(Mandatory = $true)]$Meta
    )

    $meta = [ordered]@{}
    foreach ($k in $Meta.PSObject.Properties.Name) {
        $meta[$k] = $Meta.$k
    }
    $meta.round = $RoundNumber
    $meta.selector = $Selector

    Post-Event -Config $Config -Context $Context -Path '/task/event' -TaskId $Task.id -DeviceId $DeviceId -EventType 'cookie_banner' -LogText "Cookie popup closed (selector=$Selector)" -Meta ([pscustomobject]$meta)
}

function Get-PageFocusState {
    param(    )

    try {
        $value = Invoke-CdpEvaluate -Expression 'JSON.stringify({ focused: document.hasFocus(), visibility: document.visibilityState })' -TimeoutSec 5
        if ($null -ne $value -and $value -ne 'null') {
            return ($value | ConvertFrom-Json)
        }
    } catch {
    }

    return [pscustomobject]@{ focused = $false; visibility = 'hidden' }
}

function Wait-ForPageReadyInteractive {
    param(        [Parameter(Mandatory = $true)][int]$TimeoutSec
    )

    $start = Get-Date
    while (((Get-Date) - $start).TotalSeconds -lt $TimeoutSec) {
        try {
            $state = Invoke-CdpEvaluate -Expression 'document.readyState' -TimeoutSec 5
            if ($state -eq 'interactive' -or $state -eq 'complete') {
                return $true
            }
        } catch {
        }
        Start-Sleep -Milliseconds 250
    }

    return $false
}

function Wait-ForPageLoaded {
    param(        [Parameter(Mandatory = $true)][int]$TimeoutSec
    )

    $start = Get-Date
    while (((Get-Date) - $start).TotalSeconds -lt $TimeoutSec) {
        try {
            $state = Invoke-CdpEvaluate -Expression 'document.readyState' -TimeoutSec 5
            if ($state -eq 'complete' -or $state -eq 'interactive') {
                return $true
            }
        } catch {
        }
        Start-Sleep -Milliseconds 250
    }

    return $false
}

function Get-PageLoadErrorCode {
    param(
        [Parameter(Mandatory = $true)]$Probe
    )

    if ($null -eq $Probe) {
        return $null
    }

    try {
    $title = ([string](Get-ObjectPropertyValue -Object $Probe -Name 'title' -Default '')).ToLowerInvariant()
    $body = ([string](Get-ObjectPropertyValue -Object $Probe -Name 'bodySample' -Default '')).ToLowerInvariant()
    $rawErrorHits = Get-ObjectPropertyValue -Object $Probe -Name 'errorHits' -Default $null
    $errorHits = if ($null -ne $rawErrorHits) { @($rawErrorHits) } else { @() }

    $combined = @($title, $body) -join ' '
    $visibleTextLength = [int](Get-ObjectPropertyValue -Object $Probe -Name 'visible_text_length' -Default 0)
    $headingCount = [int](Get-ObjectPropertyValue -Object $Probe -Name 'heading_count' -Default 0)
    $cardCount = [int](Get-ObjectPropertyValue -Object $Probe -Name 'card_count' -Default 0)
    $linkCount = [int](Get-ObjectPropertyValue -Object $Probe -Name 'link_count' -Default 0)
    $buttonCount = [int](Get-ObjectPropertyValue -Object $Probe -Name 'button_count' -Default 0)
    $imagesPending = [int](Get-ObjectPropertyValue -Object $Probe -Name 'images_pending' -Default 0)
    $readyState = ([string](Get-ObjectPropertyValue -Object $Probe -Name 'ready_state' -Default '')).ToLowerInvariant()
    if ([string]::IsNullOrWhiteSpace($readyState)) {
        $readyState = ([string](Get-ObjectPropertyValue -Object $Probe -Name 'readyState' -Default '')).ToLowerInvariant()
    }
    $hasMeaningfulContent = ($visibleTextLength -gt 0 -or $headingCount -gt 0 -or $cardCount -gt 0 -or $linkCount -gt 0 -or $buttonCount -gt 0)

    if ($combined.Contains('err_name_not_resolved') -or $combined.Contains('dns_probe_finished_nxdomain') -or $combined.Contains('net::err_name_not_resolved') -or $combined.Contains('name not resolved') -or $combined.Contains('dns error')) {
        return 'dns_error'
    }
    $sslMarkers = @(
        'err_ssl', 'ssl_error', 'err_cert', 'net::err_cert',
        'certificate error', 'certificate is not valid',
        'your connection is not private', 'privacy error',
        'not secure', 'connection is not private'
    )
    foreach ($marker in $sslMarkers) {
        if ($combined.Contains($marker)) {
            return 'ssl_error'
        }
    }
    if ($combined.Contains('ssl') -and -not $hasMeaningfulContent) {
        return 'ssl_error'
    }
    if ($combined.Contains('err_connection_timed_out') -or $combined.Contains('err_connection_refused') -or $combined.Contains('err_connection_reset') -or $combined.Contains("this site can't be reached") -or $combined.Contains('webpage not available') -or $combined.Contains('page could not be loaded')) {
        return 'page_not_loaded'
    }

    $matchedErrorHits = @($errorHits | Where-Object { $_ -and -not [string]::IsNullOrWhiteSpace([string]$_) })
    if ($matchedErrorHits.Count -gt 0 -and [string]::IsNullOrWhiteSpace($body) -and -not $hasMeaningfulContent) {
        return 'empty_page'
    }
    if ([string]::IsNullOrWhiteSpace($title) -and [string]::IsNullOrWhiteSpace($body) -and -not $hasMeaningfulContent -and ($imagesPending -le 0 -and $readyState -notin @('loading','interactive'))) {
        return 'empty_page'
    }
    return $null
    } catch {
        Write-StepError -Step 'Get-PageLoadErrorCode' -ErrorRecord $_ -Level 'WARN'
        return $null
    }
}

function Wait-ForPageReadyForHuman {
    param(        [Parameter(Mandatory = $true)][int]$MaxWaitMs
    )

    $start = Get-Date
    while (((Get-Date) - $start).TotalMilliseconds -lt $MaxWaitMs) {
        try {
            $state = Invoke-CdpEvaluate -Expression 'document.readyState' -TimeoutSec 5
            if (($state -eq 'interactive' -or $state -eq 'complete') -and (Test-PageIsVisibleForHuman)) {
                Start-Sleep -Milliseconds (Random-IntInclusive -Min 500 -Max 1500)
                return $true
            }
        } catch {
        }
        Start-Sleep -Milliseconds 200
    }

    return $false
}

function Select-SafeTapCoordinates {
    param(
        [Parameter(Mandatory = $true)]$Probe,
        [Parameter(Mandatory = $true)][bool]$AllowBannerClicks,
        [Parameter(Mandatory = $true)]$BlockedRegions
    )

    if ($AllowBannerClicks) {
        $width = 1280
        $height = 900
        try {
            $width = [int]$Probe.viewport_width
            $height = [int]$Probe.viewport_height
        } catch {
        }
        return [pscustomobject]@{
            x = Random-IntInclusive -Min 150 -Max ([Math]::Max($width - 150, 200))
            y = Random-IntInclusive -Min 250 -Max ([Math]::Max($height - 150, 400))
        }
    }

    $safePoint = $null
    if ($Probe.safePoint -and $Probe.safePoint.ok -eq $true) {
        $safePoint = $Probe.safePoint
    }

    if ($null -eq $safePoint) {
        return $null
    }

    foreach ($region in @($BlockedRegions)) {
        try {
            if ($region.left -le $safePoint.x -and $safePoint.x -le $region.right -and $region.top -le $safePoint.y -and $safePoint.y -le $region.bottom) {
                return $null
            }
        } catch {
        }
    }

    return [pscustomobject]@{ x = [int]$safePoint.x; y = [int]$safePoint.y }
}

function Capture-PageShot {
    param(        [Parameter(Mandatory = $true)]$Context,
        [Parameter(Mandatory = $true)][string]$Prefix,
        [AllowNull()]$Config = $null,
        [AllowNull()]$Task = $null,
        [AllowNull()]$DeviceId = $null,
        [AllowNull()][int]$RoundNumber = 0,
        [AllowNull()][string]$ErrorCode = $null
    )

    $shotDir = Join-Path $Context.RunRoot 'screenshots'
    Ensure-Directory -Path $shotDir
    $path = Join-Path $shotDir ($Prefix + '.png')
    try {
        [void](Capture-Screenshot -Path $path -Config $Config -Task $Task -Context $Context -DeviceId $DeviceId -RoundNumber $RoundNumber -ErrorCode $ErrorCode -StepName $Prefix)
        if (Test-Path -LiteralPath $path) { return $path }
    } catch {
        $errMsg = $null
        try { $errMsg = $_.Exception.Message } catch { }
        Write-RunLog -Context $Context -Level 'WARN' -Event 'error_screenshot' -Message 'Screenshot capture failed' -Data @{ prefix = $Prefix; error = $errMsg }
    }
    return $null
}


