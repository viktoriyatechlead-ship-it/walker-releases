@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul

:: ===== VMOS Desktop Runner — Installer =====
:: Запускать от имени администратора

set "INSTALL_DIR=C:\VMOS"
set "TASK_NAME=VMOS Runner"
set "SERVER_URL=http://lruxkyz77g1r748dgcu7ptc7.167.233.197.194.sslip.io"

echo.
echo  ==========================================
echo   VMOS Desktop Runner — Установка
echo  ==========================================
echo.

:: Проверка прав администратора
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo  [ОШИБКА] Запустите install.bat от имени администратора
    echo  Правая кнопка мыши -> Запуск от имени администратора
    pause
    exit /b 1
)

:: Создать директорию
echo  [1/5] Создаём %INSTALL_DIR% ...
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
if not exist "%INSTALL_DIR%\lib" mkdir "%INSTALL_DIR%\lib"
if not exist "%INSTALL_DIR%\output" mkdir "%INSTALL_DIR%\output"
if not exist "%INSTALL_DIR%\state" mkdir "%INSTALL_DIR%\state"

:: Копировать файлы раннера
echo  [2/5] Копируем файлы ...
set "SRC=%~dp0"
copy /Y "%SRC%run.ps1" "%INSTALL_DIR%\run.ps1" >nul
copy /Y "%SRC%lib\*.ps1" "%INSTALL_DIR%\lib\" >nul

:: Создать config.json
echo  [3/5] Создаём конфиг ...
if not exist "%INSTALL_DIR%\config.json" (
    (
        echo {
        echo   "apiBaseUrl": "%SERVER_URL%",
        echo   "apiTimeoutSec": 10,
        echo   "heartbeatIntervalSec": 15,
        echo   "heartbeatRetryDelaySec": 5,
        echo   "emptyQueueWaitSec": 60,
        echo   "geoBlockedMinSec": 60,
        echo   "geoBlockedMaxSec": 120,
        echo   "webViewReadyTimeoutSec": 15,
        echo   "pageReadyTimeoutSec": 25,
        echo   "pageReadyForHumanMaxWaitMs": 8000,
        echo   "captureOnSuccess": false,
        echo   "clientVersion": "windows-ps/1.0",
        echo   "deviceType": "desktop",
        echo   "behaviorProfile": "scanner",
        echo   "outputRoot": "C:\\VMOS\\output",
        echo   "stateDir": "C:\\VMOS\\state",
        echo   "browser": {
        echo     "preferred": ["edge", "chrome"],
        echo     "extraArgs": [
        echo       "--disable-features=IsolateOrigins,site-per-process",
        echo       "--disable-background-networking",
        echo       "--disable-default-apps",
        echo       "--disable-extensions",
        echo       "--disable-sync",
        echo       "--no-first-run",
        echo       "--no-default-browser-check",
        echo       "--disable-popup-blocking"
        echo     ]
        echo   }
        echo }
    ) > "%INSTALL_DIR%\config.json"
    echo     Создан новый config.json
) else (
    echo     config.json уже существует — не перезаписываем
)

:: Копировать exe если есть рядом с install.bat (сборка из dist\)
set "SRC_EXE=%~dp0vmos-runner.exe"
if exist "%SRC_EXE%" (
    copy /Y "%SRC_EXE%" "%INSTALL_DIR%\vmos-runner.exe" >nul
    echo     vmos-runner.exe скопирован
)

:: Создать тихий лончер
echo  [4/5] Создаём лончер ...
if exist "%INSTALL_DIR%\vmos-runner.exe" (
    :: Запускаем скомпилированный exe
    (
        echo Set WShell = CreateObject^("WScript.Shell"^)
        echo WShell.Run """C:\VMOS\vmos-runner.exe""", 0, False
    ) > "%INSTALL_DIR%\launcher.vbs"
    echo     Лончер: vmos-runner.exe ^(скомпилированный^)
) else (
    :: Fallback — запускаем PS1 скрипт
    (
        echo Set WShell = CreateObject^("WScript.Shell"^)
        echo cmd = "powershell.exe -WindowStyle Hidden -ExecutionPolicy Bypass -NonInteractive -File ""C:\VMOS\run.ps1"" -ConfigPath ""C:\VMOS\config.json"""
        echo WShell.Run cmd, 0, False
    ) > "%INSTALL_DIR%\launcher.vbs"
    echo     Лончер: run.ps1 ^(скрипт^)
)

:: Создать stop.bat
(
    echo @echo off
    echo taskkill /F /IM powershell.exe /FI "WINDOWTITLE eq VMOS*" >nul 2>&1
    echo taskkill /F /IM msedge.exe /FI "COMMANDLINE eq *9222*" >nul 2>&1
    echo taskkill /F /IM chrome.exe /FI "COMMANDLINE eq *9222*" >nul 2>&1
    echo echo Раннер остановлен.
) > "%INSTALL_DIR%\stop.bat"

:: Зарегистрировать Scheduled Task (запуск при входе в систему)
echo  [5/5] Регистрируем автозапуск ...
schtasks /delete /tn "%TASK_NAME%" /f >nul 2>&1
schtasks /create /tn "%TASK_NAME%" /tr "wscript.exe \"C:\VMOS\launcher.vbs\"" /sc ONLOGON /rl HIGHEST /f >nul
if %errorlevel% equ 0 (
    echo     Задача "%TASK_NAME%" зарегистрирована ^(запуск при входе^)
) else (
    echo  [ПРЕДУПРЕЖДЕНИЕ] Не удалось зарегистрировать задачу — запустите вручную
)

echo.
echo  ==========================================
echo   Установка завершена!
echo  ==========================================
echo.
echo   Директория:  C:\VMOS\
echo   Сервер:      %SERVER_URL%
echo   Автозапуск:  при входе в Windows
echo.
echo   Запустить сейчас? (Y/N)
set /p START_NOW=  >
if /i "%START_NOW%"=="Y" (
    echo   Запускаем...
    start "" wscript.exe "C:\VMOS\launcher.vbs"
    echo   Раннер запущен в фоне.
)
echo.
pause
